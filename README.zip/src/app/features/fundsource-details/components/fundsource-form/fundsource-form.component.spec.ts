import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FundsourceFormComponent } from './fundsource-form.component';

describe('FundsourceFormComponent', () => {
  let component: FundsourceFormComponent;
  let fixture: ComponentFixture<FundsourceFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FundsourceFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FundsourceFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
