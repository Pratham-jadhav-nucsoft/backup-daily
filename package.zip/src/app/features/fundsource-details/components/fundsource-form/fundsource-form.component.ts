import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { ApiFacadeService } from 'src/app/features/facade';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
@Component({
  selector: 'app-fundsource-form',
  templateUrl: './fundsource-form.component.html',
  styleUrls: ['./fundsource-form.component.css']
})
export class FundsourceFormComponent implements OnInit {
  bankingForm!: FormGroup;
  listOfCompany: any = [];
  listOfIfsc: any = [];
  listOfAccountType: any = [];
  selectedBankName: any = [];
  selectedState: any = [];
  selectedCountry: any = [];
  listOfPincode: any = [];
  selectedCity: any = [];


  constructor(private formBuilder: FormBuilder,private router: Router, private http: HttpClient, public apiService: ApiFacadeService,) { }
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  isFormCollapsed3: boolean = true;
  ngOnInit(): void {
    this.bankingForm = this.formBuilder.group({
      companyId: [null, Validators.required],
      bankBranchName: [null, Validators.required],
      pincodeId: [null, Validators.required],
      
      countryId: [null, Validators.required],
      bankId: [null, Validators.required],
      phoneStdCode: [null,  Validators.pattern('^[0-9]{1,4}$')],
      mobileNumber: [null,  Validators.pattern('^[0-9]{1,10}$')],
      ifscId: [null, Validators.required],
      bankBranchCode: [null, ],
      cityId: [null, Validators.required],
      address: [null,Validators.pattern('^[0-9]{1,10}$')],
      faxNumber: [null,Validators.pattern('^[0-9]{1,10}$')],
      emailId: [null,  Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)],
      micrCode: [null, [Validators.required, Validators.pattern('^[0-9]+$')]],
      stateId: [null, Validators.required],
      phoneNumber: [null, Validators.pattern('^[0-9]{1,8}$')],
      relationshipPerson: [null,Validators.pattern('^[A-Za-z -]{1,20}$')],
      accountTypeCode: [null, Validators.required],
      accountName: [null, Validators.required],
      accountNumber: [null, Validators.required],
      userNumber: [null, Validators.pattern('^[0-9]{1,7}$')],
      userName: [null,],
      esctTapeInputNumber: [null, ],
      ledgerFolioNumber: [null, ],
      creditItemLimit: [null, ],
      creditReference: [null,],
      description: [null, ],
      sequence: [null, Validators.required],
      isRestricted: [null,],
      isExcluded: [null, ],
      fromDate: [null, Validators.required],
      toDate: [null, ],
      isAnchorTagged: [null, ],
    });
    this.getAllCities();
    this.getAllStates();
    this.getAllCountries();
    this.getAllPincodes();
    this.getAllBankIFSCs();
    this.getAllBankNames();

    this.getAllAccountTypes();

  }
  onSubmit() {
    if (this.bankingForm && this.bankingForm.valid) {
      // Form is valid, perform form submission logic here
      // For example, you can send the form data to your backend API
      console.log(this.bankingForm.value);
      // Reset the form after successful submission
      this.bankingForm.reset();
    } else {
      // Form is invalid, handle validation errors here or show error messages

      // Set the value of the branchNameIcon control based on the validity of the branchName field
      // Form is invalid, handle validation errors here or show error messages
      // Set the value of the branchNameIcon control based on the validity of the branchName field
      this.bankingForm.controls['branchNameIcon'].setValue(this.bankingForm.controls['branchName'].valid);
    }
  }
  get f() {
    return this.bankingForm.controls;
  }
 
  saveFundSource() {
    if (this.bankingForm.valid) {
    
    }
  }
  goBack() {
    console.log('back button')
    this.router.navigate(['/fundsource-list']);
  }



  async getAllCities() {
    this.selectedCity = await this.apiService.getAllCity();

    console.log(" Cities->>>>", this.selectedCity);
  }
  async getAllStates() {
    this.selectedState = await this.apiService.getAllState();

    console.log(" states->>>>", this.selectedState);
  }
  async getAllCountries() {
    this.selectedCountry = await this.apiService.getAllCountry();

    console.log(" countries->>>>", this.selectedCountry);
  }
  async getAllPincodes() {
    this.listOfPincode = await this.apiService.getAllPincode();

    console.log(" pincodes->>>>", this.listOfPincode);
  }
  async getAllBankIFSCs() {
    this.listOfIfsc = await this.apiService.getAllBankIFSC();

    console.log(" bank ifsc->>>>", this.listOfIfsc);
  }
  async getAllBankNames() {
    this.selectedBankName = await this.apiService.getAllBankName();

    console.log(" bank ifsc->>>>", this.selectedBankName);
  }
  async getAllAccountTypes() {
    this.listOfAccountType = await this.apiService.getAllAccountType();

    console.log(" bank ifsc->>>>", this.listOfAccountType);
  }

}
