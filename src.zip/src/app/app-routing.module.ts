import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FundsourceListComponent } from './features/fundsource-details/components/fundsource-list/fundsource-list.component';
import { FundsourceFormComponent } from './features/fundsource-details/components/fundsource-form/fundsource-form.component';
import { DialogboxComponent } from './shared/helpers/dialogbox/dialogbox.component';
import { ProductconfigurationFormComponent } from './features/product-configuration/components/productconfiguration-form/productconfiguration-form.component';
import { ProductconfigurationListComponent } from './features/product-configuration/components/productconfiguration-list/productconfiguration-list.component';
const routes: Routes = [
  // {
  //   path: 'fundsource-list',
  //   component: FundsourceListComponent
  // },
  // {
  //   path: 'fundsource-form',
  //   component: FundsourceFormComponent
  // },
 
  {
    path: 'productconfiguration-list',
    component: ProductconfigurationListComponent
  },
  {
    path: 'productconfiguration-form',
    component: ProductconfigurationFormComponent
  },
 { path: '', redirectTo: '/productconfiguration-list', pathMatch: 'full' },

];

@NgModule({

  imports: [RouterModule.forRoot(routes)],
  entryComponents: [DialogboxComponent],
  exports: [RouterModule]
})
export class AppRoutingModule { }
