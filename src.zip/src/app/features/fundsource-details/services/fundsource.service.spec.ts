import { TestBed } from '@angular/core/testing';

import { FundsourceService } from './fundsource.service';

describe('FundsourceService', () => {
  let service: FundsourceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FundsourceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
