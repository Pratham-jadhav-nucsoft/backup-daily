import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';

@Component({
  selector: 'app-practice',
  templateUrl: './practice.component.html',
  styleUrls: ['./practice.component.css']
})

export class PracticeComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  private formArrayTriggered: boolean = false;

  practiceForm!: FormGroup;
  rowFormArray!: FormArray;
  lastAddedRowIndex: number = -1;

  interestList =
    [
      {
        "commonId": 3031,
        "masterType": "interest",
        "commonCode": "interest_05",
        "commonValue": "Fixed",

      },
      {
        "commonId": 3032,
        "masterType": "interest",
        "commonCode": "interest10",
        "commonValue": "Variable",

      }
    ];
  interestMethodList =
    [
      {
        "commonId": 3033,
        "masterType": "interest_method",
        "commonCode": "interest_method_quat",
        "commonValue": "Declining Balance",
      },
      {
        "commonId": 3034,
        "masterType": "interest_method",
        "commonCode": "interest_method_year",
        "commonValue": "Flat",

      }
    ];





  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.practiceForm = this.formBuilder.group({

      isManagedFeeBasedLoanAmount: [false],
      // ticketSizeMin:[null,[Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      // ticketSizeMax:[null,[this.maxValidator('min'),Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      ticketSizeMax: [null, [this.maxValidator('ticketSizeMin'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      ticketSizeMin: [null, [this.minValidator('ticketSizeMax'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

      maxCustomerIdExposure: [null, [this.maxValidator('minCustomerIdExposure'), Validators.minLength(1), Validators.maxLength(15)]],
      minCustomerIdExposure: [0, [this.maxValidator('maxCustomerIdExposure'), Validators.minLength(1), Validators.maxLength(15)]],
      maxTenure: [null, [this.maxValidator('minTenure'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minTenure: [null, [this.minValidator('maxTenure'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],

      maxAdvanceAmount: [null, [this.maxValidator('minAdvanceAmount'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      minAdvanceAmount: [null, [this.minValidator('maxAdvanceAmount'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

      maxAprPercentage: [null, [this.maxValidator('minAprPercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minAprPercentage: [null, [this.minValidator('maxAprPercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],

      maxProcessingFeePercentage: [null, [this.maxValidator('minProcessingFeePercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minProcessingFeePercentage: [null, [this.minValidator('maxProcessingFeePercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      amtmax0: [null, Validators.required],
      amtmin0: [null, Validators.required],
      maxProcessingFeePercentage0: [null, Validators.required],
      minProcessingFeePercentage0: [null, Validators.required],
      interestCode: [[], Validators.required],
      interestMethodCode: [[], Validators.required],
      isBalanceTransferred: [false],
      isOverrideEligibility: [false],
      isFreeInsuranceAllowed: [false],


      listOfTermCommercialConfig: this.formBuilder.array([

      ]),
      // Add more form controls as needed
    });

    this.rowFormArray = this.practiceForm.get('rows') as FormArray;
    this.addContactDetails();
  
    this.contactDetails.valueChanges.subscribe(() => {
      if (!this.formArrayTriggered) {
        this.patchAmtmin1Value();
        // this.enforceLogicBetweenRows();
      
      }
      this.formArrayTriggered = false; // Reset the trigger flag
    });
    
  }
  enforceLogicBetweenRows() {
    const amtmax0Value = this.practiceForm.get('amtmax0')?.value;
    const amtmin1Control = this.contactDetails.get('amtmin1');
    this.contactDetails.controls.forEach((control: AbstractControl<any, any>, index: number, array: AbstractControl<any, any>[]) => {
      const group = control as FormGroup; // Cast control to FormGroup
    
      const amtmin1Control = group.get('amtmin1');
      const amtmax1Control = group.get('amtmax1');
    console.log(amtmin1Control);
    console.log(amtmax1Control);
    
      if (amtmax0Value !== null && amtmin1Control !== null && amtmax1Control !== null) {
        const calculatedAmtmin1 = amtmax0Value + 0.01;
    
        if (amtmin1Control.value === calculatedAmtmin1) {
          amtmin1Control.setErrors(null); // Clear error if it matches calculated value
        } else {
          amtmin1Control.setErrors({ customError: true }); // Set error if not matching
        }
      }
    });
    
  }



  patchAmtmin1Value() {
    const amtmax0Value = this.practiceForm.get('amtmax0')?.value;
    const calculatedAmtmin1 = amtmax0Value + 0.01;
  
    this.contactDetails.controls.forEach((control: AbstractControl<any, any>) => {
      const group = control as FormGroup;
      const amtmin1Control = group.get('amtmin1');
  
      if (amtmin1Control) {
        amtmin1Control.patchValue(calculatedAmtmin1);
        // You can also clear any existing errors if needed
        amtmin1Control.setErrors(null);
      }
    });
  }
  

  updateAmtmin1Value(index: number) {
    const amtmax0Value = this.practiceForm.get('amtmax0')?.value;
    const calculatedAmtmin1 = amtmax0Value + 0.01;
  
    const group = this.contactDetails.at(index) as FormGroup;
    const amtmin1Control = group.get('amtmin1');
  
    if (amtmin1Control) {
      amtmin1Control.setValue(calculatedAmtmin1, { emitEvent: false }); // Emitting event manually to avoid recursion
      this.enforceLogicBetweenRows(); // Call your existing logic to check for errors
    }
  }
  
  amtmin1ShouldMatch(index: number): boolean {
    const amtmax0Value = this.practiceForm.get('amtmax0')?.value;
    const calculatedAmtmin1 = amtmax0Value + 0.01;
  
    const group = this.contactDetails.at(index) as FormGroup;
    const amtmin1Control = group.get('amtmin1');
  
    return amtmin1Control?.value === calculatedAmtmin1;
  }




  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }

  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }

  maxValidator(minControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const minControl = control.parent?.get(minControlName);
      if (minControl && control.value !== null && minControl.value !== null) {
        const min = +minControl.value;
        const max = +control.value;

        if (max <= min) {
          return { maxError: true };
        }
      }

      return null;
    };
  }
  get contactDetails() {
    return this.practiceForm.get("listOfTermCommercialConfig") as FormArray;
  }
  minValidator(maxControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const maxControl = control.parent?.get(maxControlName);
      if (maxControl && control.value !== null && maxControl.value !== null) {
        const min = +control.value;
        const max = +maxControl.value;

        if (min >= max) {
          return { minError: true };
        }
      }

      return null;
    };
  }

  // visible() {
  //   // Convert to number
  //   if (this.practiceForm.valid) {
  //     isValid=!isValid;
  //   }

  // }

  lessThanHundred(control: AbstractControl): ValidationErrors | null {
    const value = +control.value; // Convert to number
    if (value >= 100) {
      return { lessThanHundred: true };
    }
    return null;
  }

  isManageFeeCheckboxDisabled(): boolean {
    const ticketSizeMin = this.practiceForm.get('ticketSizeMin')?.value;
    const ticketSizeMax = this.practiceForm.get('ticketSizeMax')?.value;
    return !(ticketSizeMin !== null && ticketSizeMax !== null && ticketSizeMin !== '' && ticketSizeMax !== '');
  }

  addContactDetails() {


    const termLoanCommercialProcessingFeeConfig = this.formBuilder.group({
      amtmin1: ['', [this.minValidator('amtmax1'), Validators.required]],
      amtmax1: ['', [this.maxValidator('amtmin1'), Validators.required]],
      minProcessingFeePercentage1: ['', [this.minValidator('maxProcessingFeePercentage1'), Validators.required]],
      maxProcessingFeePercentage1: ['', [this.maxValidator('minProcessingFeePercentage1'), Validators.required]],
    });

    this.contactDetails.push(termLoanCommercialProcessingFeeConfig);
    this.lastAddedRowIndex = this.contactDetails.length - 1;
    this.formArrayTriggered = true;// Update lastAddedRowIndex
  }

  addArray(i: any) {
    console.log('aaaaaa', +this.contactDetails.at(i).get('amtmax1')?.value)
    if (+this.practiceForm.value.ticketSizeMax != +this.contactDetails.at(i).get('amtmax1')?.value) {
      // if (this.practiceForm.value.ticketSizeMax.valid&&this.practiceForm.value.ticketSizeMin.valid) {
      //  this.addContactDetails();
      // } else {
      //  console.log('Please fill the current row first');
      //  }
      if (this.contactDetails.at(i).valid) {
        console.log('all fields valid');
        this.addContactDetails();
      } else {
        console.log('invalid field');

      }

    }
    else {
      console.log('max amount reached');
    }
  }





  deleteDetails(contactIndex: number) {
    this.contactDetails.removeAt(contactIndex);

    if (contactIndex === this.lastAddedRowIndex) {
      if (this.contactDetails.length === 0) {
        this.lastAddedRowIndex = -1; // No rows left
      } else {
        this.lastAddedRowIndex = this.contactDetails.length - 1; // Update to the new last row index
      }
    }
  }


  // form array
  addRow() {
    this.rowFormArray.push(this.createRowFormGroup());
  }
  // removeRow(index: number) {
  //   this.rowFormArray.removeAt(index);
  // }
  createRowFormGroup() {
    return this.formBuilder.group({
      min: [null, Validators.required],
      max: [null, Validators.required],
      // ... other controls
    });
  }
}


