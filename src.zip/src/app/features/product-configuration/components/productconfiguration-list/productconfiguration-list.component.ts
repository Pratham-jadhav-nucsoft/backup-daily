import { Component, OnInit } from '@angular/core';
import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { Router } from '@angular/router';
@Component({
  selector: 'app-productconfiguration-list',
  templateUrl: './productconfiguration-list.component.html',
  styleUrls: ['./productconfiguration-list.component.css']
})
export class ProductconfigurationListComponent implements OnInit {


  columnDefinitions1: Column[] = [];
  gridOptions1: GridOption;
  dataset1: any[] = []; 

  constructor( private router: Router) {  this.gridOptions1 = {
    enableAutoResize: false,
    enableSorting: true,
    gridHeight: 500,
    gridWidth: 1500,
    enableFiltering: true,
    enableCellNavigation: true,
    enableCheckboxSelector: true, 
    checkboxSelector: {
      // you can toggle these 2 properties to show the "select all" checkbox in different location
      hideInFilterHeaderRow: false,
      hideInColumnTitleRow: true
    },
  };  }

  ngOnInit(): void {
    this.columnDefinitions1 = [
      
      { id: 'Product Name', name: 'Product Name', field: 'sequence', filterable: true,  maxWidth: 100, sortable: true },
      { id: 'Type Of Loan', name: 'Type Of Loan', field: 'accountNumber', filterable: true, maxWidth: 150, sortable: true },
      { id: 'Product Type', name: 'Product Type', field: 'accountName', filterable: true, maxWidth: 150,  sortable: true },
      { id: 'Parent Product', name: 'Parent Product', field: 'bankId', filterable: true, maxWidth: 150, sortable: true },
      { id: 'BC Partners', name: 'BC Partners', field: 'description', filterable: true, maxWidth: 250,  sortable: true },
      
      { id: 'Last Modified By', name: '', field: 'ifscCode', filterable: true, maxWidth: 150,sortable: true },
      { id: 'Last Modified Date', name: 'address', field: 'address', filterable: true, maxWidth: 150,  sortable: true },
      { id: 'Status', name: 'isActive', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
      
      {
        id: 'action',
        
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        formatter: Formatters.editIcon
      },
      {
        id: 'delete',
        name: 'Action',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        formatter: Formatters.deleteIcon
      },
      {



        id: 'clone',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        
        formatter: this.cloneIconFormatter,

      }
    ];
  // Define your hardcoded dataset
  this.dataset1 = [
    {
      id: 1,
    
      sequence: 'Item 1',
      accountNumber: '12345',
      accountName: 'Type A',
      bankId: 'Parent A',
      description: 'Partner A',
      ifscCode: 'IFSC123',
      address: 'Address A',
      isActive: true
    },
    {
      id: 2,
    
      sequence: 'Item 2',
      accountNumber: '67890',
      accountName: 'Type B',
      bankId: 'Parent B',
      description: 'Partner B',
      ifscCode: 'IFSC456',
      address: 'Address B',
      isActive: false
    },
    // ... add more data objects
  ];
  }
  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable"  style="cursor: pointer;"></i> `;
  }
  


  route(){
    this.router.navigate(['/productconfiguration-form'])
  }
}

