import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';

@Component({
  selector: 'app-practice',
  templateUrl: './practice.component.html',
  styleUrls: ['./practice.component.css']
})

export class PracticeComponent implements OnInit {
  practiceForm!: FormGroup; // Correct the variable declaration
  success: string[] = [
    'basic1',
    'basic2',
    'basic3',
    'basic4',
    'basic5',
    'basic6',
  ]

  add: any = [
    'basic7',
    'basic8',
    'basic9',
    'basic10',
    'basic11',

  ];


  data: any;
  list1: any[] = [
    {
      "eid": 1,
      "name": "abc",
      "age": 18,
      "sal": 500,

    },
    {
      "eid": 2,
      "name": "efd",
      "age": 18,
      "sal": 800,

    }
  ]
  list2: any[] = [
    {
      "eid": 1,
      "name": "abc",
      "age": 18,
      "sal": 500,

    },
    {
      "eid": 2,
      "name": "abc",
      "age": 18,
      "sal": 500,

    },
    {
      "eid": 3,
      "name": "abc",
      "age": 18,
      "sal": 500,

    },
    {
      "eid": 4,
      "name": "abc",
      "age": 18,
      "sal": 500,

    },
    {
      "eid": 5,
      "name": "abc",
      "age": 18,
      "sal": 500,

    }
  ]
  i:any = this.list1.length 
  selectedProductList: any;
  constructor(private formBuilder: FormBuilder, private apiService: ApiService) {
    this.practiceForm = this.formBuilder.group({
      test: [null]

    });
  }

  ngOnInit(): void {


    console.log('i',this.i);
    
    this.getAllProductType()
  }
  addarray() {
    // // if(this.index<this.add.length){
    // this.success.push(this.add[this.index]);
    // // this.index++;
    // // }

    this.list1.push(this.list2[this.i])
    console.log(this.list1);

  }


  async method1() {
    this.selectedProductList = await this.getAllProductType();

  }


  getAllProductType() {
    console.log('hello');
    this.apiService.getAll(GlobalUrlService.productType).subscribe(res => {
      console.log('helloworld', res);
      this.selectedProductList = res;
      console.log('this.selectedProductList', this.selectedProductList);

    });
  }
  // async newmethod(){
  //   return Promise(resolve => {
  //     return this.apiService.getAll()
  //   }

  //   )
  // }

}


