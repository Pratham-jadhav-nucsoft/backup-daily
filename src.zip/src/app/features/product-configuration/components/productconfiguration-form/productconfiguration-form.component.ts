import { Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { LimitLoanComponent } from '../limit-loan/limit-loan.component';
import { TermLoanComponent } from '../term-loan/term-loan.component';
import { validateHorizontalPosition } from '@angular/cdk/overlay';
import { ChangeDetectorRef, /* ... */ } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-productconfiguration-form',
  templateUrl: './productconfiguration-form.component.html',
  styleUrls: ['./productconfiguration-form.component.css']
})
export class ProductconfigurationFormComponent implements OnInit {
  @ViewChild('dynamicComponent', { read: ViewContainerRef, static: true })
  dynamicComponentContainer!: ViewContainerRef;

  allowedIndustriesSelected: boolean = false;
  termLoanComponentRef: any = null;
  limitLoanComponentRef: any = null;
  showAdditionalDiv: boolean = false;
  showAdditionalDiv2: boolean = false;
  showAdditionalDiv3: boolean = false;
  productForm!: FormGroup;
  termForm: any;
  selectedProductTypes: boolean[] = [];
  selectedValues: any;
  filteredSubIndustries: any[] = [];
  isFormCollapsed: boolean = true;
  termLoanPayload: any;
  limitLoanPayload: any;
  selectedCompanyList: any = [];
  selectedProductList: any = [];
  selectedIndustryList: any = [];
  selectedSubIndustryList: any = [];
  selectedCategoryList: any = [];
  selectedInterestList: any = [];


  selectedBranchList: any = [];
  params: any;
  editingMode = false;


  // categoryList = [
  //   {
  //     "commonId": 3030,
  //     "masterType": "product_category",
  //     "commonCode": "product_01",
  //     "commonValue": "MSME",
  //   },
  //   {
  //     "commonId": 3110,
  //     "masterType": "product_category",
  //     "commonCode": "personal_loan",
  //     "commonValue": "Personal Loan",


  //   },
  //   {
  //     "commonId": 3111,
  //     "masterType": "product_category",
  //     "commonCode": "business_loan",
  //     "commonValue": "Business Loan",


  //   }
  // ];

  productList = [
    {
      "productId": 261,
      "productName": "Express",
      "parentProductId": null,

    },
    {
      "productId": 262,
      "productName": "Retail",
      "parentProductId": null,

    },
    {
      "productId": 263,
      "productName": "Test",
      "parentProductId": null,

    },
    {
      "productId": 264,
      "productName": "dfsdf",
      "parentProductId": null,

    },
    {
      "productId": 265,
      "productName": "Personal Loan",
      "parentProductId": 262,

    }
  ];



  // industries =
  //   [
  //     { value: 1275, label: 'Financial Services' },
  //     { value: 1272, label: 'Healthcare' },
  //   ];

  subIndustriesMapping: any =
    [
      {
        "subIndustryName": "Pharmaceuticals",
        "subIndustryId": 65,
        "industryId": 1275,
        "industryName": "Financial Services"
      },
      {
        "subIndustryName": "Biotechnology",
        "subIndustryId": 66,
        "industryId": 1275,
        "industryName": "Financial Services"
      },
      {
        "subIndustryName": "Telemedicine",
        "subIndustryId": 67,
        "industryId": 1275,
        "industryName": "Financial Services"
      },
      {
        "subIndustryName": "Banking",
        "subIndustryId": 93,
        "industryId": 1275,
        "industryName": "Financial Services"
      },
      {
        "subIndustryName": "Stock Exchanges",
        "subIndustryId": 95,
        "industryId": 1272,
        "industryName": "Health Care"
      },
      {
        "subIndustryName": "Asset Management",
        "subIndustryId": 99,
        "industryId": 1272,
        "industryName": "Health Care"
      }
    ]

  branchOptions: any[] =
    [

      {
        "branchId": 1288,
        "branchCode": "G300",
        "branchName": "GrantRoad3",

      },
      {
        "branchId": 1289,
        "branchCode": "SANE07",
        "branchName": "SantacruzE70",

      },
      {
        "branchId": 1290,
        "branchCode": "Matheran01",
        "branchName": "Matheran",

      },




    ]
  // companylist: any[] =
  //   [
  //     {
  //       "companyId": 1,
  //       "companyName": "Neogrowth Group Company",
  //       "companyCode": "202308101734211270",
  //       "parentCompanyId": 125,
  //     },
  //     {
  //       "companyId": 128,
  //       "companyName": "Nucsoft",
  //       "companyCode": "202308211639423720",
  //       "parentCompanyId": 1,

  //     },
  //     {
  //       "companyId": 129,
  //       "companyName": "Nucsoft1",
  //       "companyCode": "202308211639590150",
  //       "parentCompanyId": 128,

  //     },
  //     {
  //       "companyId": 95,
  //       "companyName": "Aditya Birla Capital1",
  //       "companyCode": "202308211640311780",
  //       "parentCompanyId": 128,

  //     },
  //     {
  //       "companyId": 146,
  //       "companyName": "Tristha",
  //       "companyCode": "202308211641191690",
  //       "parentCompanyId": 1,

  //     }
  //   ]

  constructor(
    private formBuilder: FormBuilder,
    private componentFactoryResolver: ComponentFactoryResolver,
    private cdr: ChangeDetectorRef,
    private toastr: ToastrService,
    private router: Router,
    private http: HttpClient,
    public apiService: ApiFacadeService,
    public activate: ActivatedRoute
  ) {

    this.activate.queryParams.subscribe(productId => {
      this.params = productId;
      console.log("this.params", this.params);
      if (productId['productId']) {
        this.editingMode = true;
      }

    })


  }

  ngOnInit(): void {

    this.productForm = this.formBuilder.group({
      isRenewal: [false],
      renewalProductId: [325, Validators.required],
      productName: [null, [Validators.required, Validators.pattern('^[a-zA-Z0-9\\s]*$'), Validators.minLength(2), Validators.maxLength(30)]],
      productDescription: [null, [Validators.minLength(2), Validators.maxLength(300)]],
      productCode: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(6)]],
      parentProductId: [null],
      appIdTL: [null, [Validators.required, Validators.pattern('^[0-9]+$'), Validators.minLength(1), Validators.maxLength(15)]],
      compTL: [null, [Validators.required, Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
      compLL: [null, [Validators.required, Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
      appIdLL: [null, [Validators.required, Validators.pattern('^[0-9]+$'), Validators.minLength(1), Validators.maxLength(15)]],
      overrideAtCalculatorLevel: [false],
      productCategoryCode: [null, Validators.required],
      typesOfProduct1: [[], Validators.required],
      companyId: [null, Validators.required],
      listOfIndustries: [[],],
      allowedSubIndustries: [[], [this.subIndustryValidator(this.subIndustriesMapping)]],
      isSecured: [false],
      isUnsecured: [false],
      branchId: [[], Validators.required],
      maxOutstandingPercentageOfPreviousLoan: [null,],
      isBcPartner: [false,],
    },
      {
        validators: [this.masterFormCompositionSumValidator(), this.atLeastOneCheckedValidator()],

      });



    this.getAllCompanies();
    this.getAllProductTypes();
    this.getAllIndustries();
    this.getAllCategories();
    this.getAllBranches();
    this.fetchProductData();
  }



  get f() {
    return this.productForm.controls;
  }


  // toggleCollapse() {
  //   this.isFormCollapsed = !this.isFormCollapsed;
  // }


  onAllowedIndustriesChange(): void {
    let selectedIndustries = this.productForm.value.listOfIndustries;
    console.log('selectedIndustries---------->', selectedIndustries);
    let matchingSubIndustries: any = [];
    // Loop through selected industries and find their corresponding sub-industries
    selectedIndustries.forEach((industry: any) => {
      let subInd: any = [];
      subInd = this.subIndustriesMapping.filter(
        (subIndustry: any) => subIndustry.industryId === industry
      );
      subInd.forEach((element: any) => {
        matchingSubIndustries.push(element);
      });
    });
    this.productForm.controls['allowedSubIndustries'].patchValue(matchingSubIndustries);
    this.allowedIndustriesSelected = true;
    this.cdr.markForCheck(); //
  }


  subIndustryValidator(subIndustriesMapping: any[]): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const selectedIndustries: any[] = control.value || [];
      const allowedSubIndustries: any[] = control.parent?.get('allowedSubIndustries')?.value || [];

      let hasValidationError = false;

      selectedIndustries.forEach(industryId => {
        const industrySubIndustries: any[] = subIndustriesMapping.filter(subIndustry => subIndustry.industryId === industryId);

        if (industrySubIndustries.length > 0) {
          const isAnySubIndustrySelected = industrySubIndustries.some(subIndustry => allowedSubIndustries.includes(subIndustry));
          if (!isAnySubIndustrySelected) {
            hasValidationError = true;
          }
        }
      });

      return hasValidationError ? { subIndustriesMissing: true } : null;
    };
  }

  onProductTypeChange(): void {
    this.selectedValues = this.productForm.get('typesOfProduct1')?.value || [];

    // Set the showAdditionalDiv properties based on the condition
    this.showAdditionalDiv = this.selectedValues.includes(1);
    this.showAdditionalDiv2 = this.selectedValues.includes(2);
    this.showAdditionalDiv3 = this.selectedValues.includes(2) && this.selectedValues.includes(1);

    // Clear any previously loaded components
    this.dynamicComponentContainer.clear();

    if (this.selectedValues.includes(1)) {
      const termLoanFactory = this.componentFactoryResolver.resolveComponentFactory(TermLoanComponent);
      this.termLoanComponentRef = this.dynamicComponentContainer.createComponent(termLoanFactory);



    }

    if (this.selectedValues.includes(2)) {
      const limitLoanFactory = this.componentFactoryResolver.resolveComponentFactory(LimitLoanComponent);
      this.limitLoanComponentRef = this.dynamicComponentContainer.createComponent(limitLoanFactory);
    }


  }



  onSubmitButtonClicked(): void {

    const selectedCompanyId = this.productForm.value.companyId;
    console.log('------------>', this.productForm.value.companyId);

    const selectedCompany = this.selectedCompanyList.find((company: any) => company.companyId === selectedCompanyId);
    const companyPayload = selectedCompany.companyId




    const selectedBranchIds: number[] = this.productForm.value.branchId;

    const branchId = selectedBranchIds.map(selectedBranchId => {
      const selectedBranch = this.branchOptions.find(branch => branch.branchId === selectedBranchId);

      return selectedBranch
        ? {
          branchId: selectedBranch.branchId,
          branchName: selectedBranch.branchName,
          branchCode: selectedBranch.branchCode,
          product_branch_mapping_id: 0,
          productId: 0,
          isActive: false,
          isDeleted: false,
          createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          createdDate: "2023-08-18T03:53:13.873Z",
          updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          updatedDate: "2023-08-18T03:53:13.873Z"
        }
        : null;
    }).filter(branch => branch !== null);



    const typesOfProduct = this.selectedValues.map((productTypeId: number) => {
      const selectedType = this.selectedProductList.find((type: any) => type.productTypeId === productTypeId);
      console.log('-------------------option---->', selectedType);



      const appIdPatternControlName = selectedType?.productTypeId === 1 ? 'appIdTL' : 'appIdLL';
      const appIdPattern = this.productForm.get(appIdPatternControlName)?.value;
      const percentageComposition1 = selectedType?.productTypeId === 1 ? 'compTL' : 'compLL';
      const percentageComposition = this.productForm.get(percentageComposition1)?.value;
      console.log('---------------->>>>>>>>>>>>>value', selectedType?.productTypeId);

      console.log('-------->>>>>>>>>>>>>>>', selectedType?.productTypeId === 1 ? 'appIdTL' : 'appIdLL');


      return {
        productCompositionID: 0,
        productTypeId: selectedType?.productTypeId,
        appIdPattern,
        percentageComposition,
        isDeleted: false,
        productTypeName: "string",
        isActive: false,
        createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        createdDate: "2023-08-18T03:53:13.873Z",
        updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        updatedDate: "2023-08-18T03:53:13.873Z"
      };

    });
    // console.log('Branch Information Array:', branchId);

    const selectedIndustries: number[] = this.productForm.value.listOfIndustries;
    const listOfIndustries = selectedIndustries.map((industryId: number) => {
      const industrySubIndustries = this.productForm.value.allowedSubIndustries.filter(
        (subIndustry: any) => subIndustry.industryId === industryId
      );
      return {
        product_industry_mapping_id: 0,
        productId: 0, // You need to set the actual productId value here
        industryId,
        isDeleted: false,
        isActive: true,


        subIndustryId: industrySubIndustries.map((subIndustry: any) => ({
          subIndustryId: subIndustry.subIndustryId,
          product_industry_mapping_id: 0,
          isDeleted: false,
          isActive: true,

        })),
        createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        createdDate: "2023-08-18T03:53:13.873Z",
        updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        updatedDate: "2023-08-18T03:53:13.873Z",
      };
    });




    const termLoanPayload = this.termLoanComponentRef ? this.termLoanComponentRef.instance.termForm.value : {};

    const limitLoanPayload = this.limitLoanComponentRef ? this.limitLoanComponentRef.instance.limitForm.value : {};
    const productDetailsPayload = this.productForm.value;




    const result = this.productForm.value.typesOfProduct1.some((num: any) => num == 1);
    const result2 = this.productForm.value.typesOfProduct1.some((num: any) => num == 2);
    console.log('?????????????????????????', result, result2);

    let arr: any = []
    let arr2: any = []
    if (result2) {
      arr = [
        {
          limitLoanCommercialConfigId: 0,
          productCompositionId: 0,

          ...limitLoanPayload,
          isActive: true,
          isDeleted: false,
          createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          createdDate: "2023-08-18T03:53:13.873Z",
          updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          updatedDate: "2023-08-18T03:53:13.873Z"
        }
      ];

    }
    else {
      arr = null;
    }

    if (result) {
      arr2 = [
        {
          termLoanCommercialConfigId: 0,
          productCompositionId: 0,
          // Insert the term form payload here
          ...termLoanPayload,

        }
      ]

    }
    else {
      arr2 = null;
    }
    
// console.log('helllllo---->checkbox12365812376', this.termLoanComponentRef.instance.termForm.value.isManagedFeeBasedLoanAmount);

    


    const finalPayload: any = {
      productId: 0, // You need to set the actual productId value here
      typesOfProduct,
      listOfIndustries,
      companyId: companyPayload,
      ...productDetailsPayload,
      // termLoanCommercialConfig: arr2,
      termLoanCommercialConfig: arr2,

      listOfLimitLoan: arr,
      


      "isActive": true,
      "isDeleted": false,
      "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
      "createdDate": "2023-08-18T03:53:13.873Z",
      "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
      "updatedDate": "2023-08-18T03:53:13.873Z"

    };






    finalPayload.listOfIndustries = listOfIndustries;
    // finalPayload.typesOfProduct = typesOfProduct;
    finalPayload.companyId = companyPayload;
    finalPayload.branchId = branchId;
    if (finalPayload.termLoanCommercialConfig) {
      const checker = this.termLoanComponentRef.instance.termForm.value.isManagedFeeBasedLoanAmount;
      if(checker==true)
      {
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig = [];
        // if(finalPayload.termLoanCommercialConfig[0].isManagedFeeBasedLoanAmount==true){
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig.push({ listOfTermCommercialConfig: [] })
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig = termLoanPayload.listOfTermCommercialConfig;
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig.forEach((element: any) => {
          element.isActive = true,
            element.isDeleted = true,
            element.termLoanCommercialProcessingFeeConfigId = 0,
            element.createdBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            element.createdDate = "2023-08-18T03:53:13.873Z",
            element.updatedBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            element.updatedDate = "2023-08-18T03:53:13.873Z"
  
        });
   
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].termLoanCommercialConfig = 0;
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].isActive = true;
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].isDeleted = false;
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].createdBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6";
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].createdDate = "2023-08-18T03:53:13.873Z";
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].updatedBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6";
        // delete termLoanPayload.listOfTermCommercialConfig;
        delete finalPayload.termLoanCommercialConfig[0].listOfTermCommercialConfig;
      }
      else{
        finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig = [];
        delete finalPayload.termLoanCommercialConfig[0].listOfTermCommercialConfig;  
      }


    }
    delete finalPayload.allowedSubIndustries;
    delete finalPayload.typesOfProduct1;
    delete finalPayload.appIdTL;
    delete finalPayload.compTL;
    delete finalPayload.compLL;
    delete finalPayload.appIdLL;
    // delete finalPayload.branchId;
    console.log('Final payload:', finalPayload);
    // } else {
    //   console.log('Error filling form');
    //   this.toastr.error('Error filling form!', 'Error');
    // }

    // ... (other properties)

    if (finalPayload) {
      // Assuming your form value represents the payload structure

      this.apiService.postProductDetails(finalPayload)
        .then((res) => {
          console.log('Response:', res);
          // Handle success, show toast, or navigate to another page if needed
        })
        .catch((error) => {
          console.error('Error:', error);
          // Handle error, show toast, or display an error message
        });
    } else {
      console.log('error while submitting-----------');

    }

  }





  getTermLoanPayload(): any {
    return {
      minTicket: this.termForm.get('ticketmin').value,
      maxTicket: this.termForm.get('ticketmax').value,
      minCust: this.termForm.get('custmin').value,
      maxCust: this.termForm.get('custmax').value,

    };
  }

  customCompTLValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;


    if (value !== null && (isNaN(value) || value < 0 || value > 100)) {
      return { invalidCompTL: true };
    }

    return null;
  }
  customCompLLValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;


    if (value !== null && (isNaN(value) || value < 0 || value > 100)) {
      return { invalidCompLL: true };
    }

    return null;
  }

  masterFormCompositionSumValidator(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      const compTLValue = formGroup.get('compTL');
      const compLLValue = formGroup.get('compLL');

      if (compTLValue && compLLValue) {
        const totalValue = (compTLValue.value || 0) + (compLLValue.value || 0);

        if (totalValue !== 100) {
          compTLValue.setErrors({ compositionSumInvalid: true });
          compLLValue.setErrors({ compositionSumInvalid: true });
        } else {
          if (compTLValue.errors && compTLValue.errors['compositionSumInvalid']) {
            const errors = { ...compTLValue.errors };
            delete errors['compositionSumInvalid'];
            compTLValue.setErrors(Object.keys(errors).length ? errors : null);
          }

          if (compLLValue.errors && compLLValue.errors['compositionSumInvalid']) {
            const errors = { ...compLLValue.errors };
            delete errors['compositionSumInvalid'];
            compLLValue.setErrors(Object.keys(errors).length ? errors : null);
          }
        }
      }

      return null;
    };
  }


  //   getAppIdControlName() {

  //     if (this.selectedValues.includes(1)) {
  //         return 'appIdTL';
  //     }

  //     if (this.selectedValues.includes(2)) {
  //         return 'appIdLL'; 
  //     } 



  // }





  atLeastOneCheckedValidator() {
    return (formGroup: AbstractControl): { [key: string]: any } | null => {
      const securedProduct = formGroup.get('isSecured');
      const unsecuredProduct = formGroup.get('isUnsecured');

      if ((securedProduct?.dirty || unsecuredProduct?.dirty) && (!securedProduct?.value && !unsecuredProduct?.value)) {
        return { atLeastOneChecked: true };
      }

      return null;
    };
  }


  goback() {
    this.router.navigate(['/productconfiguration-list'])
  }


  async fetchProductData(): Promise<void> {
    // const productId = 123;

    try {
      // const productData :any = await this.apiService.getProductById2(this.params.productId);
      if (this.params.productId) {
        const productData: any = {
          "productId": 123,
          "isRenewal": true,
          "renewalProductId": 0,
          "productName": "oldIndustry",
          "productDescription": "ABCD",
          "productCode": "IND",
          "productCategoryCode": "business_loan",
          "parentProductId": 0,
          "typesOfProduct": [
            {
              "productCompositionID": 92,
              "productTypeId": 1,
              "appIdPattern": 10,
              "percentageComposition": 100,
              "productTypeName": "Term Loan",
              "isActive": true,
              "isDeleted": false,
              "createdBy": "00000000-0000-0000-0000-000000000000",
              "createdDate": "2023-08-25T15:55:21.14",
              "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              "updatedDate": "2023-08-08T13:55:50.683"
            }

          ],
          "overrideAtCalculatorLevel": true,
          "companyId": 1,
          "listOfIndustries": [
            {
              "product_industry_mapping_id": 4,
              "productId": 0,
              "industryId": 4,
              "subIndustryId": [
                {
                  "product_industry_mapping_id": 4,
                  "subIndustryId": 1,
                  "isActive": true,
                  "isDeleted": false
                }
              ],
              "isActive": true,
              "isDeleted": false,
              "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              "createdDate": "2023-08-25T10:23:54.217",
              "updatedBy": null,
              "updatedDate": null
            }
          ],
          "isSecured": true,
          "isUnsecured": true,
          "branchId": [
            {
              "product_branch_mapping_id": 9,
              "branchId": 42,
              "productId": 123,
              "isActive": true,
              "isDeleted": false,
              "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              "createdDate": "2023-08-25T10:23:54.217",
              "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              "updatedDate": "2023-08-09T13:55:50.683"
            }
          ],
          "maxOutstandingPercentageOfPreviousLoan": 0,
          "isBcPartner": true,
          "termLoanCommercialConfig": [
            {
              "termLoanCommercialConfigId": 30,
              "productCompositionId": 92,
              "ticketSizeMin": 20,
              "ticketSizeMax": 30,
              "minCustomerIdExposure": 1000,
              "maxCustomerIdExposure": 2000,
              "minAdvanceAmount": 10,
              "maxAdvanceAmount": 0,
              "minAprPercentage": 0,
              "maxAprPercentage": 0,
              "minTenure": 0,
              "maxTenure": 0,
              "minProcessingFeePercentage": 0,
              "maxProcessingFeePercentage": 0,
              "isManagedFeeBasedLoanAmount": true,
              "interestCode": "variable",
              "interestMethodCode": "flat",
              "isFreeInsuranceAllowed": false,
              "isOverrideEligibility": true,
              "isBalanceTransferred": false,
              "termLoanCommercialProcessingFeeConfig": [
                {
                  "termLoanCommercialConfig": 30,
                  "listOfTermCommercialConfig": [
                    {
                      "termLoanCommercialProcessingFeeConfigId": 30,
                      "amountRangeMin": 10,
                      "amountRangeMax": 0,
                      "processingFeePercentageMin": 0,
                      "processingFeePercentageMax": 0,
                      "isActive": true,
                      "isDeleted": false,
                      "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                      "createdDate": "2023-08-25T10:23:54.217",
                      "updatedBy": null,
                      "updatedDate": null
                    }
                  ]
                }
              ],
              "isActive": true,
              "isDeleted": false,
              "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              "createdDate": "0001-01-01T00:00:00",
              "updatedBy": null,
              "updatedDate": null
            }
          ],
          "listOfLimitLoan": null,
          "isActive": true,
          "isDeleted": false,
          "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          "createdDate": "2023-08-25T15:55:21.137",
          "updatedBy": null,
          "updatedDate": null
        }

        if (productData) {

          const firstTypeProductTypeId = productData.typesOfProduct[0]?.productTypeId;

          if (firstTypeProductTypeId === 1) {
            this.productForm.patchValue({
              appIdTL: productData.typesOfProduct[0]?.appIdPattern, // Assuming appIdTL is a control in your form
              compTL: productData.typesOfProduct[0]?.percentageComposition, // Assuming compTL is a control in your form
            });
          } else {
            this.productForm.patchValue({
              appIdLL: productData.typesOfProduct[0]?.appIdPattern, // Assuming appIdLL is a control in your form
              compLL: productData.typesOfProduct[0]?.percentageComposition, // Assuming compLL is a control in your form
            });
          }
          
          this.productForm.patchValue({
            isRenewal: productData.isRenewal,
            renewalProductId: productData.renewalProductId,
            productName: productData.productName,
            productDescription: productData.productDescription,
            productCode: productData.productCode,
            // parentProductId: productData.parentProductId,
            // Continue mapping other properties
            productCategoryCode: productData.productCategoryCode,
            typesOfProduct1: [productData.typesOfProduct[0]?.productTypeId],

            // appIdPattern: [productData.typesOfProduct[0]?.appIdPattern],
            // percentageComposition: [productData.typesOfProduct[0]?.percentageComposition],
            overrideAtCalculatorLevel: productData.overrideAtCalculatorLevel,
            companyId: productData.companyId,
            listOfIndustries: [productData.listOfIndustries[0]?.industryId],
            isSecured: productData.isSecured,
            isUnsecured: productData.isUnsecured,
            branchId: [productData.branchId[0]?.branchId],
            maxOutstandingPercentageOfPreviousLoan: productData.maxOutstandingPercentageOfPreviousLoan,
            isBcPartner: productData.isBcPartner,
            termLoanCommercialConfig: productData.termLoanCommercialConfig,

            // Map other properties as needed


          });
          console.log('productData---------------->', productData);
         
         

          this.onProductTypeChange()
        } else {
          console.error('Failed to fetch product data.');
        }
      }
    } catch (error) {
      console.error('Error while fetching data by ID:', error);
    }
  }





  async getAllCompanies() {
    console.log('helllllllllllllllllllllio');

    this.selectedCompanyList = await this.apiService.getAllCompany();

    console.log(" company->>>>", this.selectedCompanyList);
  }
  async getAllProductTypes() {
    console.log('adadadad');

    this.selectedProductList = await this.apiService.getAllProductType();

    console.log(" company->>>>", this.selectedProductList);
  }
  async getAllIndustries() {
    console.log('adadadad');

    this.selectedIndustryList = await this.apiService.getAllIndustry();

    console.log(" industries->>>>", this.selectedIndustryList);
  }
  async getAllSubIndustries() {
    console.log('adadadad');

    this.selectedSubIndustryList = await this.apiService.getAllSubIndustry();

    console.log(" industries->>>>", this.selectedSubIndustryList);
  }
  async getAllCategories() {
    console.log('adadadad');

    this.selectedCategoryList = await this.apiService.getAllCategory();

    console.log(" category->>>>", this.selectedCategoryList);
  }

  async getAllBranches() {
    console.log('adadadad');

    this.selectedBranchList = await this.apiService.getAllBranch();

    console.log(" category->>>>", this.selectedBranchList);
  }







}
