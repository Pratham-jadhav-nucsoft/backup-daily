export interface Auth {
}
