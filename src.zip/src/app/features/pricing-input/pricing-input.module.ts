import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PricingInputRoutingModule } from './pricing-input-routing.module';


@NgModule({
  declarations: [
  
  ],
  imports: [
    CommonModule,
    PricingInputRoutingModule
  ]
})
export class PricingInputModule { }
