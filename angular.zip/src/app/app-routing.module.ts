import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FundsourceListComponent } from './features/fundsource-details/components/fundsource-list/fundsource-list.component';
import { FunsourceFormComponent } from './features/fundsource-details/components/funsource-form/funsource-form.component';
import { DialogboxComponent } from './shared/helpers/dialogbox/dialogbox.component';
import { BankingFormComponent } from './features/fundsource-details/components/banking-form/banking-form.component';
const routes: Routes = [
  {
    path: 'fundsource-list',
    component: FundsourceListComponent
  },
  {
    path: 'funsource-form',
    component: FunsourceFormComponent
  },
  { path: '', redirectTo: '/fundsource-list', pathMatch: 'full' },

];

@NgModule({
  
  imports: [RouterModule.forRoot(routes)],
  entryComponents:[DialogboxComponent],
  exports: [RouterModule]
})
export class AppRoutingModule { }
