import { Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { LimitLoanComponent } from '../limit-loan/limit-loan.component';
import { TermLoanComponent } from '../term-loan/term-loan.component';
import { validateHorizontalPosition } from '@angular/cdk/overlay';
import { ChangeDetectorRef, /* ... */ } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-productconfiguration-form',
  templateUrl: './productconfiguration-form.component.html',
  styleUrls: ['./productconfiguration-form.component.css']
})
export class ProductconfigurationFormComponent implements OnInit {
  @ViewChild('dynamicComponent', { read: ViewContainerRef, static: true })
  dynamicComponentContainer!: ViewContainerRef;
  formControls: FormGroup | null = null;
  allowedIndustriesSelected: boolean = false;
  termLoanComponentRef: any = null;
  limitLoanComponentRef: any = null;
  showAdditionalDiv: boolean = false;
  showAdditionalDiv2: boolean = false;
  showAdditionalDiv3: boolean = false;
  productForm!: FormGroup;
  termForm: any;
  selectedProductTypes: boolean[] = [];
  selectedValues: any;
  filteredSubIndustries: any[] = [];
  isFormCollapsed: boolean = true;
  termLoanPayload: any;
  limitLoanPayload: any;
  selectedCompanyList: any = [];
  selectedProductList: any = [];
  selectedIndustryList: any = [];
  selectedSubIndustryList: any = [];
  selectedCategoryList: any = [];
  selectedInterestList: any = [];
  selectedParentProductList: any = [];
  industrySelected: boolean = false;

  selectedBranchList: any = [];
  params: any;
  editingMode = false;


  productpayload: any;


  constructor(
    private formBuilder: FormBuilder,
    private componentFactoryResolver: ComponentFactoryResolver,
    private cdr: ChangeDetectorRef,
    private toastr: ToastrService,
    private router: Router,
    private http: HttpClient,
    public apiService: ApiFacadeService,
    public activate: ActivatedRoute
  ) {

    this.activate.queryParams.subscribe(productId => {
      this.params = productId;
      console.log("this.params", this.params);
      if (productId['productId']) {
        this.editingMode = true;
      }

    })


  }

  ngOnInit(): void {

    this.productForm = this.formBuilder.group({

      isRenewal: [false],
      renewalProductId: [null, Validators.required],
      productName: [null, [Validators.required, Validators.pattern('^[a-zA-Z0-9\\s]*$'), Validators.minLength(2), Validators.maxLength(30)]],
      productDescription: [null, [Validators.minLength(2), Validators.maxLength(300)]],
      productCode: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(6)]],
      parentProductId: [null],
      appIdTL: [null, [Validators.required, Validators.pattern('^[0-9]+$'), Validators.minLength(1), Validators.maxLength(15)]],
      compTL: [null, [Validators.required, Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
      compLL: [null, [Validators.required, Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
      appIdLL: [null, [Validators.required, Validators.pattern('^[0-9]+$'), Validators.minLength(1), Validators.maxLength(15)]],
      overrideAtCalculatorLevel: [false],
      productCategoryCode: [null, Validators.required],
      typesOfProduct1: [[], Validators.required],
      companyId: [null, Validators.required],
      listOfIndustries: [[],],
      allowedSubIndustries: [[], [this.subIndustryValidator(this.selectedSubIndustryList)]],
      isSecured: [false],
      isUnsecured: [false],
      branchId: [[], Validators.required],
      maxOutstandingPercentageOfPreviousLoan: [null, Validators.max(100),],
      isBcPartner: [false,],
    },
      {
        validators: [this.masterFormCompositionSumValidator(), this.atLeastOneCheckedValidator()],

      });



    this.getAllCompanies();
    this.getAllProductTypes();
    this.getAllIndustries();
    this.getAllCategories();
    this.getAllBranches();
    this.fetchProductData();
    this.getAllParentProducts();
    // this.getAllSubIndutriyMappings();


    // console.log('finalobject', this.finalobject);
    // const final2 = this.finalobject[0]
    // console.log('finalobject2', final2);
  }



  get f() {
    return this.productForm.controls;
  }



  onAllowedIndustriesChange(): void {
    let selectedIndustries = this.productForm.value.listOfIndustries;
    this.industrySelected = selectedIndustries && selectedIndustries.length > 0;

    let matchingSubIndustries: any = [];
    selectedIndustries.forEach((industry: any) => {
      let subInd: any = [];
      subInd = this.selectedSubIndustryList.filter(
        (subIndustry: any) => subIndustry.industryId === industry
      );
      subInd.forEach((element: any) => {
        matchingSubIndustries.push(element);

      });
    });
    this.productForm.controls['allowedSubIndustries'].patchValue(matchingSubIndustries);
    this.allowedIndustriesSelected = true;
    this.cdr.markForCheck(); //
    this.getAllSubIndutriyMappings(this.productForm.value.listOfIndustries);
  }


  subIndustryValidator(selectedSubIndustryList: any[]): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const selectedIndustries: any[] = control.value || [];
      const allowedSubIndustries: any[] = control.parent?.get('allowedSubIndustries')?.value || [];

      let hasValidationError = false;

      selectedIndustries.forEach(industryId => {
        const industrySubIndustries: any[] = selectedSubIndustryList.filter(subIndustry => subIndustry.industryId === industryId);

        if (industrySubIndustries.length > 0) {
          const isAnySubIndustrySelected = industrySubIndustries.some(subIndustry => allowedSubIndustries.includes(subIndustry));
          if (!isAnySubIndustrySelected) {
            hasValidationError = true;
          }
        }
      });

      return hasValidationError ? { subIndustriesMissing: true } : null;
    };
  }

  onProductTypeChange(): void {

    //  this.terminst = this.termLoanComponentRef.instance.termForm;
    //  this.limitinst = this.limitLoanComponentRef.instance.limitForm;
    this.selectedValues = this.productForm.get('typesOfProduct1')?.value || [];
    console.log('selectedValues', this.selectedValues);

    // Set the showAdditionalDiv properties based on the condition
    this.showAdditionalDiv = this.selectedValues.includes(1);
    this.showAdditionalDiv2 = this.selectedValues.includes(2);
    this.showAdditionalDiv3 = this.selectedValues.includes(2) && this.selectedValues.includes(1);

    // Clear any previously loaded components
    this.dynamicComponentContainer.clear();

    if (this.selectedValues.includes(1)) {
      const termLoanFactory = this.componentFactoryResolver.resolveComponentFactory(TermLoanComponent);
      this.termLoanComponentRef = this.dynamicComponentContainer.createComponent(termLoanFactory);



    }

    if (this.selectedValues.includes(2)) {
      const limitLoanFactory = this.componentFactoryResolver.resolveComponentFactory(LimitLoanComponent);
      this.limitLoanComponentRef = this.dynamicComponentContainer.createComponent(limitLoanFactory);
    }
    console.log('-------->loanreffffffffffff', this.limitLoanComponentRef);

  }



  onSubmitButtonClicked(): void {


    let termLoanPayload: any = {};
    let limitLoanPayload: any = {};
    console.log('+++++++++++++++++', this.productForm.get('typesOfProduct1')?.value.includes(1));
    console.log('+++++++++++++++++2', this.productForm.get('typesOfProduct1')?.value.includes(2));

    if (this.productForm.get('typesOfProduct1')?.value.includes(1)) {
      termLoanPayload = this.termLoanComponentRef ? this.termLoanComponentRef.instance.termForm.value : {};
      // limitLoanPayload = this.limitLoanComponentRef ? this.limitLoanComponentRef.instance.limitForm.value : {};
      console.log('termLoanPayloadtermLoanPayload', termLoanPayload);
    }

    if (this.productForm.get('typesOfProduct1')?.value.includes(2)) {
      limitLoanPayload = this.limitLoanComponentRef ? this.limitLoanComponentRef.instance.limitForm.value : {};
      // termLoanPayload = this.termLoanComponentRef ? this.termLoanComponentRef.instance.termForm.value : {};
      console.log('limitLoanPayloadlimitLoanPayload', limitLoanPayload);
    }



    const productDetailsPayload = this.productForm.value;

    console.log('productDetailsPayload.valid', this.productForm);
    console.log('this.termLoanComponentRef.instance.termForm.valid', this.termLoanComponentRef.instance.termForm);
    console.log('this.LimitLoanComponentRef.instance.Limitform.valid', this.limitLoanComponentRef.instance.limitForm);


    if (this.productForm.valid && (this.termLoanComponentRef.instance.termForm.valid || this.limitLoanComponentRef.instance.limitForm.valid)) {




      const selectedCompanyId = this.productForm.value.companyId;
      console.log('------------>', this.productForm.value.companyId);

      const selectedCompany = this.selectedCompanyList.find((company: any) => company.companyId === selectedCompanyId);
      const companyPayload = selectedCompany.companyId




      const selectedBranchIds: number[] = this.productForm.value.branchId;


      const branchId = selectedBranchIds.map(selectedBranchId => {
        const selectedBranch = this.selectedBranchList.find((branch: any) => branch.branchId === selectedBranchId);
        console.log('branchid------------->', selectedBranch);


        var newvar3: any;
        this.productpayload.branchId.forEach((element: any) => {

          //  console.log('elseeeeeee',element.product_industry_mapping_id);

          if (selectedBranch?.branchId == element.branchId) {


            newvar3 = element.product_branch_mapping_id
            console.log('newvar3', element.product_branch_mapping_id);
          }

        })
        return selectedBranch
          ? {


            product_branch_mapping_id: this.params.productId ? newvar3 : 0,
            branchId: selectedBranch.branchId,
            branchName: selectedBranch.branchName,
            branchCode: selectedBranch.branchCode,

            productId: 0,
            isActive: true,
            isDeleted: false,
            createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            createdDate: "2023-08-18T03:53:13.873Z",
            updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            updatedDate: "2023-08-18T03:53:13.873Z"
          }
          : null;
      }).filter(branch => branch !== null);



      const typesOfProduct = this.selectedValues.map((productTypeId: number) => {

        const selectedType = this.selectedProductList.find((type: any) => type.productTypeId === productTypeId);

        const appIdPatternControlName = selectedType?.productTypeId === 1 ? 'appIdTL' : 'appIdLL';
        const appIdPattern = this.productForm.get(appIdPatternControlName)?.value;
        const percentageComposition1 = selectedType?.productTypeId === 1 ? 'compTL' : 'compLL';
        const percentageComposition = this.productForm.get(percentageComposition1)?.value;

        var newvar2: any;
        this.productpayload.typesOfProduct.forEach((element: any) => {
          if (selectedType?.productTypeId == element.productTypeId) {
            console.log('ifffffffffffffff', element.productCompositionID);

            newvar2 = element.productCompositionID
          }

        })
        var newvar1: any;
        this.productpayload.typesOfProduct.forEach((element: any) => {
          if (selectedType?.productTypeId == element.productTypeId) {
            console.log('ifffffffffffffff', element.productTypeName);

            newvar1 = element.productTypeName
          }

        })
        console.log('newvar1', newvar1);

        return {

          productCompositionID: this.params.productId ? newvar2 : 0,

          productTypeId: selectedType?.productTypeId,
          appIdPattern,
          percentageComposition,
          isDeleted: false,
          productTypeName: this.params.productId ? newvar1 : 0,
          isActive: true,
          createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          createdDate: "2023-08-18T03:53:13.873Z",
          updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          updatedDate: "2023-08-18T03:53:13.873Z"

        };
        // } 
        // else {
        //   return {

        //     productCompositionID: 0,
        //     productTypeId: selectedType?.productTypeId,
        //     appIdPattern,
        //     percentageComposition,
        //     isDeleted: false,
        //     productTypeName: "string",
        //     isActive: true,
        //     createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        //     createdDate: "2023-08-18T03:53:13.873Z",
        //     updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        //     updatedDate: "2023-08-18T03:53:13.873Z"

        //   };
        // }


      });
      // console.log('Branch Information Array:', branchId);

      const selectedIndustries: number[] = this.productForm.value.listOfIndustries;
      console.log('selectedIndustries', this.productForm.value.listOfIndustries);
      const listOfIndustries = selectedIndustries?.map((industryId: number) => {
        const selectedType = this.selectedIndustryList.find((type: any) => type.industryId === industryId);

        const industrySubIndustries = this.productForm.value.allowedSubIndustries.filter(
          (subIndustry: any) => subIndustry.industryId === industryId

        );
        console.log('industrySubIndustries', industrySubIndustries);


        var newvar: any;
        this.productpayload.listOfIndustries.forEach((element: any) => {

          //  console.log('elseeeeeee',element.product_industry_mapping_id);

          if (selectedType?.industryId == element.industryId) {
            console.log('element.product_industry_mapping_id', element.product_industry_mapping_id);

            newvar = element.product_industry_mapping_id
          }

        })





        return {

          product_industry_mapping_id: this.params.productId ? newvar : 0,


          productId: this.params.productId ? this.productpayload.listOfIndustries[0].productId : 0,
          industryId,
          isDeleted: false,
          isActive: true,
          subIndustryId: industrySubIndustries.map((subIndustry: any) => ({

            // product_industry_mapping_id:  this.params.productId ? newvar2 : 0,
            subIndustryId: subIndustry.subIndustryId,
            isDeleted: false,
            isActive: true,

          })),
          createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          createdDate: "2023-08-18T03:53:13.873Z",
          updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          updatedDate: "2023-08-18T03:53:13.873Z",
        };
      });







      const result = this.productForm.value.typesOfProduct1.some((num: any) => num == 1);
      const result2 = this.productForm.value.typesOfProduct1.some((num: any) => num == 2);
      console.log('?????????????????????????', result, result2);
      let arr: any = []
      let arr2: any = []
      if (result2) {
        arr =
          [
            {
              limitLoanCommercialConfigId: this.params ? this.productpayload.listOfLimitLoan[0].limitLoanCommercialConfigId : 0,
              productCompositionId: this.params ? this.productpayload.listOfLimitLoan[0].productCompositionId : 0,

              ...limitLoanPayload,
              isActive: true,
              isDeleted: false,
              createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              createdDate: "2023-08-18T03:53:13.873Z",
              updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              updatedDate: "2023-08-18T03:53:13.873Z"
            }
          ];

      }
      else {
        arr = null;
      }

      if (result) {
        arr2 = [
          {

            termLoanCommercialConfigId: this.params ? this.productpayload.termLoanCommercialConfig[0].termLoanCommercialConfigId : 0,
            productCompositionId: this.params ? this.productpayload.termLoanCommercialConfig[0].productCompositionId : 0,
            // Insert the term form payload here
            ...termLoanPayload,
            isActive: true,
            isDeleted: false,
            createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            createdDate: "2023-08-18T03:53:13.873Z",
            updatedBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            updatedDate: "2023-08-18T03:53:13.873Z"
          }
        ]

      }
      else {
        arr2 = null;
      }





      let finalPayload: any = {
        productId: this.params ? this.productpayload.productId : 0,
        typesOfProduct,
        listOfIndustries,
        companyId: companyPayload,
        ...productDetailsPayload,

        termLoanCommercialConfig: arr2,

        listOfLimitLoan: arr,



        "isActive": true,
        "isDeleted": false,
        "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        "createdDate": "2023-08-18T03:53:13.873Z",
        "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        "updatedDate": "2023-08-18T03:53:13.873Z"

      };



      var formarr: any=[];  
      this.productpayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig.forEach((element: any) => {
        formarr.push(element.termLoanCommercialProcessingFeeConfigId) 
      
console.log('      var formarr: any;',formarr);

      });
      // finalPayload.termLoanPayload = productId;
      finalPayload.listOfIndustries = listOfIndustries;
      // finalPayload.typesOfProduct = typesOfProduct;
      finalPayload.companyId = companyPayload;
      finalPayload.branchId = branchId;
      if (finalPayload.termLoanCommercialConfig) {
        const checker = this.termLoanComponentRef.instance.termForm.value.isManagedFeeBasedLoanAmount;
        if (checker == true) {
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig = [];
          // if(finalPayload.termLoanCommercialConfig[0].isManagedFeeBasedLoanAmount==true){
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig.push({ listOfTermCommercialConfig: [] })
        
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig = termLoanPayload.listOfTermCommercialConfig;
    
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig.forEach((element: any ,index:number) => {
        
          
              element.isActive = true,
              // element.isDeleted = false,
              element.termLoanCommercialProcessingFeeConfigId = this.params ? formarr[index] : 0,
              element.createdBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              element.createdDate = "2023-08-18T03:53:13.873Z",
              element.updatedBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6",
              element.updatedDate = "2023-08-18T03:53:13.873Z"
 
          });

          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].termLoanCommercialConfig = 0;
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].isActive = true;
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].isDeleted = false;
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].createdBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6";
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].createdDate = "2023-08-18T03:53:13.873Z";
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].updatedBy = "3fa85f64-5717-4562-b3fc-2c963f66afa6";
   
          
          delete finalPayload.termLoanCommercialConfig[0].listOfTermCommercialConfig;
        }
        else {
          finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig = [];
          delete finalPayload.termLoanCommercialConfig[0].listOfTermCommercialConfig;
        }


      }
      delete finalPayload.allowedSubIndustries;
      delete finalPayload.typesOfProduct1;
      delete finalPayload.appIdTL;
      delete finalPayload.compTL;
      delete finalPayload.compLL;
      delete finalPayload.appIdLL;

      console.log('Final payload:', finalPayload);

      // this.finalobject = finalPayload
      if (finalPayload) {


        this.apiService.postProductDetails(finalPayload)
          .then((res) => {
            console.log('Response:', res);
            this.toastr.success('Form Submitted!', 'Success');
          })
          .catch((error) => {
            console.error('Error:', error);
            this.toastr.error('Error while submiting form!', 'Error');
          });
      }


    }
    else {



      if (this.productForm && (this.termLoanComponentRef || this.limitLoanComponentRef)) {

      }

      else {
        console.log('aaaaaaaaaaaa', this.productForm.get('typesOfProduct1')?.value);

        if (this.productForm.get('typesOfProduct1')?.value.includes(2)) {
          this.limitLoanComponentRef.instance.limitForm.markAllAsTouched();
          console.log('+++++++>>>>>>>>>>>>>>>1', this.limitLoanComponentRef.instance.limitForm);
          console.log('+++++++>>>>>>>>>>>>>>>1.5', this.productForm);
          // this.productForm.get('appIdTL')?.clearValidators()
          // this.productForm.get('compTL')?.clearValidators()
          // this.productForm.get('appIdTL')?.updateValueAndValidity()
          // this.productForm.get('compTL')?.updateValueAndValidity()

        }
        if (this.productForm.get('typesOfProduct1')?.value.includes(1)) {
          this.termLoanComponentRef.instance.termForm.markAllAsTouched();
          console.log('+++++++>>>>>>>>>>>>>>>2', this.termLoanComponentRef.instance.termForm);
          console.log('+++++++>>>>>>>>>>>>>>>2.5', this.productForm);
          // this.productForm.get('appIdLL')?.clearValidators()
          // this.productForm.get('compLL')?.clearValidators()
          // this.productForm.get('appIdLL')?.updateValueAndValidity()
          // this.productForm.get('compLL')?.updateValueAndValidity()
        }

        this.productForm.markAllAsTouched();
        this.toastr.error('Error while submitting form!', 'Error');

      }
    }



  }










  getTermLoanPayload(): any {
    return {
      minTicket: this.termForm.get('ticketmin').value,
      maxTicket: this.termForm.get('ticketmax').value,
      minCust: this.termForm.get('custmin').value,
      maxCust: this.termForm.get('custmax').value,

    };
  }

  customCompTLValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;


    if (value !== null && (isNaN(value) || value < 0 || value > 100)) {
      return { invalidCompTL: true };
    }

    return null;
  }
  customCompLLValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;


    if (value !== null && (isNaN(value) || value < 0 || value > 100)) {
      return { invalidCompLL: true };
    }

    return null;
  }

  masterFormCompositionSumValidator(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      const compTLValue = formGroup.get('compTL');
      const compLLValue = formGroup.get('compLL');

      if (compTLValue && compLLValue) {
        const totalValue = (compTLValue.value || 0) + (compLLValue.value || 0);

        if (totalValue !== 100) {
          compTLValue.setErrors({ compositionSumInvalid: true });
          compLLValue.setErrors({ compositionSumInvalid: true });
        } else {
          if (compTLValue.errors && compTLValue.errors['compositionSumInvalid']) {
            const errors = { ...compTLValue.errors };
            delete errors['compositionSumInvalid'];
            compTLValue.setErrors(Object.keys(errors).length ? errors : null);
          }

          if (compLLValue.errors && compLLValue.errors['compositionSumInvalid']) {
            const errors = { ...compLLValue.errors };
            delete errors['compositionSumInvalid'];
            compLLValue.setErrors(Object.keys(errors).length ? errors : null);
          }
        }
      }

      return null;
    };
  }






  atLeastOneCheckedValidator() {
    return (formGroup: AbstractControl): { [key: string]: any } | null => {
      const securedProduct = formGroup.get('isSecured');
      const unsecuredProduct = formGroup.get('isUnsecured');

      if ((securedProduct?.dirty || unsecuredProduct?.dirty) && (!securedProduct?.value && !unsecuredProduct?.value)) {
        return { atLeastOneChecked: true };
      }

      return null;
    };
  }


  goback() {
    this.router.navigate(['/productconfiguration-list'])
  }


  async fetchProductData(): Promise<void> {


    try {

      if (this.params.productId) {


        const productData: any = await this.apiService.getProductById2(this.params.productId);
        this.productpayload = productData
        console.log('productDataproductDataproductData', productData);

        if (productData) {

          // const firstTypeProductTypeId = productData.typesOfProduct[0]?.productTypeId;
          let var1: any = []
          productData.listOfIndustries.forEach((element: any) => {
            console.log(' element.industryId', element.industryId);

            var1.push(element.industryId)
          });
          this.getAllSubIndutriyMappings(var1);
          let subindustryFormGetByIdProduct: any = [];

          productData.listOfIndustries.forEach((element: any) => {
            element.subIndustryId.forEach((element2: any) => {
              console.log(' element.subIndustryId');

              // if( element.subIndustryId == ){
              // }  
              subindustryFormGetByIdProduct.push(element2.subIndustryId)
            });
            // var5.push(element.industryId)
          });
          console.log('hiiiiii', var1);
          productData.typesOfProduct.forEach((element: any) => {

            if (element.productTypeId == 1) {
              this.productForm.patchValue({
                appIdTL: element.appIdPattern,

                // Assuming appIdTL is a control in your form
                compTL: element.percentageComposition,
                // Assuming compTL is a control in your form
              });

            }
            else {
              this.productForm.patchValue({
                appIdLL: element.appIdPattern,// Assuming appIdTL is a control in your form
                compLL: element.percentageComposition,// Assuming compTL is a control in your form
              });
            }

            // element.productTypeId

          });

          this.productForm.patchValue({
            isRenewal: productData.isRenewal,
            renewalProductId: productData.renewalProductId,
            productName: productData.productName,
            productDescription: productData.productDescription,
            productCode: productData.productCode,
            parentProductId: productData.parentProductId,
            // Continue mapping other properties
            productCategoryCode: productData.productCategoryCode,
            typesOfProduct1: [productData.typesOfProduct[0]?.productTypeId, productData.typesOfProduct[1]?.productTypeId],
            overrideAtCalculatorLevel: productData.overrideAtCalculatorLevel,
            companyId: productData.companyId,
            listOfIndustries: var1,
            isSecured: productData.isSecured,
            isUnsecured: productData.isUnsecured,
            branchId: [productData.branchId[0]?.branchId],
            maxOutstandingPercentageOfPreviousLoan: productData.maxOutstandingPercentageOfPreviousLoan,
            isBcPartner: productData.isBcPartner,
            termLoanCommercialConfig: productData.termLoanCommercialConfig,
          });
          this.onProductTypeChange();
          this.industrySelected = var1 && var1.length > 0;
          console.log('var1', var1);
          console.log('productData---------------->', productData);

          console.log('subindustryFormGetByIdProduct', subindustryFormGetByIdProduct);
          setTimeout(() => {
            this.productForm.controls['allowedSubIndustries'].patchValue(this.getSubIndustry(subindustryFormGetByIdProduct));
          }, 1000);

          console.log(" subindustry2->>>>", this.selectedSubIndustryList);
          this.productForm.markAllAsTouched()


        } else {
          console.error('Failed to fetch product data.');
        }
      }
    } catch (error) {
      console.error('Error while fetching data by ID2:', error);
    }
  }

  getSubIndustry(subindustryFormGetByIdProduct: any) {
    let subInduastryToPatch: any = [];
    subindustryFormGetByIdProduct.forEach((element: any) => {
      this.selectedSubIndustryList.forEach((subIndustry: any) => {
        if (element == subIndustry.subIndustryId) {
          subInduastryToPatch.push(subIndustry);
        }
      });
    });
    return subInduastryToPatch;
  }



  async getAllCompanies() {

    this.selectedCompanyList = await this.apiService.getAllCompany();

    console.log(" company->>>>", this.selectedCompanyList);
  }
  async getAllProductTypes() {

    this.selectedProductList = await this.apiService.getAllProductType();

    console.log(" company->>>>", this.selectedProductList);
  }
  async getAllIndustries() {

    this.selectedIndustryList = await this.apiService.getAllIndustry();

    console.log(" industries->>>>", this.selectedIndustryList);
  }
  async getAllCategories() {

    this.selectedCategoryList = await this.apiService.getAllCategory();

    console.log(" category->>>>", this.selectedCategoryList);
  }
  async getAllBranches() {

    this.selectedBranchList = await this.apiService.getAllBranch();

    console.log(" category->>>>", this.selectedBranchList);
  }
  async getAllParentProducts() {

    this.selectedParentProductList = await this.apiService.getAllParentProduct();

    console.log(" category->>>>", this.selectedParentProductList);
  }
  async getAllSubIndutriyMappings(payload: any) {

    // const listOfIndustriesJson = JSON.stringify(this.productForm.value.listOfIndustries);

    this.selectedSubIndustryList = await this.apiService.getAllSubIndutriyMapping(payload);

    console.log(" subindustry->>>>", this.selectedSubIndustryList);
  }







}
