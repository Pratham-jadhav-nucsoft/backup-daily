import { Component, OnInit } from '@angular/core';
import {  ElementRef, EventEmitter, Output, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-import',
  templateUrl: './import.component.html',
  styleUrls: ['./import.component.css']
})
export class ImportComponent implements OnInit {

  selectedFile: File | null = null;
  @Output() importedData = new EventEmitter<any>();
  onImportClick(): void {
    // ... Handle import logic ...
    // Once the data is processed, emit it to the parent component
    this.importedData.emit(/* Processed Data Here */);

    // this.dialogRef.close();
  }
  open() {
    throw new Error('Method not implemented.');
  }

  constructor() { }

  ngOnInit(): void {
  }

}
