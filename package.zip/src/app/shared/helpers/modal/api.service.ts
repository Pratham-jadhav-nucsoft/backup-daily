import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
// import { GlobalUrlDirective } from "src/app/shared/helpers/modal/global-url";
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
@Injectable({
  providedIn: 'root',
})
export class ApiService {
  // private baseUrl = GlobalUrlDirective.gateway + '/branch'; // Forming the complete API URL


  constructor(private http: HttpClient) { }

  public getAllDetails(url: any) {
    return this.http.get<any>(url);
  }


  public getDetailsPagination(url: string, pageNumber: number, pageSize: number) {
    return this.http.get<any[]>(`${url}?pageNumber=${pageNumber}&pageSize=${pageSize}`, {});
  }


  postAllDetails(url: string, payload: any): Observable<any> {
    return this.http.post<any>(url, payload);
  }


}


