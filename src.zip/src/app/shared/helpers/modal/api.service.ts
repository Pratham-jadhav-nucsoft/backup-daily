import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
// import { GlobalUrlDirective } from "src/app/shared/helpers/modal/global-url";
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
@Injectable({
  providedIn: 'root',
})
export class ApiService {
  // private baseUrl = GlobalUrlDirective.gateway + '/branch'; // Forming the complete API URL


  constructor(private http: HttpClient) { }

  public getAllDetails(url: any) {
    return this.http.get<any>(url);
  }

//for edit
  // getDetailsById(url: string, api_id: any) {
  //   return this.http.get<any[]>(url +'?fundSourceId=' +api_id, { });
  // }

  getDetailsById(url: string, api_id: any) {
    return this.http.get<any[]>(url + '?fundSourceId=' +api_id, { });
  }


//used for sequence
  getAllSequence(url: any) {
    return this.http.get<any>(url);
  }


  public getDetailsPagination(url: string, pageNumber: number, pageSize: number) {
    return this.http.get<any[]>(`${url}?pageNumber=${pageNumber}&pageSize=${pageSize}`, {});
  }

  getDetailsByPincodeId(ifscId: any): Observable<any[]> {
    const url = `${GlobalUrlService.autopopulate}?ifscId=${ifscId}`;
    return this.http.get<any[]>(url);
  }

  postAllDetails(url: string, payload: any): Observable<any> {
    return this.http.post<any>(url, payload);
  }
  
  getExport(url: any): Observable<any> {
    console.log('Calling getExport Method with apiservices:', url);
    return this.http.get(url);
  }

  public deleteById(url: string, id: number)  { // use this method when you need to delete data with api id
    console.log(url+"/"+id);
    return this.http.delete(`${url}/${id}`);
  }

  downloadTemplate(): Observable<Blob> {
    return this.http.get(GlobalUrlService.template, { responseType: 'blob' });
  }



  //import
  
  uploadFile(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    console.log("daaaaataaaaaaaaaaa saved api")
    return this.http.post(GlobalUrlService.imports, formData);
  }

}


