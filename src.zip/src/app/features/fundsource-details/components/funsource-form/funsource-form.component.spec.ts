import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FunsourceFormComponent } from './funsource-form.component';

describe('FunsourceFormComponent', () => {
  let component: FunsourceFormComponent;
  let fixture: ComponentFixture<FunsourceFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FunsourceFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FunsourceFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
