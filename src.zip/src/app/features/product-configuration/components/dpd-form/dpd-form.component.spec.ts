import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DpdFormComponent } from './dpd-form.component';

describe('DpdFormComponent', () => {
  let component: DpdFormComponent;
  let fixture: ComponentFixture<DpdFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DpdFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DpdFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
