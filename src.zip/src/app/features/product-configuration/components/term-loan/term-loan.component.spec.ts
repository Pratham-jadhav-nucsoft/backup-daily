import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TermLoanComponent } from './term-loan.component';

describe('TermLoanComponent', () => {
  let component: TermLoanComponent;
  let fixture: ComponentFixture<TermLoanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TermLoanComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TermLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
