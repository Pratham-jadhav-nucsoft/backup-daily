
import { Component, OnInit, ViewChild } from '@angular/core';
import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { HttpClient } from '@angular/common/http';
import { ApiFacadeService } from 'src/app/features/facade';
import { MatDialog ,MatDialogModule} from '@angular/material/dialog';
import { DialogboxComponent } from 'src/app/shared/helpers/dialogbox/dialogbox.component';
import { ImportComponent } from 'src/app/shared/helpers/import/import.component';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { FullscreenOverlayContainer } from '@angular/cdk/overlay';
import { MatDialogRef,MAT_DIALOG_DATA } from '@angular/material/dialog';
import { event } from 'jquery';
import { Router } from '@angular/router';


@Component({
  selector: 'app-fundsource-list',
  templateUrl: './fundsource-list.component.html',
  styleUrls: ['./fundsource-list.component.css'],

})
export class FundsourceListComponent implements OnInit {
  // @ViewChild(DialogboxComponent)
  // dialogBox!: DialogboxComponent;

  columnDefinitions1: Column[] = [];
  gridOptions1: GridOption;
  dataset1!: any[];
 
 
  page = 1;
  pageSize = 10;

  currentPage = 1;

  
 fundsources:any=[];
  angularGrid: any;

  constructor(private http: HttpClient,public apiService:ApiFacadeService,public dialog: MatDialog ,public api:ApiService, private router: Router ) {
    this.gridOptions1 = {
      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 500,
      gridWidth: 1500,
      enableFiltering: true, 
      enableCellNavigation: true, // Enable cell navigation to handle click events
    };
  }
  paginationConfigForListGrid: any = {
    totalItems: 0,
    itemsPerPage: 10,
    currentPage: 1,
    
  };

 

  ngOnInit(): void {

    
    this.columnDefinitions1 = [
      { id: 'Sequence', name: 'Sequence', field: 'Sequence', filterable: true, formatter: this.numberAlignFormatter,  maxWidth: 80,sortable: true },
      { id: 'Account Number', name: 'Account Number', field: 'Account Number',filterable: true,  maxWidth: 140,formatter: this.numberAlignFormatter, sortable: true },
      { id: 'Account Name', name: 'Account Name', field: 'Account Name',filterable: true,maxWidth: 140 ,formatter: this.textAlignFormatter, sortable: true },
      { id: 'BankName', name: 'BankName', field: 'BankName',filterable: true,maxWidth: 150,formatter: this.textAlignFormatter, sortable: true },
      { id: 'Branch Name', name: 'Branch Name', field: 'Branch Name',filterable: true,maxWidth: 120,formatter: this.textAlignFormatter, sortable: true },
      { id: 'Description', name: 'Description', field: 'Description',filterable: true,maxWidth: 250,formatter: this.textAlignFormatter,sortable: true },
      { id: 'IFSC Code', name: 'IFSC Code', field: 'IFSC Code',filterable: true,maxWidth: 120,formatter: this.numberAlignFormatter, sortable: true },
      { id: 'Address', name: 'Address', field: 'Address',filterable: true,maxWidth: 250,formatter: this.textAlignFormatter, sortable: true },
      { id: 'Phone Number', name: 'Phone Number', field: 'Phone Number',filterable: true,formatter: this.numberAlignFormatter, sortable: true },
      {
        id: 'action',
        
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
       
        formatter: Formatters.editIcon
      },
      {
        id: 'delete',
        name: 'Action',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
         
          this.openDialog();
          
        },
        formatter: Formatters.deleteIcon
      },
      {
        id: 'clone',
         
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        formatter: this.cloneIconFormatter ,// Use the custom formatter function
        onCellClick: (e: Event, args: OnEventArgs) => {
         
          this.router.navigateByUrl('/funsource-form');
          
        },
      }
    ];

    this.getAllFundSource(this.currentPage, this.pageSize);   
  }


  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable"  style="cursor: pointer;"></i> `;
  }

  numberAlignFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<div style="text-align: right;">${value}</div>`;
  }
  
 
   textAlignFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<div style="text-align: left;">${value}</div>`;
  }

  handleCellClick(event: Event, args: any): void {
    const actionColumnId = 'clone';
    if (args.cell === this.columnDefinitions1.findIndex((c) => c.id === actionColumnId)) {
      this.cloneItem(args.row); // Handle the clone action, you can implement your own logic here
    }
  }
  
  cloneItem(row: number): void {
    console.log('Clone icon clicked on row:', row);
    // Implement your logic for the cloning operation here
  }


  pageChange(page: number): void {
    this.currentPage = page;
  }

  addNewUser(): void {
    // Add your logic for adding a new user here
  }

  openDialog(){ 

    this.dialog.open(DialogboxComponent, {      })
   }

   openDialog2(){ 

    this.dialog.open(ImportComponent, {      })
   }
 async getAllFundSources()
 {
  this.fundsources = await this.apiService.getAllFundSource();
 
  console.log('hello',this.fundsources);
 }


 async getAllFundSource(pageNumber: number, pageSize: number) {
  console.log('inside getAllBranchs facade')
  return new Promise(resolve => {
    return this.api.getDetailsPagination(GlobalUrlService.fundsource, pageNumber, pageSize).subscribe((res: any) => {
      console.log("ress==>", res);

      this.fundsources = res.data;
      console.log("this.branches", this.fundsources);

      this.fundsources.forEach((item: { id: any; }, index: number) => {
        item.id = index + 1;
      });
      this.dataset1 = this.fundsources;
      console.log("this.branches==", this.dataset1);

      console.log("branches==========", this.fundsources);
      resolve(this.fundsources);
    });
  })

}
}