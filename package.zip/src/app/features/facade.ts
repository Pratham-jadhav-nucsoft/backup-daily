import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
// import { GlobalUrlDirective } from 'src/app/shared/helpers/modal/global-url';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url'; 
@Injectable({
    providedIn: 'root',
  })
  export class ApiFacadeService {
    constructor(private apiService: ApiService) {}
  
    async getAllFundSource() {
        return new Promise(resolve => {
                return  this.apiService.getAllDetails(GlobalUrlService.fundsource).subscribe(res => {
                    resolve(res);
                    console.log(res);
                    console.log('console running')
                  });
                });
    }

    
    async getAllBanks() {
      return new Promise(resolve => {
               return this.apiService.getAllBank  (GlobalUrlService.bank).subscribe(res => {
                  resolve(res);
                  console.log(res);
                  console.log('console running')
                });
              });
  }

  async getAllState() {
    return new Promise(resolve => {
            return  this.apiService.getAllBank  (GlobalUrlService.state).subscribe(res => {
                resolve(res);
                console.log(res);
                console.log('console running')
              });
            });
}

  }