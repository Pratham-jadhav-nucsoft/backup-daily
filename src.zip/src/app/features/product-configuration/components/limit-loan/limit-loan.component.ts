import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-limit-loan',
  templateUrl: './limit-loan.component.html',
  styleUrls: ['./limit-loan.component.css']
})
export class LimitLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  
  limitForm!: FormGroup;
  
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.limitForm = this.formBuilder.group({
      productDescription: [''],
      manageFeeBasedOnLoan: [false]
    
      // Add more form controls as needed
    });
  }

  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }
  
  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }


}
