import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AngularSlickgridModule } from 'angular-slickgrid';
import { AppRoutingModule } from './app-routing.module';
import { MatIconModule } from '@angular/material/icon';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FundsourceListComponent } from './features/fundsource-details/components/fundsource-list/fundsource-list.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { MatExpansionModule } from '@angular/material/expansion';
import { NgSelectModule } from '@ng-select/ng-select';
import { MatDialogRef } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { FundsourceDetailsModule } from './features/fundsource-details/fundsource-details.module';
import { ReactiveFormsModule } from '@angular/forms';
import {MatTooltipModule} from '@angular/material/tooltip';
import { FundsourceFormComponent } from './features/fundsource-details/components/fundsource-form/fundsource-form.component';
import { ToastrModule } from 'ngx-toastr';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
// import { DeleteConfirmationDialogComponent } from './features/fundsource-details/components/fundsource-list/delete-confirmation-dialog.component';
import { FormsModule } from '@angular/forms';
import {MatTabsModule} from '@angular/material/tabs';
import { ProductconfigurationFormComponent } from './features/product-configuration/components/productconfiguration-form/productconfiguration-form.component';
import { DialogboxComponent } from './shared/helpers/dialogbox/dialogbox.component';
import { FileStatusComponent } from './shared/helpers/file-status/file-status.component';
import { TermLoanComponent } from './features/product-configuration/components/term-loan/term-loan.component';
import { LimitLoanComponent } from './features/product-configuration/components/limit-loan/limit-loan.component';
MatDialogRef
@NgModule({

  declarations: [
    AppComponent,
    TermLoanComponent,
    LimitLoanComponent,
    FundsourceListComponent,
    DialogboxComponent,
    FundsourceFormComponent,
    FileStatusComponent,
    ProductconfigurationFormComponent
    // DeleteConfirmationDialogComponent,


  ],
  imports: [
    BrowserModule,
    MatTooltipModule,
    CommonModule,
    ToastrModule.forRoot(),
    MatTabsModule,

    MatAutocompleteModule,
    MatCardModule, 
    NgSelectModule,
    MatCheckboxModule,
    ReactiveFormsModule,
    MatSlideToggleModule,
    MatDatepickerModule,
    MatInputModule,
    MatDialogModule,
    MatRadioModule,
    CdkAccordionModule,
    MatSelectModule,
    MatFormFieldModule,
    AppRoutingModule,
    HttpClientModule,
    AngularSlickgridModule.forRoot({}),
    MatIconModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatExpansionModule,
    NgxPaginationModule,
    MatPaginatorModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    FormsModule,
  ],
  exports: [
    AngularSlickgridModule,
    FormsModule,
    ReactiveFormsModule,


  ],
  // entryComponents: [
  //   DeleteConfirmationDialogComponent
  // ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

