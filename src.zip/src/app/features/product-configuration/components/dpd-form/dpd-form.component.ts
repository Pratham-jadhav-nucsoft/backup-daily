import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dpd-form',
  templateUrl: './dpd-form.component.html',
  styleUrls: ['./dpd-form.component.css']
})
export class DpdFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
