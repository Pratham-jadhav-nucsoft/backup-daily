
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';

@Component({
  selector: 'app-term-loan',
  templateUrl: './term-loan.component.html',
  styleUrls: ['./term-loan.component.css']
})
export class TermLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;

  termForm!: FormGroup;
  rowFormArray!: FormArray;
  lastAddedRowIndex: number = -1;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.termForm = this.formBuilder.group({
     
      isManagedFeeBasedLoanAmount: [false],
      // ticketSizeMin:[null,[Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      // ticketSizeMax:[null,[this.maxValidator('min'),Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      ticketSizeMax: [null, [this.maxValidator('ticketSizeMin'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      ticketSizeMin: [null, [this.minValidator('ticketSizeMax'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

      maxCustomerIdExposure: [null, [this.maxValidator('minCustomerIdExposure'), Validators.minLength(1), Validators.maxLength(15)]],
      minCustomerIdExposure: [0, [this.maxValidator('maxCustomerIdExposure'), Validators.minLength(1), Validators.maxLength(15)]],
      maxTenure: [null, [this.maxValidator('minTenure'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minTenure: [null, [this.minValidator('maxTenure'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],

      maxAdvanceAmount: [null, [this.maxValidator('minAdvanceAmount'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      minAdvanceAmount: [null, [this.minValidator('maxAdvanceAmount'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

      maxAprPercentage: [null, [this.maxValidator('minAprPercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minAprPercentage: [null, [this.minValidator('maxAprPercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],

      maxProcessingFeePercentage: [null, [this.maxValidator('minProcessingFeePercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minProcessingFeePercentage: [null, [this.minValidator('maxProcessingFeePercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      amtmax0: [null, Validators.required],
      amtmin0: [null, Validators.required],
      maxProcessingFeePercentage0: [null, Validators.required],
      minProcessingFeePercentage0: [null, Validators.required],
      interestCode: [null, Validators.required],
      interestMethodCode: [null, Validators.required],
      isBalanceTransferred: [false],
      isOverrideEligibility: [false],
      isFreeInsuranceAllowed: [false],
     

      listOfTermCommercialConfig: this.formBuilder.array([

      ]),
      // Add more form controls as needed
    });
   
    this.rowFormArray = this.termForm.get('rows') as FormArray;
    this.addContactDetails();
  }

  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }

  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }

  maxValidator(minControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const minControl = control.parent?.get(minControlName);
      if (minControl && control.value !== null && minControl.value !== null) {
        const min = +minControl.value;
        const max = +control.value;

        if (max <= min) {
          return { maxError: true };
        }
      }

      return null;
    };
  }
  get contactDetails() {
    return this.termForm.get("listOfTermCommercialConfig") as FormArray;
  }
  minValidator(maxControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const maxControl = control.parent?.get(maxControlName);
      if (maxControl && control.value !== null && maxControl.value !== null) {
        const min = +control.value;
        const max = +maxControl.value;

        if (min >= max) {
          return { minError: true };
        }
      }

      return null;
    };
  }



  lessThanHundred(control: AbstractControl): ValidationErrors | null {
    const value = +control.value; // Convert to number
    if (value >= 100) {
      return { lessThanHundred: true };
    }
    return null;
  }

  isManageFeeCheckboxDisabled(): boolean {
    const ticketSizeMin = this.termForm.get('ticketSizeMin')?.value;
    const ticketSizeMax = this.termForm.get('ticketSizeMax')?.value;
    return !(ticketSizeMin !== null && ticketSizeMax !== null && ticketSizeMin !== '' && ticketSizeMax !== '');
  }

  addContactDetails() {


    const termLoanCommercialProcessingFeeConfig = this.formBuilder.group({
      amtmin1: ['',[this.minValidator('amtmax1'),Validators.required]],
      amtmax1: ['',[this.maxValidator('amtmin1'),Validators.required]],
      minProcessingFeePercentage1: ['',[this.minValidator('maxProcessingFeePercentage1'),Validators.required]],
      maxProcessingFeePercentage1: ['',[this.maxValidator('minProcessingFeePercentage1'),Validators.required]],
    });

    this.contactDetails.push(termLoanCommercialProcessingFeeConfig);
    this.lastAddedRowIndex = this.contactDetails.length - 1; // Update lastAddedRowIndex
  }

  addArray(i: any) {
    console.log('aaaaaa', +this.contactDetails.at(i).get('amtmax1')?.value)
    if (+this.termForm.value.ticketSizeMax != +this.contactDetails.at(i).get('amtmax1')?.value) {
      // if (this.termForm.value.ticketSizeMax.valid&&this.termForm.value.ticketSizeMin.valid) {
      //  this.addContactDetails();
      // } else {
      //  console.log('Please fill the current row first');
      //  }
      if (this.contactDetails.at(i).valid) {
        console.log('all fields valid');
        this.addContactDetails();
      } else {
        console.log('invalid field');

      }
     
    }
    else {
      console.log('max amount reached');
    }
  }





  deleteDetails(contactIndex: number) {
    this.contactDetails.removeAt(contactIndex);

    if (contactIndex === this.lastAddedRowIndex) {
      if (this.contactDetails.length === 0) {
        this.lastAddedRowIndex = -1; // No rows left
      } else {
        this.lastAddedRowIndex = this.contactDetails.length - 1; // Update to the new last row index
      }
    }
  }


  // form array
  addRow() {
    this.rowFormArray.push(this.createRowFormGroup());
  }
  // removeRow(index: number) {
  //   this.rowFormArray.removeAt(index);
  // }
  createRowFormGroup() {
    return this.formBuilder.group({
      min: [null, Validators.required],
      max: [null, Validators.required],
      // ... other controls
    });
  }
}
