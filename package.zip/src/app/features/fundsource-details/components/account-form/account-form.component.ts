import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { FormControl, } from '@angular/forms';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

import { startWith, map } from 'rxjs/operators';
import { ApiFacadeService } from 'src/app/features/facade';
@Component({
  selector: 'app-account-form',
  templateUrl: './account-form.component.html',
  styleUrls: ['./account-form.component.css']
})
export class AccountFormComponent implements OnInit {
  accountForm!: FormGroup;
  today: Date;
  

  
  constructor(private formBuilder: FormBuilder) {
    this.today = new Date();
  }
 

  ngOnInit(): void {
    this.accountForm= this.formBuilder.group({
      accounttype:[null,Validators.required],
      accountName:[null,Validators.required],
      accountNumber:[null,Validators.required],
      startDate: [null, [Validators.required, this.minDateValidator()]],
      endDate: [null, [Validators.required, this.futureDateValidator]],
      // userNumber:[null,Validators.required],
      // inputNumber:[null,Validators.required],
      // creditLimit:[null,,Validators.required]
    })
  }
  minDateValidator() {
    return (control: any) => {
      const selectedDate = control.value;
      return selectedDate && selectedDate < this.today ? { invalidDate: true } : null;
    };
  }
  futureDateValidator() {
    return (control: any) => {
      const selectedDate = control.value;
      return selectedDate && selectedDate < this.today ? { invalidDate: true } : null;
    };
  }
   

}
