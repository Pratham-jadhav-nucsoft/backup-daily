import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
// import { GlobalUrlDirective } from 'src/app/shared/helpers/modal/global-url';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { ToastrService } from 'ngx-toastr';
@Injectable({
  providedIn: 'root',
})
export class ApiFacadeService {
  deletedData: any;
  constructor(private apiService: ApiService, public toastr: ToastrService) { }

  async getAllFundSource() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.fundsource).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }


  //   async getAllBanks() {
  //     return new Promise(resolve => {
  //              return this.apiService.getAllBank  (GlobalUrlService.bank).subscribe(res => {
  //                 resolve(res);
  //                 console.log(res);
  //                 console.log('console running')
  //               });
  //             });
  // }

  async getAllState() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.state).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running(facade layer)')
      });
    });
  }

  exportData(): Observable<any> {
    const exportUrl = GlobalUrlService.export;
    return this.apiService.getExport(exportUrl);
  }
  async getAllCity() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.city).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllPincode() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.pincode).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllCountry() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.country).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllBankIFSC() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.bankifsc).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllBankName() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.bankname).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }

  async getAllAccountType() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.accounttype).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }


  async getBranchByIdPincode(id: number) {
    return new Promise(resolve => {
      return this.apiService.getDetailsById(GlobalUrlService.autopopulate, +id).subscribe(
        (res: any) => {
          resolve(res);
          console.log(res);
        },
        (error: any) => {
          // Handle error here
          console.error('Error while fetching data by ID:', error);
          resolve(null); // Return null or handle the error case as needed
        }
      );
    });
  }


  postCityDetails(payload: any) {
    return new Promise(resolve => {
      this.apiService.postAllDetails(GlobalUrlService.post, payload).subscribe(res => {
        resolve(res);
        console.log(res);
      });
    });
  }


  deleteItemById(fundSourceId: number) {
    console.log("this.apis_id=====>", fundSourceId);
    return new Promise(resolve => {
      this.apiService.deleteById(GlobalUrlService.delete, fundSourceId).subscribe(res => {
        this.deletedData = res;
        console.log("data", this.deletedData);
        resolve(res);
      });
    });

  }

  async getFundSourceById(id: number) {
    return new Promise(resolve => {
      return this.apiService.getDetailsById(GlobalUrlService.edit, +id).subscribe(
        (res: any) => {
          resolve(res);
          console.log(res);
        },
        (error: any) => {
          // Handle error here
          console.error('Error while fetching data by ID:', error);
          resolve(null); // Return null or handle the error case as needed
        }
      );
    });
  }


  async getNextSequence() {
    return new Promise(resolve => {
      return this.apiService.getAllSequence(GlobalUrlService.sequence).subscribe(res => {
        resolve(res);
        console.log("ggggggggggg", res);
      });
    });
  }


  downloadTemplate(): Observable<Blob> {
    return this.apiService.downloadTemplate();
  }


  // async getFundSourceById(id: number) {
  //   return new Promise(resolve => {
  //     return this.apiService.getDetailsById(GlobalUrlService.edit, +id).subscribe(
  //       (res: any) => {
  //         resolve(res);
  //         console.log(res);
  //       },
  //       (error: any) => {
  //         // Handle error here
  //         console.error('Error while fetching data by ID:', error);
  //         resolve(null); // Return null or handle the error case as needed
  //       }
  //     );
  //   });
  // }




  //import
  uploadFile(file: File): Promise<any> {
    console.log("facade apiiiiiiiiii")
    return new Promise((resolve, reject) => {
      this.apiService.uploadFile(file).subscribe(
        (response: any) => {
          resolve(response);
        },
        (error: any) => {
          reject(error);
        }
      );
    });
  }


  postProductDetails(finalPayload: any) {
    return new Promise(resolve => {
      this.apiService.postAllProduct(GlobalUrlService.create, finalPayload).subscribe(res => {
        resolve(res);
        console.log(res);
      });
    });
  }


  async getAllCompany() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.company).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllProductType() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.productType).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllIndustry() {
    return new Promise(resolve => {
      console.log("hello");
      
      return this.apiService.getAll(GlobalUrlService.industry).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
  
      
    });
  
    
  }
  async getAllSubIndustry() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.subindustry).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllCategory() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.category).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllInterest() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.interest).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllODE() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.ode).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllinterestCalMethod() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.icm).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getMinimumAccountDueCalculationMethod() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.madcm).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getPenalInterestCalculationMethod() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.picm).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running');

      });
    });
  }
  async getAllBranch() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.branch).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllInterestMethod() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.interestmethod).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }

  async getAllStatementCycle() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.stmtcycle).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllParentProduct() {
    return new Promise(resolve => {
      return this.apiService.getAll(GlobalUrlService.parentproduct).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllSubIndutriyMapping(selectedId: any) {
    return new Promise(resolve => {
      return this.apiService.postAllDetails(GlobalUrlService.subindustrymapping, selectedId).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running---------------->subindsutry')
      });
    });
  }


  async getProductById2(id: number) {
    return new Promise(resolve => {
      return this.apiService.getProductById(GlobalUrlService.patch, +id).subscribe(
        (res: any) => {
          resolve(res);
          console.log(res);
        },
        (error: any) => {

          console.error('Error while fetching data by ID:', error);
          resolve(null);
        }
      );
    });
  }
  //slivkgrid
  async getAllProductlist() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.slick).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }


  deleteProductById(productId: number) {
    console.log("this.apis_id=====>", productId);
    return new Promise(resolve => {
      this.apiService.deleteById(GlobalUrlService.deleted, productId).subscribe(res => {
        this.deletedData = res;
        console.log("data", this.deletedData);
        resolve(res);
      });
    });

  }














































}


