

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

import { startWith, map } from 'rxjs/operators';
import { ApiFacadeService } from 'src/app/features/facade';
@Component({
  selector: 'app-banking-form',
  templateUrl: './banking-form.component.html',
  styleUrls: ['./banking-form.component.css'],

})
export class BankingFormComponent implements OnInit {
  bankingForm!: FormGroup;
  inputValue = new FormControl();
  // Use the '!' non-null assertion operator to tell TypeScript that the property will be assigned before it is used
  filteredOptions!: Observable<string[]>;
  toastr: any;
  bank: any;
  cityary: any = [];
  stateary: any = [];
  pinary: any = [];

  conarr: any=[];

  constructor(private formBuilder: FormBuilder, private http: HttpClient, public apiService: ApiFacadeService,) {
    // this.filteredOptions = this.inputValue.valueChanges.pipe(
    //   startWith(''),
    //   map(value => this._filter(value))
    // );
  }

  ngOnInit() {
    this.bankingForm = this.formBuilder.group({
      companyName: [null, Validators.required],
      branchName: [null, Validators.required],
      pincode: [null, Validators.required],
      // country: [null, Validators.required],
      country: [null, Validators.required],

      stdCode: [null, Validators.required],
      mobileNumber: [null, Validators.required],
      IFSC: [null, Validators.required],
      branchCode: [null, Validators.required],
      city: [null, Validators.required],
      address: [null, Validators.required],
      faxNumber: [null, Validators.required],
      emailId: [null, [Validators.required, Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)]],
      bankName: [null, Validators.required],
      micr: [null, [Validators.required, Validators.pattern('^[0-9]+$')]],
      state: [null, Validators.required],
      phoneNumber: [null, Validators.required],
      relationshipPerson: [null, Validators.required]
    });
    this.bankingForm.addControl('branchNameIcon', new FormControl());
    // this.filteredOptions = this.inputValue.valueChanges.pipe(
    //   startWith(''),
    //   map(value => this._filter(value))
    // );

    this.getAllPin();
    this.getAllState2();
    this.getAllCities();
    this.getAllCon();
  }



  // private _filter(value: string): string[] {
  //   const filterValue = value.toLowerCase();
  //   // Replace the options below with your actual list of IFSC codes
  //   const options: string[] = [
  //     'IFSC0001234',
  //     'IFSC0005678',
  //     'IFSC0009012',
  //     // Add other IFSC codes as needed...
  //   ];
  //   return options.filter(option => option.toLowerCase().includes(filterValue));
  // }

  onSubmit() {
    if (this.bankingForm && this.bankingForm.valid) {
      // Form is valid, perform form submission logic here
      // For example, you can send the form data to your backend API
      console.log(this.bankingForm.value);
      // Reset the form after successful submission
      this.bankingForm.reset();
    } else {
      // Form is invalid, handle validation errors here or show error messages

      // Set the value of the branchNameIcon control based on the validity of the branchName field
      // Form is invalid, handle validation errors here or show error messages
      // Set the value of the branchNameIcon control based on the validity of the branchName field
      this.bankingForm.controls['branchNameIcon'].setValue(this.bankingForm.controls['branchName'].valid);
    }
  }
  get f() {
    return this.bankingForm.controls;
  }
  //  async getAllBanks()
  //  {
  //   this.bank = await this.apiService.getAllBanks();

  //   console.log(this.bank);
  //  }

  async getAllCities() {
    this.cityary = await this.apiService.getAllCity();

    console.log(" Cities->>>>", this.cityary);
  }


  async getAllState2() {
    this.stateary = await this.apiService.getAllState();
    console.log("this.state", this.stateary);
  }


  async getAllPin() {
    this.pinary = await this.apiService.getAllPincode();
    console.log("this.pin", this.pinary);
  }

  async getAllCon() {
    // const country = await this.apiService.getAllCountry();
 
    // console.log("country==>", this.country);

    // console.log("this.country", this.country);
    this.conarr=await this.apiService.getAllCountry();
    console.log("this.country",this.conarr);
  }

  // countryDropDown() {
  //   this.getAllCon();
  // }


}
