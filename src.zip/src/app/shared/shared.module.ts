import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImportComponent } from './helpers/import/import.component';
import { BackdialogComponent } from './helpers/backdialog/backdialog.component';




@NgModule({
  declarations: [
 
  
    ImportComponent,
         BackdialogComponent
  ],
  imports: [
    CommonModule
  ]
})
export class SharedModule { }
