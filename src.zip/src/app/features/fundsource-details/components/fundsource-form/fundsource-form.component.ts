import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { HttpClient } from '@angular/common/http';
import { ApiFacadeService } from 'src/app/features/facade';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { BackdialogComponent } from 'src/app/shared/helpers/backdialog/backdialog.component';
@Component({
  selector: 'app-fundsource-form',
  templateUrl: './fundsource-form.component.html',
  styleUrls: ['./fundsource-form.component.css']
})
export class FundsourceFormComponent implements OnInit {
  bankingForm!: FormGroup;
  listOfCompany: any = [];
  listOfIfsc: any = [];
  listOfAccountType: any = [];
  selectedBankName: any = [];
  selectedState: any = [];
  selectedCountry: any = [];
  listOfPincode: any = [];
  selectedCity: any = [];
  createdBy: any;
  createdDate: any;
  phoneNumber: any;
  fundSourceId: any;
  fundSourceCode: any;
  formSubmitted: any;
  formSaved: any;
  createBranch: any;
  fundSourceData: any;
  params: any;

  listOfIfscForEdit:any;
  num: unknown;
  constructor(private formBuilder: FormBuilder,private router: Router,public activate:ActivatedRoute,private toastr: ToastrService, private http: HttpClient, public apiService: ApiFacadeService,public dialog: MatDialog,)
   {

    this.activate.queryParams.subscribe(params => {
      this.params = params;
      console.log("this.params", this.params);
    })
  


    }
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  isFormCollapsed3: boolean = true;
  ngOnInit(): void {
    this.bankingForm = this.formBuilder.group({
      // companyId: [null, Validators.required],
      bankBranchName: [null, Validators.required],
      pincodeId: [null, Validators.required],
      
      countryId: [null, Validators.required],
      bankId: [null,],
      phoneStdCode: [null,  Validators.pattern('^[0-9]{1,4}$')],
      mobileNumber: [null,  Validators.pattern('^[0-9]{1,10}$')],
      ifscId: [null, Validators.required],
      bankBranchCode: [null, ],
      cityId: [null, Validators.required],
      address: [null],
      faxNumber: [null,Validators.pattern('^[0-9]{1,10}$')],
      emailId: [null,  Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)],
      micrCode: [null, [Validators.required, Validators.pattern('^[0-9]+$')]],
      stateId: [null, Validators.required],
      phoneNumber: [null,[ Validators.pattern('^[0-9]*$'),Validators.max(8)]],
      relationshipPerson: [null,Validators.pattern('^[A-Za-z -]{1,20}$')],
      accountTypeCode: [null, Validators.required],
      accountName: [null, Validators.required],
      accountNumber: [null, Validators.required],
      userNumber: [null,[Validators.required,Validators.pattern('^[0-9]{1,7}$')] ],
      userName: [null,[Validators.required,]],
      esctTapeInputNumber: [null, ],
      ledgerFolioNumber: [null, ],
      creditItemLimit: [null, ],
      creditReference: [null,],
      description: [null, ],
      sequence: [null, Validators.required],
      isRestricted: [false],
      isExcluded: [false],
      fromDate: [null, Validators.required],
      toDate: [null ],
      isActive: [false],
      isAnchorTagged: [false],

    });
    this.getAllCities();
    this.getAllStates();
    this.getAllCountries();
    this.getAllPincodes();
    this.getAllBankIFSCs();
    this.getAllBankNames();

    this.getAllAccountTypes();
    this.getFundSourcesById();


    this.getNextSequen();

  }
  
    saveForm(param: any) : void{
      if (this.bankingForm.valid) {

        console.log(this.bankingForm.value);
        this.createdBy="3fa85f64-5717-4562-b3fc-2c963f66afa6"
        this.createdDate="2023-08-01T04:18:41.349Z"
  
        this.fundSourceId=0
        this.fundSourceCode="helloworld"
        const payload=this.bankingForm.value
        payload.createdBy=this.createdBy
        payload.createdDate=this.createdDate
        payload.fundSourceId=this.fundSourceId
        payload.fundSourceCode=this.fundSourceCode
        
        console.log("payload",payload);
  
        if(this.params.selectedItemId && this.params.cloneFlag){
          this.listOfIfscForEdit={... this.bankingForm.value};
         const payload={...this.listOfIfscForEdit,selectedItemId:0,createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6"};
          console.log('Payload of Clone--->',payload);
        }
        this.apiService.postCityDetails(payload).then(() => {
          
        this.toastr.success('Form saved successfully!', 'Success');
      
        this.router.navigate(['/fundsource-list']);
       })
       .catch((error: { message: string; }) => {
          this.toastr.error('Error saving form: ' + error.message, 'Error');
        });
      } else {
        this.toastr.error('Please fill in all the required fields', 'Error');
      
    }
  }
//   saveForm(param: any) : void{
//     if (this.bankingForm.valid) {

//       console.log(this.bankingForm.value);
//       this.createdBy="3fa85f64-5717-4562-b3fc-2c963f66afa6"
//       this.createdDate="2023-08-01T04:18:41.349Z"

//       this.fundSourceId=0
//       this.fundSourceCode="helloworld"
//       const payload=this.bankingForm.value
//       payload.createdBy=this.createdBy
//       payload.createdDate=this.createdDate
//       payload.fundSourceId=this.fundSourceId
//       payload.fundSourceCode=this.fundSourceCode
      
//       console.log("payload",payload);

//       if(this.params.selectedItemId && this.params.cloneFlag){
//         this.listOfIfscForEdit={... this.bankingForm.value};
//        const payload={...this.listOfIfscForEdit,selectedItemId:0,createdBy: "3fa85f64-5717-4562-b3fc-2c963f66afa6"};
//         console.log('Payload of Clone--->',payload);
//       }
//       this.apiService.postCityDetails(payload).then(() => {
        
//       this.toastr.success('Form saved successfully!', 'Success');
    
//       this.router.navigate(['/fundsource-list']);
//      })
//      .catch((error: { message: string; }) => {
//         this.toastr.error('Error saving form: ' + error.message, 'Error');
//       });
//     } else {
//       this.toastr.error('Please fill in all the required fields', 'Error');
    
//   }
// }

 
 
  // get f() {
  //   return this.bankingForm.controls;
  // }
 
 
  saveAndContinueForm()  {
    if (this.bankingForm.valid) {
      console.log(this.bankingForm.value);
      this.toastr.success('Form saved successfully!', 'Success');
      this.formSubmitted = false;
      this.bankingForm.reset(); // Reset the form after saving
      // this.markControlsAsPristine(); // Mark all controls as pristine after reset
      this.formSaved = true; // Set the flag to true after successful save
    } else {
      this.toastr.error('Please fill in all the required fields.', 'Error');
      this.formSubmitted = true; // Set formSubmitted to true when saving with errors
    }
  }

  goBack() {
    const dialogRef = this.dialog.open(BackdialogComponent, {
      width: '250px',
    });
  
    dialogRef.afterClosed().subscribe((result: boolean) => {
      if (result) {
        this.router.navigate(['/fundsource-list']);
      }
    });
  }

  
  dateValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const selectedDate = new Date(control.value);
      const currentDate = new Date();
      currentDate.setHours(0, 0, 0, 0);

      if (selectedDate < currentDate) {
        this.toastr.error('Selected date cannot be in the past.', 'Invalid Date');
        return { 'invalidDate': true };
        }
      return null;
    };
  }

  getMinToDate(): Date | null {
    const fromDateControl = this.bankingForm.get('fromDate');
    if (fromDateControl && fromDateControl.value) {
      return new Date(fromDateControl.value);
    }
    return null;
  }



  openDialog() {

   
  
    console.log("Inside the dialog ");
    const dialogRef = this.dialog.open(BackdialogComponent, {
  
      width: '250px',
      
    })
  
  
    //  const result=this.box.onYesClick();

  }
// saveForm() {
//   if (this.bankingForm.valid) {
//     console.log(this.bankingForm.value);
//     this.createdBy="3fa85f64-5717-4562-b3fc-2c963f66afa6"
   
//     const payload=this.bankingForm.value
//     payload.createdBy=this.createdBy
  
//     console.log("payload",payload);

//     this.apiService.postCityDetails(payload).then(() => {
      
//       this.toastr.success('Form saved successfully!', 'Success');
//       this.router.navigate(['/city-list']);
//     }).catch((error: { message: string; }) => {
//       this.toastr.error('Error saving form: ' + error.message, 'Fail');
//     });
//   } else {
//     this.toastr.error('Fill the Form!', 'Fail');
//   }
// }


  async getAllCities() {
    this.selectedCity = await this.apiService.getAllCity();

    console.log(" Cities->>>>", this.selectedCity);
  }
  async getAllStates() {
    this.selectedState = await this.apiService.getAllState();

    console.log(" states->>>>", this.selectedState);
  }
  async getAllCountries() {
    this.selectedCountry = await this.apiService.getAllCountry();

    console.log(" countries->>>>", this.selectedCountry);
  }
  async getAllPincodes() {
    this.listOfPincode = await this.apiService.getAllPincode();

    console.log(" pincodes->>>>", this.listOfPincode);
  }
  async getAllBankIFSCs() {
    this.listOfIfsc = await this.apiService.getAllBankIFSC();

    console.log(" bank ifsc->>>>", this.listOfIfsc);
  }
  async getAllBankNames() {
    this.selectedBankName = await this.apiService.getAllBankName();

    console.log(" bank ifsc->>>>", this.selectedBankName);
  }
  async getAllAccountTypes() {
    this.listOfAccountType = await this.apiService.getAllAccountType();

    console.log(" bank ifsc->>>>", this.listOfAccountType);
  }


///edit form
async  getFundSourcesById() {
  console.log("inside listOfBranchForId",this.params.selectedItemId);

  if (this.params && this.params.selectedItemId) {

    this.fundSourceData = await this.apiService.getFundSourceById(this.params.selectedItemId);
  console.log("this.listOfbranchRecordForEdit===========", this.fundSourceData);
  this.createBranch = false;
this.bankingForm.patchValue({





  cityId: this.fundSourceData.cityId, //
  phoneStdCode: this.fundSourceData.phoneStdCode, //
  phoneNumber: this.fundSourceData.phoneNumber, //
  mobileNumber: this.fundSourceData.mobileNumber,//
  ifscId: this.fundSourceData.ifscId, //
  faxNumber: this.fundSourceData.faxNumber, //
  userNumber: this.fundSourceData.userNumber,//
  userName: this.fundSourceData.userName,//
  relationshipPerson: this.fundSourceData.relationshipPerson, //
  address: this.fundSourceData.address, //
  emailId: this.fundSourceData.emailId, //
  description: this.fundSourceData.description,//
  esctTapeInputNumber: this.fundSourceData.esctTapeInputNumber,//
  ledgerFolioNumber: this.fundSourceData.ledgerFolioNumber,//
  isRestricted:this.fundSourceData.isRestricted,//
  isExcluded:this.fundSourceData.isExcluded,//
  creditReference: this.fundSourceData.creditReference,//
  creditItemLimit: this.fundSourceData.creditItemLimit,//
  accountName: this.fundSourceData.accountName,//
  accountNumber: this.fundSourceData.accountNumber,//
  isAnchorTagged:this.fundSourceData.isAnchorTagged,//
  sequence: this.fundSourceData.sequence,//
  toDate:this.fundSourceData.toDate,//
  accountTypeCode:this.fundSourceData.accountTypeCode,///
  fromDate:this.fundSourceData.fromDate,//
  pincodeId:this.fundSourceData.pincodeId,//
  // isActive:this.fundSourceData.isActive,//
 

 
  
});
}
else {
  this.createBranch = true;
}
}


async getNextSequen() {
  this.num = await this.apiService.getNextSequence();
  console.log("this.sequence ", this.num);
  this.bankingForm.get("sequence")?.patchValue(this.num);
}



}
