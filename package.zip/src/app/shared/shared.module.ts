import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogboxComponent } from './helpers/dialogbox/dialogbox.component';



@NgModule({
  declarations: [
    DialogboxComponent
  ],
  imports: [
    CommonModule
  ]
})
export class SharedModule { }
