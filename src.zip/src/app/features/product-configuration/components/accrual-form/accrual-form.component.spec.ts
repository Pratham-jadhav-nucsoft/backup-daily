import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccrualFormComponent } from './accrual-form.component';

describe('AccrualFormComponent', () => {
  let component: AccrualFormComponent;
  let fixture: ComponentFixture<AccrualFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccrualFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AccrualFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
