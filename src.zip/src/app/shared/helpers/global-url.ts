import { OnInit, Directive } from '@angular/core';
import configJson from "src/assets/config/config.json";
import { Injectable } from '@angular/core';
@Directive()



@Injectable({
  providedIn: 'root',
})
export class GlobalUrlService implements OnInit {

  public static fundsource = configJson.gateWayUrl + '/fund-source/pagination';

  // public static bank = configJson.gateWayUrl + '/api/Master/get-all-bank';


  // dropdowns
  public static state = configJson.gateWayUrl + '/masters/get-all-state';
  public static city = configJson.gateWayUrl + '/masters/get-all-city';
  public static pincode = configJson.gateWayUrl + '/masters/get-all-pincode';
  public static country = configJson.gateWayUrl + '/masters/get-all-country';
  public static bankifsc = configJson.gateWayUrl + '/masters/get-all-ifsc';
  public static bankname = configJson.gateWayUrl + '/masters/get-all-bank';

  public static accounttype = configJson.gateWayUrl + '/masters/get-all-account-type';


  //edit
  public static edit = configJson.gateWayUrl + '/fund-source/fundSourceId';


  // post
  public static post = configJson.gateWayUrl + '/fund-source';


  /// delete
  public static delete = configJson.gateWayUrl + '/fund-source';

//sequence
  public static sequence = configJson.gateWayUrl+'/fund-source/max-sequence';

//autopopulate
  public static   autopopulate = configJson.gateWayUrl+'  /masters/get-all-ifsc';


//template
  public static   template = configJson.gateWayUrl+'/fund-source/sample';

//import
  public static   imports = configJson.gateWayUrl+'/fund-source/import';


//export 
  public static   export = configJson.gateWayUrl+'/fund-source';






  public static   create = configJson.gateWayUrl2+'/product';

  // dorpdowns
  public static   company = configJson.gateWayUrl2+'/product/company';
  
  public static   productType = configJson.gateWayUrl2+'/product/productType';
  public static   industry = configJson.gateWayUrl2+'/product/industry';
  public static   subindustry = configJson.gateWayUrl2+'/product/subIndustry';
  public static   subindustrymapping = configJson.gateWayUrl2+'/subIndustryFromIndustryId';





  public static  category = configJson.gateWayUrl2+'/product/category';
  
  public static  interest = configJson.gateWayUrl2+'/product/interest';
  public static  interestmethod = configJson.gateWayUrl2+'/product/interestMethod';
  public static  ode = configJson.gateWayUrl2+'/product/overDisbursedEvent';
  public static  icm = configJson.gateWayUrl2+'/product/interestCalculationMethod';
  public static  madcm = configJson.gateWayUrl2+'/product/minimumAccountDueCalculationMethod';
  public static  picm = configJson.gateWayUrl2+'/product/penalInterestCalculationMethod';
  public static  branch = configJson.gateWayUrl2+'/product/branch';
  public static  stmtcycle = configJson.gateWayUrl2+'/product/statementCycle';


  //getbyid
  public static  patch = configJson.gateWayUrl2+'/productId';
  public static  slick = configJson.gateWayUrl2+'/product/pagination';
  public static  deleted = configJson.gateWayUrl2+'/product';


  

  ngOnInit(): void {
  }
}

