import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PricingInputListComponent } from './pricing-input-list.component';

describe('PricingInputListComponent', () => {
  let component: PricingInputListComponent;
  let fixture: ComponentFixture<PricingInputListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PricingInputListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PricingInputListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
