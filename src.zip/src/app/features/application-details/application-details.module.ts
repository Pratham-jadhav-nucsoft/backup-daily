import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApplicationDetailsRoutingModule } from './application-details-routing.module';
import { ComponentComponent } from './component/component.component';


@NgModule({
  declarations: [
    ComponentComponent
  ],
  imports: [
    CommonModule,
    ApplicationDetailsRoutingModule
  ]
})
export class ApplicationDetailsModule { }
