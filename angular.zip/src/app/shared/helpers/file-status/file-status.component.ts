

// import { Component, OnInit } from '@angular/core';
// import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
// import { SlickgridComponent } from '../slickgrid/slickgrid.component';  

// @Component({
//   selector: 'app-file-status',
//   templateUrl: './file-status.component.html',
//   styleUrls: ['./file-status.component.css']
// })
// export class FileStatusComponent implements OnInit {
//    columnDefinitions1: Column[]=[];
//    gridOptions1!: GridOption;
//    dataset1: any[] = [];
   
//    columnDefinitions2: Column[]=[];
//    dataset2: any[] = [];
//    gridOptions2!: GridOption;

//   constructor() { }

//   ngOnInit(): void {
//     this.gridOptions1 = {
//       enableCellNavigation: true,
//       enableColumnReorder: false,
//       enableAutoResize: false,
//       enableFiltering: true,
//       enableSorting: true,
//     };
 

//   this.columnDefinitions1 = [
//     { id: 'sequence', name: 'Sequence', field: 'Sequence', filterable: true, sortable: true },
//     { id: 'city', name: 'City', field: 'City', filterable: true, sortable: true },
//     { id: 'citycode', name: 'City Code', field: 'City Code', filterable: true, sortable: true },
//     { id: 'state', name: 'State', field: 'State', filterable: true, sortable: true },
//     { id: 'region', name: 'Region', field: 'Region', filterable: true, sortable: true },
//     { id: 'country', name: 'Country', field: 'Country', filterable: true, sortable: true },
//     { id: 'description', name: 'Description', field: 'Description', filterable: true, sortable: true },
//   ]

//   this.dataset1 = [

//       { id: 1, sequence: 1, city: 'City 1', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf' },
//       { id: 2, sequence:2, city: 'city 2', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf'  }
//     ];


//     //--------------------------2------------------------------
//    this.gridOptions2 = {
//       enableCellNavigation: true,
//       enableColumnReorder: false,
//       enableAutoResize: false,
//       enableFiltering: true,
//       enableSorting: true,
//     };

//     this.columnDefinitions2 = [
//       { id: 'sequence', name: 'Sequence', field: 'Sequence', filterable: true, sortable: true },
//       { id: 'city', name: 'City', field: 'City', filterable: true, sortable: true },
//       { id: 'citycode', name: 'City Code', field: 'City Code', filterable: true, sortable: true },
//       { id: 'state', name: 'State', field: 'State', filterable: true, sortable: true },
//       { id: 'region', name: 'Region', field: 'Region', filterable: true, sortable: true },
//       { id: 'country', name: 'Country', field: 'Country', filterable: true, sortable: true },
//       { id: 'description', name: 'Description', field: 'Description', filterable: true, sortable: true },
//     ]
//     this.dataset2 = [
//       { id: 1, sequence: 1, city: 'City 1', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf' },
//       { id: 2, sequence:2, city: 'city 2', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf'  }

//     ];
// }

// angularGridReady(angularGrid: any): void {
  
// }

// }


import { Component, OnInit, ViewChild } from '@angular/core';
import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { SlickgridComponent } from '../slickgrid/slickgrid.component';  
import { MatTabChangeEvent } from '@angular/material/tabs';

@Component({
  selector: 'app-file-status',
  templateUrl: './file-status.component.html',
  styleUrls: ['./file-status.component.css']
})
export class FileStatusComponent implements OnInit {
   columnDefinitions: Column[]=[];
   gridOptions!: GridOption;
   listOfSuccessRecords: any[] = [];
   
   columnDefinitions2: Column[]=[];
   listOfFailureRecords: any[] = [];
   gridOptions2!: GridOption;
   successFileGridId: any = "success-file"
  failureFileGridId: any = "failure-file"
   isFailureTabActive: boolean=false;

   @ViewChild('tabGroup') tabGroup: any;

  constructor() { }

  ngOnInit(): void {
    this.gridOptions = {
      enableCellNavigation: true,
      enableColumnReorder: false,
      enableAutoResize: false,
      enableFiltering: true,
      enableSorting: true,
      gridHeight: 450,
      gridWidth: 1100,
    };
 

  this.columnDefinitions = [
    { id: 'sequence', name: 'Sequence', field: 'Sequence', filterable: true, sortable: true },
    { id: 'city', name: 'City', field: 'City', filterable: true, sortable: true },
    { id: 'citycode', name: 'City Code', field: 'City Code', filterable: true, sortable: true },
    { id: 'state', name: 'State', field: 'State', filterable: true, sortable: true },
    { id: 'region', name: 'Region', field: 'Region', filterable: true, sortable: true },
    { id: 'country', name: 'Country', field: 'Country', filterable: true, sortable: true },
    { id: 'description', name: 'Description', field: 'Description', filterable: true, sortable: true },
  ]

  this.listOfSuccessRecords = [

      { id: 1, sequence: 1, city: 'City 1', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf' },
      { id: 2, sequence:2, city: 'city 2', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf'  }
    ];


    //--------------------------2------------------------------
   this.gridOptions2 = {
      enableCellNavigation: true,
      enableColumnReorder: false,
      enableAutoResize: false,
      enableFiltering: true,
      enableSorting: true,
    };

    this.columnDefinitions2 = [
      { id: 'sequence', name: 'Sequence', field: 'Sequence', filterable: true, sortable: true },
      { id: 'city', name: 'City', field: 'City', filterable: true, sortable: true },
      { id: 'citycode', name: 'City Code', field: 'City Code', filterable: true, sortable: true },
      { id: 'state', name: 'State', field: 'State', filterable: true, sortable: true },
      { id: 'region', name: 'Region', field: 'Region', filterable: true, sortable: true },
      { id: 'country', name: 'Country', field: 'Country', filterable: true, sortable: true },
      { id: 'description', name: 'Description', field: 'Description', filterable: true, sortable: true },
    ]
    this.listOfFailureRecords = [
      { id: 1, sequence: 1, city: 'City 1', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf' },
      { id: 2, sequence:2, city: 'city 2', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf'  }

    ];
}

angularGridReady(angularGrid: any): void {
  
}

tabChanged(tabChangeEvent: MatTabChangeEvent): void {
  this.isFailureTabActive = !this.isFailureTabActive
}


}
