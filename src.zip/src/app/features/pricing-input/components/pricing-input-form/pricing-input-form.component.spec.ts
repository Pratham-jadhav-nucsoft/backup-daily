import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PricingInputFormComponent } from './pricing-input-form.component';

describe('PricingInputFormComponent', () => {
  let component: PricingInputFormComponent;
  let fixture: ComponentFixture<PricingInputFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PricingInputFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PricingInputFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
