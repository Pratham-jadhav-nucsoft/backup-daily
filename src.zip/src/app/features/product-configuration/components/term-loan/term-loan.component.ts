

import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';

@Component({
  selector: 'app-term-loan',
  templateUrl: './term-loan.component.html',
  styleUrls: ['./term-loan.component.css']
})
export class TermLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  params: any;
  editingMode: boolean = false;
  termForm!: FormGroup;
  rowFormArray!: FormArray;
  lastAddedRowIndex: number = -1;
  selectedInterestList: any = [];
  selectedMethodInterestList: any = [];





  interestMethodList =
    [
      {
        "commonId": 3033,
        "masterType": "interest_method",
        "commonCode": "interest_method_quat",
        "commonValue": "Declining Balance",
      },
      {
        "commonId": 3034,
        "masterType": "interest_method",
        "commonCode": "interest_method_year",
        "commonValue": "Flat",

      }
    ];






  constructor(private formBuilder: FormBuilder, public apiService: ApiFacadeService, public activate: ActivatedRoute) {

    this.activate.queryParams.subscribe(productId => {
      this.params = productId;
      console.log("this.params", this.params);
      if (productId['productId']) {
        this.editingMode = true;
      }

    })

  }

  ngOnInit(): void {
    this.termForm = this.formBuilder.group({

      isManagedFeeBasedLoanAmount: [false],
      // ticketSizeMin:[null,[Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      // ticketSizeMax:[null,[this.maxValidator('min'),Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      ticketSizeMax: [null, [this.maxValidator('ticketSizeMin'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      ticketSizeMin: [null, [this.minValidator('ticketSizeMax'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

      maxCustomerIdExposure: [null, [this.maxValidator('minCustomerIdExposure'), Validators.minLength(1), Validators.maxLength(15)]],
      minCustomerIdExposure: [0, [this.minValidator('maxCustomerIdExposure'), Validators.minLength(1), Validators.maxLength(15)]],
      maxTenure: [null, [this.maxValidator('minTenure'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minTenure: [null, [this.minValidator('maxTenure'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],

      maxAdvanceAmount: [null, [this.maxValidator('minAdvanceAmount'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      minAdvanceAmount: [null, [this.minValidator('maxAdvanceAmount'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

      maxAprPercentage: [null, [this.maxValidator('minAprPercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minAprPercentage: [null, [this.minValidator('maxAprPercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],

      maxProcessingFeePercentage: [null, [this.maxValidator('minProcessingFeePercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minProcessingFeePercentage: [null, [this.minValidator('maxProcessingFeePercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      // amtmax0: [null, Validators.required],
      // amtmin0: [null, Validators.required],
      // maxProcessingFeePercentage0: [null, Validators.required],
      // minProcessingFeePercentage0: [null, Validators.required],
      interestCode: [null, Validators.required],
      interestMethodCode: [null, Validators.required],
      isBalanceTransferred: [false],
      isOverrideEligibility: [false],
      isFreeInsuranceAllowed: [false],


      listOfTermCommercialConfig: this.formBuilder.array([

      ]),
      // Add more form controls as needed
    });

    this.rowFormArray = this.termForm.get('rows') as FormArray;
    const defaultRowCount = 2; // Set the number of default rows you want
    if (!this.params.productId) {
      for (let i = 0; i < defaultRowCount; i++) {
        this.addContactDetails(); // This function adds default rows
      }
    }

    this.getAllInterests();
    this.getAllInterestMethods();
    this.fetchProductData();
    console.log('assad--------->', this.contactDetails);

  }





  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }

  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }



  maxValidator(minControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const minControl = control.parent?.get(minControlName);
      if (minControl && control.value !== null && minControl.value !== null) {
        const min = +minControl.value;
        const max = +control.value;

        if (max <= min) {
          return { maxError: true };
        }
      }

      return null;
    };
  }


  get contactDetails() {
    return this.termForm.get("listOfTermCommercialConfig") as FormArray;
  }
  minValidator(maxControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const maxControl = control.parent?.get(maxControlName);
      if (maxControl && control.value !== null && maxControl.value !== null) {
        const min = +control.value;
        const max = +maxControl.value;

        if (min >= max) {
          return { minError: true };
        }
      }

      return null;
    };
  }

  // visible() {
  //   // Convert to number
  //   if (this.termForm.valid) {
  //     isValid=!isValid;
  //   }

  // }

  lessThanHundred(control: AbstractControl): ValidationErrors | null {
    const value = +control.value; // Convert to number
    if (value >= 100) {
      return { lessThanHundred: true };
    }
    return null;
  }

  isManageFeeCheckboxDisabled(): boolean {
    const ticketSizeMin = this.termForm.get('ticketSizeMin')?.value;
    const ticketSizeMax = this.termForm.get('ticketSizeMax')?.value;
    return !(ticketSizeMin !== null && ticketSizeMax !== null && ticketSizeMin !== '' && ticketSizeMax !== '');
  }


  addContactDetails() {


    const termLoanCommercialProcessingFeeConfig = this.formBuilder.group({

      amountRangeMin: [null, [this.minValidator('amountRangeMax'), Validators.minLength(1), Validators.maxLength(15), Validators.required]],
      amountRangeMax: [null, [this.maxValidator('amountRangeMin'), Validators.minLength(1), Validators.maxLength(15), Validators.required]],
      processingFeePercentageMin: [null, [this.minValidator('processingFeePercentageMax'), Validators.max(100), Validators.required]],
      processingFeePercentageMax: [null, [this.maxValidator('processingFeePercentageMin'), Validators.max(100), Validators.required]],
      isDeleted: [false]
    });

    this.contactDetails.push(termLoanCommercialProcessingFeeConfig);
    this.lastAddedRowIndex = this.contactDetails.length - 1; // Update lastAddedRowIndex
  }

  addArray(i: any) {
    console.log('aaaaaa', +this.contactDetails.at(i).get('amountRangeMax')?.value)
    if (+this.termForm.value.ticketSizeMax != +this.contactDetails.at(i).get('amountRangeMax')?.value) {
      // if (this.termForm.value.ticketSizeMax.valid&&this.termForm.value.ticketSizeMin.valid) {
      //  this.addContactDetails();
      // } else {
      //  console.log('Please fill the current row first');
      //  }
      if (this.contactDetails.at(i).valid) {
        console.log('All fields valid');
        this.addContactDetails();
      }
      else {
        console.log('Invalid field');
      }

    }
    else {
      console.log('max amount reached');
    }
  }
  // addArray(i: any) {
  //   const newRowFormGroup = this.formBuilder.group({
  //     amountRangeMin: [null, [this.minValidator('amountRangeMax'), Validators.required]],
  //     amountRangeMax: [null, [this.maxValidator('amountRangeMin'), Validators.required]],
  //     processingFeePercentageMin: [null, [this.minValidator('processingFeePercentageMax'), Validators.required]],
  //     processingFeePercentageMax: [null, [this.maxValidator('processingFeePercentageMin'), Validators.required]],
  //   });

  //   if (newRowFormGroup.valid) {
  //     this.contactDetails.push(newRowFormGroup);
  //     this.lastAddedRowIndex = this.contactDetails.length - 1;
  //   } else {
  //     console.log('Invalid field');
  //   }
  // }




  deleteDetails(contactIndex: number) {
    // Get the form group at the specified index
    if (this.params.productId) {
      const contactFormGroup = this.contactDetails.at(contactIndex) as FormGroup;

      // Set isDeleted to true for the specific row
      contactFormGroup.get('isDeleted')?.setValue(true);

      // Remove the contact detail from the form array
      this.contactDetails.removeAt(contactIndex);
    }


    if (contactIndex === this.lastAddedRowIndex) {
      if (this.contactDetails.length === 0) {
        this.lastAddedRowIndex = -1; // No rows left
      } else {
        this.lastAddedRowIndex = this.contactDetails.length - 1; // Update to the new last row index
      }
    }
    // console.log('this.termForm.value', contactFormGroup.get('isDeleted'));

  }


  //   deleteDetails(contactIndex: number) {
  //     this.contactDetails.removeAt(contactIndex);

  //     if (contactIndex === this.lastAddedRowIndex) {
  //       if (this.contactDetails.length === 0) {
  //         this.lastAddedRowIndex = -1; // No rows left
  //       } else {
  //         this.lastAddedRowIndex = this.contactDetails.length - 1; // Update to the new last row index
  //       }
  //     }
  //     // Get the form group at the specified index
  //   const contactFormGroup = this.contactDetails.at(contactIndex) as FormGroup;
  // console.log('contactFormGroup',contactFormGroup);

  //   // Set isDeleted to true for the specific row
  //   // contactFormGroup.get('isDeleted')?.setValue(true);
  //     console.log('this.termForm.value',this.termForm.value);

  //   } 




  async getAllInterests() {
    console.log('adadadad');
    this.selectedInterestList = await this.apiService.getAllInterest();
    console.log(" category->>>>", this.selectedInterestList);
  }
  async getAllInterestMethods() {
    console.log('adadadad');
    this.selectedMethodInterestList = await this.apiService.getAllInterestMethod();
    console.log(" category->>>>", this.selectedMethodInterestList);
  }

  async fetchProductData(): Promise<void> {

    try {
      if (this.params.productId) {
        const productData: any = await this.apiService.getProductById2(this.params.productId);


        console.log('  this.termform.->>>>>>>>>>>>>>>>>>>', productData);

        if (productData) {
          if (productData.termLoanCommercialConfig != null) {
            if (productData.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig != null) {
              if (productData.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig) {
                productData.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig.forEach((element: any) => {
                  this.addContactDetails();
                });
                let listOfTermCommercialConfig = productData.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig.map((element: any) => ({
                  amountRangeMin: element.amountRangeMin,
                  amountRangeMax: element.amountRangeMax,
                  processingFeePercentageMin: element.processingFeePercentageMin,
                  processingFeePercentageMax: element.processingFeePercentageMax
                }))
                this.termForm.controls['listOfTermCommercialConfig'].patchValue(listOfTermCommercialConfig);

                console.log('this.termForm', this.termForm);

              }
            }


            this.termForm.patchValue({
              ticketSizeMax: productData.termLoanCommercialConfig[0].ticketSizeMax,
              ticketSizeMin: productData.termLoanCommercialConfig[0].ticketSizeMin,
              maxCustomerIdExposure: productData.termLoanCommercialConfig[0].maxCustomerIdExposure,
              minCustomerIdExposure: productData.termLoanCommercialConfig[0].minCustomerIdExposure,
              minTenure: productData.termLoanCommercialConfig[0].minTenure,
              maxTenure: productData.termLoanCommercialConfig[0].maxTenure,
              maxAdvanceAmount: productData.termLoanCommercialConfig[0].maxAdvanceAmount,
              minAdvanceAmount: productData.termLoanCommercialConfig[0].minAdvanceAmount,
              maxAprPercentage: productData.termLoanCommercialConfig[0].maxAprPercentage,
              minAprPercentage: productData.termLoanCommercialConfig[0].minAprPercentage,
              maxProcessingFeePercentage: productData.termLoanCommercialConfig[0].maxProcessingFeePercentage,
              interestCode: productData.termLoanCommercialConfig[0].interestCode,
              interestMethodCode: productData.termLoanCommercialConfig[0].interestMethodCode,
              isBalanceTransferred: productData.termLoanCommercialConfig[0].isBalanceTransferred,
              isOverrideEligibility: productData.termLoanCommercialConfig[0].isOverrideEligibility,
              isFreeInsuranceAllowed: productData.termLoanCommercialConfig[0].isFreeInsuranceAllowed,
              isManagedFeeBasedLoanAmount: productData.termLoanCommercialConfig[0].isManagedFeeBasedLoanAmount,




              // Map other properties as needed
            });
          }
          this.termForm.markAllAsTouched()
          console.log('termproductData---------------->', productData);

          if (productData.termLoanCommercialConfig[0].isManagedFeeBasedLoanAmount == true) {
            console.log('DONEEE')
            this.termForm.get('maxProcessingFeePercentage')?.clearValidators();
            this.termForm.get('minProcessingFeePercentage')?.clearValidators();
            this.termForm.get('maxProcessingFeePercentage')?.updateValueAndValidity();
            this.termForm.get('minProcessingFeePercentage')?.updateValueAndValidity();
          }
          else {
            console.log('NOT DONEEE')
          }

        }
        else {
          console.error('Failed to fetch product data.');
        }

      }

    } catch (error) {
      console.error('Error while fetching data by ID3:', error);
    }
  }

  //   clearValidations() {

  // //  console.log(this.contactDetails.controls.get('amtmin1'));

  //  console.log('contactdetailss-------------->',this.contactDetails);

  //   this.contactDetails.controls.forEach((control: AbstractControl<any, any>) => {
  //     control.get('amtmin1')?.clearValidators();
  //     control.get('amtmax1')?.clearValidators();
  //     control.get('minProcessingFeePercentage1')?.clearValidators();
  //     control.get('maxProcessingFeePercentage1')?.clearValidators();
  //     control.get('amtmin1')?.updateValueAndValidity();
  //     control.get('amtmax1')?.updateValueAndValidity();
  //     control.get('minProcessingFeePercentage1')?.updateValueAndValidity();
  //     control.get('maxProcessingFeePercentage1')?.updateValueAndValidity();
  //   });

  //   // Update the form controls to remove the validations
  //   // this.termForm.updateValueAndValidity();
  //    console.log( 'assad2--------->', this.contactDetails);
  // }


  // onManageFeeCheckboxChange(event: any) {
  //   // Check if the checkbox is checked or not
  //   if (event.checked) {
  //     this.termForm.get('maxProcessingFeePercentage')?.clearValidators();
  //     this.termForm.get('minProcessingFeePercentage')?.clearValidators();
  //     this.termForm.get('maxProcessingFeePercentage')?.updateValueAndValidity();
  //     this.termForm.get('minProcessingFeePercentage')?.updateValueAndValidity();
  //     console.log('Yes'); // Checkbox is checked
  //   } else {

  //     console.log('No'); // Checkbox is not checked
  //   }
  // }

}
