
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';

@Component({
  selector: 'app-term-loan',
  templateUrl: './term-loan.component.html',
  styleUrls: ['./term-loan.component.css']
})
export class TermLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
 
  termForm!: FormGroup;
  rowFormArray!: FormArray;
  
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.termForm = this.formBuilder.group({
      productDescription: [''],
      manageFeeBasedOnLoan: [false],
     // ticketmin:[null,[Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
     // ticketmax:[null,[this.maxValidator('min'),Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
     ticketmax: [null, [this.maxValidator('ticketmin'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
     ticketmin: [null, [this.minValidator('ticketmax'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

     custmax:[null,[this.maxValidator('custmin'), Validators.minLength(1), Validators.maxLength(15)]],
      custmin:[0,[this.maxValidator('custmax'), Validators.minLength(1), Validators.maxLength(15)]],
      tenmax:[null,[this.maxValidator('tenmin'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      tenmin:[null,[this.minValidator('tenmax'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      
      advmax:[null,[this.maxValidator('advmin'),Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      advmin:[null,[this.minValidator('advmax'),Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      
      aprmax:[null,[this.maxValidator('aprmin'),this.lessThanHundred,Validators.required,Validators.minLength(1),Validators.maxLength(3)]],
      aprmin:[null,[this.minValidator('aprmax'),this.lessThanHundred,Validators.required,Validators.minLength(1),Validators.maxLength(3)]],
      
      promax:[null,[this.maxValidator('promin'),this.lessThanHundred,Validators.required,Validators.minLength(1),Validators.maxLength(3)]],
      promin:[null,[this.minValidator('promax'),this.lessThanHundred,Validators.required,Validators.minLength(1),Validators.maxLength(3)]],
      interest:[null,Validators.required],
      interestMethod:[null,Validators.required],
      blnTransfer:[false],
      ovrEligibility:[false],
      freeInsurance:[false],
      contactDetails: this.formBuilder.array([

      ]),

      rows: this.formBuilder.array([]),
      // Add more form controls as needed
    });
    this.rowFormArray = this.termForm.get('rows') as FormArray;
    this.addContactDetails();
  }

  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }
  
  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }

  maxValidator(minControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const minControl = control.parent?.get(minControlName);
      if (minControl && control.value !== null && minControl.value !== null) {
        const min = +minControl.value;
        const max = +control.value;
  
        if (max <= min) {
          return { maxError: true };
        }
      }
  
      return null;
    };
  }
  get contactDetails() {
    return this.termForm.get("contactDetails") as FormArray;
  }
  minValidator(maxControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const maxControl = control.parent?.get(maxControlName);
      if (maxControl && control.value !== null && maxControl.value !== null) {
        const min = +control.value;
        const max = +maxControl.value;
  
        if (min >= max) {
          return { minError: true };
        }
      }
  
      return null;
    };
  }
  


  lessThanHundred(control: AbstractControl): ValidationErrors | null {
    const value = +control.value; // Convert to number
    if (value >= 100) {
      return { lessThanHundred: true };
    }
    return null;
  }

  isManageFeeCheckboxDisabled(): boolean {
    const ticketMin = this.termForm.get('ticketmin')?.value;
    const ticketMax = this.termForm.get('ticketmax')?.value;
    return !(ticketMin !== null && ticketMax !== null && ticketMin !== '' && ticketMax !== '');
  }
  

  addContactDetails() {
    const contactForm = this.formBuilder.group({
      amtmin: ['', ],
      amymax: ['', ],
      promin1: ['', ],
      promin2: ['', ]
    });
    this.contactDetails.push(contactForm);
  }

  deleteDetails(contactIndex: number) {
    this.contactDetails.removeAt(contactIndex);
  }

  

  // form array
  addRow() {
    this.rowFormArray.push(this.createRowFormGroup());
  }
  removeRow(index: number) {
    this.rowFormArray.removeAt(index);
  }
  createRowFormGroup() {
    return this.formBuilder.group({
      min: [null, Validators.required],
      max: [null, Validators.required],
      // ... other controls
    });
  }
}
