

// import { Component, OnInit } from '@angular/core';
// import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
// import { SlickgridComponent } from '../slickgrid/slickgrid.component';  

// @Component({
//   selector: 'app-file-status',
//   templateUrl: './file-status.component.html',
//   styleUrls: ['./file-status.component.css']
// })
// export class FileStatusComponent implements OnInit {
//    columnDefinitions1: Column[]=[];
//    gridOptions1!: GridOption;
//    dataset1: any[] = [];
   
//    columnDefinitions2: Column[]=[];
//    dataset2: any[] = [];
//    gridOptions2!: GridOption;

//   constructor() { }

//   ngOnInit(): void {
//     this.gridOptions1 = {
//       enableCellNavigation: true,
//       enableColumnReorder: false,
//       enableAutoResize: false,
//       enableFiltering: true,
//       enableSorting: true,
//     };
 

//   this.columnDefinitions1 = [
//     { id: 'sequence', name: 'Sequence', field: 'Sequence', filterable: true, sortable: true },
//     { id: 'city', name: 'City', field: 'City', filterable: true, sortable: true },
//     { id: 'citycode', name: 'City Code', field: 'City Code', filterable: true, sortable: true },
//     { id: 'state', name: 'State', field: 'State', filterable: true, sortable: true },
//     { id: 'region', name: 'Region', field: 'Region', filterable: true, sortable: true },
//     { id: 'country', name: 'Country', field: 'Country', filterable: true, sortable: true },
//     { id: 'description', name: 'Description', field: 'Description', filterable: true, sortable: true },
//   ]

//   this.dataset1 = [

//       { id: 1, sequence: 1, city: 'City 1', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf' },
//       { id: 2, sequence:2, city: 'city 2', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf'  }
//     ];


//     //--------------------------2------------------------------
//    this.gridOptions2 = {
//       enableCellNavigation: true,
//       enableColumnReorder: false,
//       enableAutoResize: false,
//       enableFiltering: true,
//       enableSorting: true,
//     };

//     this.columnDefinitions2 = [
//       { id: 'sequence', name: 'Sequence', field: 'Sequence', filterable: true, sortable: true },
//       { id: 'city', name: 'City', field: 'City', filterable: true, sortable: true },
//       { id: 'citycode', name: 'City Code', field: 'City Code', filterable: true, sortable: true },
//       { id: 'state', name: 'State', field: 'State', filterable: true, sortable: true },
//       { id: 'region', name: 'Region', field: 'Region', filterable: true, sortable: true },
//       { id: 'country', name: 'Country', field: 'Country', filterable: true, sortable: true },
//       { id: 'description', name: 'Description', field: 'Description', filterable: true, sortable: true },
//     ]
//     this.dataset2 = [
//       { id: 1, sequence: 1, city: 'City 1', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf' },
//       { id: 2, sequence:2, city: 'city 2', citycode: '400101', state:'dfgs', region:'dfxc', country:'DFsadf', description:'asf'  }

//     ];
// }

// angularGridReady(angularGrid: any): void {
  
// }

// }

import { Component, Inject, OnInit, ViewChild  } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { GlobalUrlService } from '../global-url';
import { ApiFacadeService } from 'src/app/features/facade';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
export interface DialogData {
  columnDefinitions: any[];
  listOfSuccessRecords: any;
  listOfFailureRecords: any;
  headers: any;
  failureCount: number;
  successCount: number;

}
@Component({
  selector: 'app-file-status',
  templateUrl: './file-status.component.html',
  styleUrls: ['./file-status.component.css']
})
export class FileStatusComponent implements OnInit {
  columnDefinitionsWithoutError:any[] = [];
  columnDefinitions: any[] = [];
  fileSuccessFailureColumnDefinitions:any;
  gridOptions!: GridOption;
  listOfSuccessRecords: any[] = [];

  columnDefinitions2: Column[] = [];
  listOfFailureRecords: any[] = [];
  gridOptions2!: GridOption;
  successFileGridId: any = "success-file"
  failureFileGridId: any = "failure-file"
  isFailureTabActive: boolean = false;

  @ViewChild('tabGroup') tabGroup: any;
  constructor(@Inject(MAT_DIALOG_DATA) public data: DialogData    ) {
    console.log("-------------",data)
    this.columnDefinitions = this.data.columnDefinitions.filter((column: any) => column.field !== 'isAnchorTagged');
    this.columnDefinitionsWithoutError = this.columnDefinitions.filter((column: any) => column.field !== 'error','isAnchorTagged');
   }
  ngOnInit(): void {
    console.log("this.data.listOfFailureRecords",this.data.listOfFailureRecords);  
     // Disable closing on clicking outside the dialog
     this.gridOptions = {

      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 300,
      gridWidth: 1000,
      enableFiltering: true,
      enableCellNavigation: true,

      // enablePagination: true, // Enable pagination
      // pagination: {
      //   pageSizes: [10, 25, 50], // Set the available page sizes (optional)
      //   pageSize: 10, // Set the initial page size (optional)
      //   pageNumber: 1, // Set the initial page number (optional)
      //   totalItems: 100, // Set the total number of items in your dataset (required)
      // },
    };
    };

    tabChanged(tabChangeEvent: MatTabChangeEvent): void {
      this.isFailureTabActive = !this.isFailureTabActive
    }

    exportSuccessData(): void {
      const csvContent = this.convertToCSV(this.data.listOfSuccessRecords);
      console.log("List of Success Records:", this.data.listOfSuccessRecords);
    
      // Create a Blob with the data
      const blob = new Blob([csvContent], { type: 'text/csv' });
    
      // Trigger the download using FileSaver.js
      saveAs(blob, 'exported_SuccessImports.csv');
      
    }
  
    exportFailureData(): void {
  
      const csvContent = this.convertToCSV(this.data.listOfFailureRecords);
      console.log("List of Failure Records:", this.data.listOfFailureRecords);
    
      // Create a Blob with the data
      const blob = new Blob([csvContent], { type: 'text/csv' });
    
      // Trigger the download using FileSaver.js
      saveAs(blob, 'exported_FailedImports.csv');
    }

    convertToCSV(data: any[]): string {
      // Initialize the CSV content with the header row
      let csvContent = 'Sequence,Ifsc Code,Micr Code,Branch Name,Branch Code\n';
  
      // Iterate through the data and add each row to the CSV content
      for (const items of data) {
        console.log('data of dataset2', items)
        const row = `${items.sequence},${items.ifscCode},${items.micrCode},${items.bankBranchName},${items.bankBranchCode}\n`;
        csvContent += row;
      }
  
      return csvContent;
    }


}
