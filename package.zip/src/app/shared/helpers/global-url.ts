import { OnInit, Directive } from '@angular/core';
import configJson from "src/assets/config/config.json";
import { Injectable } from '@angular/core';
@Directive()



@Injectable({
    providedIn: 'root',
  })
  export class GlobalUrlService implements OnInit {

    public static fundsource = configJson.gateWayUrl +'/api/FundSource/pagination';

    public static bank = configJson.gateWayUrl +'/api/Master/get-all-bank';
    public static state = configJson.gateWayUrl +'/api/Master/get-all-state';
     
    ngOnInit(): void {
    }
  }

  