import { OnInit, Directive } from '@angular/core';
import configJson from "src/assets/config/config.json";
import { Injectable } from '@angular/core';
@Directive()



@Injectable({
    providedIn: 'root',
  })
  export class GlobalUrlService implements OnInit {

    public static fundsource = configJson.gateWayUrl +'/api/fund-source/pagination';

    public static bank = configJson.gateWayUrl +'/api/Master/get-all-bank';
    
    
    // dropdowns
    public static state = configJson.gateWayUrl +'/api/masters/get-all-state';
    public static city = configJson.gateWayUrl +'/api/masters/get-all-city';
    public static pincode = configJson.gateWayUrl +'/api/masters/get-all-pincode';
    public static country = configJson.gateWayUrl +'/api/masters/get-all-country';
     
    ngOnInit(): void {
    }
  }

  