import { Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { LimitLoanComponent } from '../limit-loan/limit-loan.component';
import { TermLoanComponent } from '../term-loan/term-loan.component';
import { validateHorizontalPosition } from '@angular/cdk/overlay';
@Component({
  selector: 'app-productconfiguration-form',
  templateUrl: './productconfiguration-form.component.html',
  styleUrls: ['./productconfiguration-form.component.css']
})
export class ProductconfigurationFormComponent implements OnInit {
  @ViewChild('dynamicComponent', { read: ViewContainerRef, static: true })
  dynamicComponentContainer!: ViewContainerRef;

  allowedIndustriesSelected: boolean = false;
  termLoanComponentRef: any = null;
  limitLoanComponentRef: any = null;
  showAdditionalDiv: boolean = false;
  showAdditionalDiv2: boolean = false;
  showAdditionalDiv3: boolean = false;

  selectedProductTypes: boolean[] = [];
  selectedValues: any;
filteredSubIndustries: any[] = [];



  isFormCollapsed: boolean = true;
  termLoanPayload: any;
  limitLoanPayload: any;

  productTypes = [
    { value: 'type1', label: 'Term Loan' },
    { value: 'type2', label: 'Limit Loan  ' },
    // ... add more product types
  ];
  // subIndustries = [
  //   { value: 'subIndustry1', label: 'Sub-industry 1' },
  //   { value: 'subIndustry2', label: 'Sub-industry 2' },
  //   // ... add more sub-industries
  // ];

  industries = [
    { value: 1275, label: 'Financial Services' },
    { value: 1272, label: 'Healthcare' },
    // ... add other industries
  ];
  
  subIndustriesMapping:any= 
  // {
  //   1275: [
  //     { label: 'Pharmaceuticals (Financial Services)' },
  //     {  label: 'Biotechnology (Financial Services)' },
  //     {  label: 'Telemedicine (Financial Services)' },
  //     {   label: 'Banking (Financial Services)' },
  //     { label: 'Stock Exchanges (Financial Services)' },
  //     {  label: 'Asset Management (Financial Services)' },
  //     // ... add other sub-industries
  //   ],
  //   1272: [
  //     {  label: 'Pharmaceuticals (Healthcare)' },
  //     {  label: 'Biotechnology (Healthcare)' },
  //     {  label: 'Telemedicine (Healthcare)' },
  //     { label: 'Banking (Healthcare)' },
  //     {  label: 'Stock Exchanges (Healthcare)' },
  //     { label: 'Asset Management (Healthcare)' },
  //     // ... add other sub-industries
  //   ],
   
  //   // ... add mappings for other industries
  // };
  [
    {
        "subIndustryName": "Pharmaceuticals",
        "subIndustryId": 65,
        "industryId": 1275,
        "industryName": "Financial Services"
    },
    {
        "subIndustryName": "Biotechnology",
        "subIndustryId": 66,
        "industryId": 1275,
        "industryName": "Financial Services"
    },
    {
        "subIndustryName": "Telemedicine",
        "subIndustryId": 67,
        "industryId": 1275,
        "industryName": "Financial Services"
    },
    {
        "subIndustryName": "Banking",
        "subIndustryId": 93,
        "industryId": 1275,
        "industryName": "Financial Services"
    },
    {
        "subIndustryName": "Stock Exchanges",
        "subIndustryId": 95,
        "industryId": 1272,
        "industryName": "Health Care"
    },
    {
        "subIndustryName": "Asset Management",
        "subIndustryId": 99,
        "industryId": 1272,
        "industryName": "Health Care"
    }
]
  
  



  productForm!: FormGroup;
  termForm: any;
  // isPanelExpanded: boolean = true;





  constructor(
    private formBuilder: FormBuilder,
    private componentFactoryResolver: ComponentFactoryResolver
  ) { }

  ngOnInit(): void {

    this.productForm = this.formBuilder.group({
      isRenewal: [false],
      correspondingFreshProduct: [null, Validators.required],
      productName: [null, [Validators.required, Validators.pattern('^[a-zA-Z0-9\\s]*$'), Validators.minLength(2), Validators.maxLength(30)]],
      productDescription: [null, [Validators.minLength(2), Validators.maxLength(300)]],
      productCode: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(6)]],
      parentProduct: [null,],
      appIdTL: [null, [Validators.required, Validators.pattern('^[0-9]+$'), Validators.minLength(1), Validators.maxLength(15)]],
      compTL: [null, [this.customCompTLValidator,this.compositionSumValidator(),Validators.required,Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
      appIdLL: [null, [Validators.required, Validators.pattern('^[0-9]+$'), Validators.minLength(1), Validators.maxLength(15)]],
      compLL: [null, [this.customCompLLValidator,this.compositionSumValidator() ,Validators.required,Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
      calLvl: [false],

      category: [null, Validators.required],
      productType: [null, Validators.required, []],
      companyName: [null, Validators.required],
      allowedIndustries: [[],],
      allowedSubIndustries: [[], [this.subIndustryValidator(this.subIndustriesMapping)]],
      securedProduct: [null,],
      UnsecuredProduct: [null,],
      branch: [null, Validators.required],
      maxOutstanding: [null,],
      bcPartner: [null,],

    });
    console.log('---------------->', this.showAdditionalDiv3)
  }



  get f() {
    return this.productForm.controls;
  }


  // toggleCollapse() {
  //   this.isFormCollapsed = !this.isFormCollapsed;
  // }


  onAllowedIndustriesChange(): void {
    let selectedIndustries = this.productForm.value.allowedIndustries;
    console.log('selectedIndustries---------->',selectedIndustries);
    let matchingSubIndustries:any=[];
    // Loop through selected industries and find their corresponding sub-industries
    selectedIndustries.forEach((industry:any) => {
      let subInd:any=[];
      subInd = this.subIndustriesMapping.filter(
        (subIndustry:any) => subIndustry.industryId === industry
      );
      subInd.forEach((element:any) => {
      matchingSubIndustries.push(element);
      });
    });
    console.log('selectedIndustries------->',selectedIndustries);
    console.log('matchingSubIndustries-------->',matchingSubIndustries);
    this.productForm.controls['allowedSubIndustries'].patchValue(matchingSubIndustries);

  }


  subIndustryValidator(subIndustriesMapping: any[]): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const selectedIndustries: any[] = control.value || [];
      const allowedSubIndustries: any[] = control.parent?.get('allowedSubIndustries')?.value || [];
  
      let hasValidationError = false;
  
      selectedIndustries.forEach(industryId => {
        const industrySubIndustries: any[] = subIndustriesMapping.filter(subIndustry => subIndustry.industryId === industryId);
  
        if (industrySubIndustries.length > 0) {
          const isAnySubIndustrySelected = industrySubIndustries.some(subIndustry => allowedSubIndustries.includes(subIndustry));
          if (!isAnySubIndustrySelected) {
            hasValidationError = true;  
          }
        }
      });
  
      return hasValidationError ? { subIndustriesMissing: true } : null;
    };
  }
  
  customCompTLValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    
    // Validate if the value is between 0 and 100
    if (value !== null && (isNaN(value) || value < 0 || value > 100)) {
      return { invalidCompTL: true };
    }
    
    return null;
  }
  customCompLLValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    
    // Validate if the value is between 0 and 100
    if (value !== null && (isNaN(value) || value < 0 || value > 100)) {
      return { invalidCompLL: true };
    }
    
    return null;
  }
  
  
  onProductTypeChange(): void {
      this.selectedValues = this.productForm.get('productType')?.value || [];

    // Set the showAdditionalDiv properties based on the condition
    this.showAdditionalDiv = this.selectedValues.includes('type1');
    this.showAdditionalDiv2 = this.selectedValues.includes('type2');
    this.showAdditionalDiv3 = this.selectedValues.includes('type1') && this.selectedValues.includes('type2');

    // Clear any previously loaded components
    this.dynamicComponentContainer.clear();

    if (this.selectedValues.includes('type1')) {
      const termLoanFactory = this.componentFactoryResolver.resolveComponentFactory(TermLoanComponent);
      this.termLoanComponentRef = this.dynamicComponentContainer.createComponent(termLoanFactory);


      
    }

    if (this.selectedValues.includes('type2')) {
      const limitLoanFactory = this.componentFactoryResolver.resolveComponentFactory(LimitLoanComponent);
      this.limitLoanComponentRef = this.dynamicComponentContainer.createComponent(limitLoanFactory);
    }


  }

  
  onSubmitButtonClicked(): void {
    
    let payload: any = {};
    payload.termLoan=this.termLoanComponentRef.instance.termForm.value;
    payload.LimitLoan=this.limitLoanComponentRef.instance.limitForm.value;
    payload.ProductDetails=this.productForm.value;
    console.log('payoad-------->',payload);
    


    
  }
  

  // ... other class methods ...
  getTermLoanPayload(): any {
    return {
      minTicket: this.termForm.get('ticketmin').value,
      maxTicket: this.termForm.get('ticketmax').value,
      minCust: this.termForm.get('custmin').value,
      maxCust: this.termForm.get('custmax').value,
      // ... other properties ...
    };
  }
  getLimitLoanPayload(): any {
    // Return the data you want to include in the payload for LimitLoan
  }

  // compositionSumValidator(control: AbstractControl): ValidationErrors | null {
  //   const compTLValue = control.get('compTL')?.value;
  //   const compLLValue = control.get('compLL')?.value;
  
  //   if (compTLValue !== null && compLLValue !== null && compTLValue + compLLValue !== 100) {
  //     return { invalidCompositionSum: true };
  //   }
  
  //   return null;
  // }
  // applyCompositionValidation(): void {
  //   if (this.selectedValues.includes('type1') && this.selectedValues.includes('type2')) {
  //     const compTLControl = this.productForm.get('compTL');
  //     const compLLControl = this.productForm.get('compLL');
      
  //     if (compTLControl && compLLControl) {
  //       compTLControl.setValidators([
  //         Validators.required,
  //         Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$'),
  //         this.customCompTLValidator, // Add your custom validator here
  //        this. compositionSumValidator
  //       ]);
  
  //       compLLControl.setValidators([
  //         Validators.required,
  //         Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$'),
  //         this.customCompLLValidator, // Add your custom validator here
  //         this.compositionSumValidator
  //       ]);
  
  //       compTLControl.updateValueAndValidity();
  //       compLLControl.updateValueAndValidity();
  //     }
  //   }
  // }
  compositionSumValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      // Implement the validation logic here
      // For example, check if the sum of compTL and compLL is 100
      
      const compTLValue = control.parent?.get('compTL')?.value || 0;
      const compLLValue = control.parent?.get('compLL')?.value || 0;
      
      if (compTLValue + compLLValue !== 100) {
        return { compositionSumInvalid: true };
      }
      
      return null;
    };
  }
  // applyCompositionValidation(): void {
  //   if (this.showAdditionalDiv3) {
  //     const compTLControl = this.productForm.get('compTL');
  //     const compLLControl = this.productForm.get('compLL');

  //     if (compTLControl && compLLControl) {
  //       compTLControl.setValidators([
  //         Validators.required,
  //         Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$'),
  //         compositionSumValidator // Apply the custom validator here
  //       ]);

  //       compLLControl.setValidators([
  //         Validators.required,
  //         Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$'),
  //         compositionSumValidator // Apply the custom validator here
  //       ]);

  //       compTLControl.updateValueAndValidity();
  //       compLLControl.updateValueAndValidity();
  //     }
  //   }
  // }
}
