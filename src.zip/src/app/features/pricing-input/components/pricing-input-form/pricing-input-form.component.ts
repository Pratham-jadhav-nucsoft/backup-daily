import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-pricing-input-form',
  templateUrl: './pricing-input-form.component.html',
  styleUrls: ['./pricing-input-form.component.css']
})
export class PricingInputFormComponent implements OnInit {
  pricingForm!: FormGroup;
  avgtix: any;
  constructor(private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {


    this.pricingForm = this.formBuilder.group({

      month: ['',],
      year: ['',],
      txn: [null,],
      highTix: ['',],
      lowTix: ['',],
      mid: ['',],
      tid: ['',],
      batch: ['',],
      cardSales: [null,],
      cashSales: ['',],
      amex: ['',],
      total: ['',],
      avgtix: ['',],





    })
    this.onChange();
  }


  onChange() {
    // console.log(this.pricingForm.value);
  
    const cardSalesValue = this.pricingForm.value.cardSales;
    const txnValue = this.pricingForm.value.txn;
  
    // Perform the division calculation
    const calculatedValue = cardSalesValue / txnValue;
    console.log(calculatedValue);
  
    // Patch the calculated value into the form using the control name
    this.pricingForm.patchValue({ calculatedField: calculatedValue }); // 'calculatedField' should be the name of the control
  }



}
