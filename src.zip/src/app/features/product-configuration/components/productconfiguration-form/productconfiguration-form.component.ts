import { Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { LimitLoanComponent } from '../limit-loan/limit-loan.component';
import { TermLoanComponent } from '../term-loan/term-loan.component';
import { validateHorizontalPosition } from '@angular/cdk/overlay';
import { ChangeDetectorRef, /* ... */ } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-productconfiguration-form',
  templateUrl: './productconfiguration-form.component.html',
  styleUrls: ['./productconfiguration-form.component.css']
})
export class ProductconfigurationFormComponent implements OnInit {
  @ViewChild('dynamicComponent', { read: ViewContainerRef, static: true })
  dynamicComponentContainer!: ViewContainerRef;

  allowedIndustriesSelected: boolean = false;
  termLoanComponentRef: any = null;
  limitLoanComponentRef: any = null;
  showAdditionalDiv: boolean = false;
  showAdditionalDiv2: boolean = false;
  showAdditionalDiv3: boolean = false;
  productForm!: FormGroup;
  termForm: any;
  selectedProductTypes: boolean[] = [];
  selectedValues: any;
  filteredSubIndustries: any[] = [];
  isFormCollapsed: boolean = true;
  termLoanPayload: any;
  limitLoanPayload: any;





  categoryList = [
    {
      "commonId": 3030,
      "masterType": "product_category",
      "commonCode": "product_01",
      "commonValue": "MSME",
    },
    {
      "commonId": 3110,
      "masterType": "product_category",
      "commonCode": "personal_loan",
      "commonValue": "Personal Loan",


    },
    {
      "commonId": 3111,
      "masterType": "product_category",
      "commonCode": "business_loan",
      "commonValue": "Business Loan",


    }
  ];

  productList = [
    {
      "productId": 261,
      "productName": "Express",
      "parentProductId": null,

    },
    {
      "productId": 262,
      "productName": "Retail",
      "parentProductId": null,

    },
    {
      "productId": 263,
      "productName": "Test",
      "parentProductId": null,

    },
    {
      "productId": 264,
      "productName": "dfsdf",
      "parentProductId": null,

    },
    {
      "productId": 265,
      "productName": "Personal Loan",
      "parentProductId": 262,

    }
  ];

  productTypes =
    [
      {
        value: 4, label: 'Term Loan'
      },
      {
        value: 3, label: 'Limit Loan'
      },
    ];

  industries =
    [
      { value: 1275, label: 'Financial Services' },
      { value: 1272, label: 'Healthcare' },
    ];

  subIndustriesMapping: any =
    [
      {
        "subIndustryName": "Pharmaceuticals",
        "subIndustryId": 65,
        "industryId": 1275,
        "industryName": "Financial Services"
      },
      {
        "subIndustryName": "Biotechnology",
        "subIndustryId": 66,
        "industryId": 1275,
        "industryName": "Financial Services"
      },
      {
        "subIndustryName": "Telemedicine",
        "subIndustryId": 67,
        "industryId": 1275,
        "industryName": "Financial Services"
      },
      {
        "subIndustryName": "Banking",
        "subIndustryId": 93,
        "industryId": 1275,
        "industryName": "Financial Services"
      },
      {
        "subIndustryName": "Stock Exchanges",
        "subIndustryId": 95,
        "industryId": 1272,
        "industryName": "Health Care"
      },
      {
        "subIndustryName": "Asset Management",
        "subIndustryId": 99,
        "industryId": 1272,
        "industryName": "Health Care"
      }
    ]

  branchOptions: any[] =
    [

      {
        "branchId": 1288,
        "branchCode": "G300",
        "branchName": "GrantRoad3",

      },
      {
        "branchId": 1289,
        "branchCode": "SANE07",
        "branchName": "SantacruzE70",

      },
      {
        "branchId": 1290,
        "branchCode": "Matheran01",
        "branchName": "Matheran",

      },




    ]
  companylist: any[] =
    [
      {
        "companyId": 1,
        "companyName": "Neogrowth Group Company",
        "companyCode": "202308101734211270",
        "parentCompanyId": 125,
      },
      {
        "companyId": 128,
        "companyName": "Nucsoft",
        "companyCode": "202308211639423720",
        "parentCompanyId": 1,

      },
      {
        "companyId": 129,
        "companyName": "Nucsoft1",
        "companyCode": "202308211639590150",
        "parentCompanyId": 128,

      },
      {
        "companyId": 95,
        "companyName": "Aditya Birla Capital1",
        "companyCode": "202308211640311780",
        "parentCompanyId": 128,

      },
      {
        "companyId": 146,
        "companyName": "Tristha",
        "companyCode": "202308211641191690",
        "parentCompanyId": 1,

      }
    ]

  constructor(
    private formBuilder: FormBuilder,
    private componentFactoryResolver: ComponentFactoryResolver,
    private cdr: ChangeDetectorRef,
    private toastr: ToastrService,
    private router: Router,
    private http: HttpClient,
     public apiService: ApiFacadeService,
  ) { }

  ngOnInit(): void {

    this.productForm = this.formBuilder.group({
      isRenewal: [false],
      renewalProductId: [null, Validators.required],
      productName: [null, [Validators.required, Validators.pattern('^[a-zA-Z0-9\\s]*$'), Validators.minLength(2), Validators.maxLength(30)]],
      productDescription: [null, [Validators.minLength(2), Validators.maxLength(300)]],
      productCode: [null, [Validators.required, Validators.minLength(2), Validators.maxLength(6)]],
      parentProductId: [[],],
      appIdTL: [null, [Validators.required, Validators.pattern('^[0-9]+$'), Validators.minLength(1), Validators.maxLength(15)]],
      compTL: [null, [Validators.required, Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
      compLL: [null, [Validators.required, Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
      appIdLL: [null, [Validators.required, Validators.pattern('^[0-9]+$'), Validators.minLength(1), Validators.maxLength(15)]],
      overrideAtCalculatorLevel: [false],
      productCategoryCode: [[]  , Validators.required],
      typesOfProduct1: [[], Validators.required],
      companyId: [[], Validators.required],
      listOfIndustries: [[],],
      allowedSubIndustries: [[], [this.subIndustryValidator(this.subIndustriesMapping)]],
      isSecured: [null,],
      isUnsecured: [null,],
      branchId: [[], Validators.required],
      maxOutstandingPercentageOfPreviousLoan: [null,],
      isBcPartner: [null,],
    }, {
      validators: [this.masterFormCompositionSumValidator(), this.atLeastOneCheckedValidator()],

    });




  }



  get f() {
    return this.productForm.controls;
  }


  // toggleCollapse() {
  //   this.isFormCollapsed = !this.isFormCollapsed;
  // }


  onAllowedIndustriesChange(): void {
    let selectedIndustries = this.productForm.value.listOfIndustries;
    console.log('selectedIndustries---------->', selectedIndustries);
    let matchingSubIndustries: any = [];
    // Loop through selected industries and find their corresponding sub-industries
    selectedIndustries.forEach((industry: any) => {
      let subInd: any = [];
      subInd = this.subIndustriesMapping.filter(
        (subIndustry: any) => subIndustry.industryId === industry
      );
      subInd.forEach((element: any) => {
        matchingSubIndustries.push(element);
      });
    });
    this.productForm.controls['allowedSubIndustries'].patchValue(matchingSubIndustries);
    this.allowedIndustriesSelected = true;
    this.cdr.markForCheck(); //
  }


  subIndustryValidator(subIndustriesMapping: any[]): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const selectedIndustries: any[] = control.value || [];
      const allowedSubIndustries: any[] = control.parent?.get('allowedSubIndustries')?.value || [];

      let hasValidationError = false;

      selectedIndustries.forEach(industryId => {
        const industrySubIndustries: any[] = subIndustriesMapping.filter(subIndustry => subIndustry.industryId === industryId);

        if (industrySubIndustries.length > 0) {
          const isAnySubIndustrySelected = industrySubIndustries.some(subIndustry => allowedSubIndustries.includes(subIndustry));
          if (!isAnySubIndustrySelected) {
            hasValidationError = true;
          }
        }
      });

      return hasValidationError ? { subIndustriesMissing: true } : null;
    };
  }

  onProductTypeChange(): void {
    this.selectedValues = this.productForm.get('typesOfProduct1')?.value || [];

    // Set the showAdditionalDiv properties based on the condition
    this.showAdditionalDiv = this.selectedValues.includes(4);
    this.showAdditionalDiv2 = this.selectedValues.includes(3);
    this.showAdditionalDiv3 = this.selectedValues.includes(3) && this.selectedValues.includes(4);

    // Clear any previously loaded components
    this.dynamicComponentContainer.clear();

    if (this.selectedValues.includes(4)) {
      const termLoanFactory = this.componentFactoryResolver.resolveComponentFactory(TermLoanComponent);
      this.termLoanComponentRef = this.dynamicComponentContainer.createComponent(termLoanFactory);



    }

    if (this.selectedValues.includes(3)) {
      const limitLoanFactory = this.componentFactoryResolver.resolveComponentFactory(LimitLoanComponent);
      this.limitLoanComponentRef = this.dynamicComponentContainer.createComponent(limitLoanFactory);
    }


  }



  onSubmitButtonClicked(): void {

    const selectedCompanyId = this.productForm.value.companyId;

    const selectedCompany = this.companylist.find(company => company.companyId === selectedCompanyId);

    const companyPayload = selectedCompany
      ? {
        companyId: selectedCompany.companyId,
        companyName: selectedCompany.companyName,
        companyCode: selectedCompany.companyCode,
        parentCompanyId: selectedCompany.parentCompanyId
      }
      : null;



    const selectedBranchIds: number[] = this.productForm.value.branchId;

    const branchId = selectedBranchIds.map(selectedBranchId => {
      const selectedBranch = this.branchOptions.find(branch => branch.branchId === selectedBranchId);

      return selectedBranch
        ? {
          branchId: selectedBranch.branchId,
          branchName: selectedBranch.branchName,
          branchCode: selectedBranch.branchCode
        }
        : null;
    }).filter(branch => branch !== null);



    const typesOfProduct = this.selectedValues.map((value: number) => {
      const selectedType = this.productTypes.find(type => type.value === value);


      const appIdPatternControlName = selectedType?.value === 4 ? 'appIdTL' : 'appIdLL';
      const appIdPattern = this.productForm.get(appIdPatternControlName)?.value;
      const percentageComposition1 = selectedType?.value === 4 ? 'compTL' : 'compLL';
      const percentageComposition = this.productForm.get(percentageComposition1)?.value;

      return {
        productCompositionID: 0,
        productTypeId: selectedType?.value,
        appIdPattern,
        percentageComposition,
        isDeleted: false,
      };

    });
    // console.log('Branch Information Array:', branchId);

    const selectedIndustries: number[] = this.productForm.value.listOfIndustries;
    const listOfIndustries = selectedIndustries.map((industryId: number) => {
      const industrySubIndustries = this.productForm.value.allowedSubIndustries.filter(
        (subIndustry: any) => subIndustry.industryId === industryId
      );
      return {
        product_industry_mapping_id: 0,
        productId: 0, // You need to set the actual productId value here
        industryId,
        subIndustryId: industrySubIndustries.map((subIndustry: any) => ({
          subIndustryId: subIndustry.subIndustryId,
          product_industry_mapping_id: 0,
          isDeleted: false,
        })),
      };
    });




    const termLoanPayload = this.termLoanComponentRef ? this.termLoanComponentRef.instance.termForm.value : {};

    const limitLoanPayload = this.limitLoanComponentRef ? this.limitLoanComponentRef.instance.limitForm.value : {};
    const productDetailsPayload = this.productForm.value;

    const finalPayload: any = {
      productId: 0, // You need to set the actual productId value here
      typesOfProduct,
      listOfIndustries,
      companyId: companyPayload,
      ...productDetailsPayload,
      termLoanCommercialConfig: [
        {
          termLoanCommercialConfigId: 0,
          productCompositionId: 0,
          // Insert the term form payload here
          ...termLoanPayload,
          // termLoanCommercialProcessingFeeConfig: {

          // ...termLoanPayload.listOfTermCommercialConfig
          // }
        }
      ],
      listOfLimitLoan: [
        {
          limitLoanCommercialConfigId: 0,
          productCompositionId: 0,
          // Insert the limit form payload here
          ...limitLoanPayload,
        }
      ],
      createdBy: '66cea40c-54d2-41ed-4db2-80346a613e97',
      createdDate: '2023-08-14T06:06:48.16'
      
    };






    finalPayload.listOfIndustries = listOfIndustries;
    finalPayload.companyId = companyPayload;
    finalPayload.branchId = branchId;
    finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig = [];
    finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig.push({ listOfTermCommercialConfig: [] })
    finalPayload.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig = termLoanPayload.listOfTermCommercialConfig;
    // delete termLoanPayload.listOfTermCommercialConfig;
    delete finalPayload.termLoanCommercialConfig[0].listOfTermCommercialConfig;
    delete finalPayload.allowedSubIndustries;
    delete finalPayload.typesOfProduct1;
    delete finalPayload.appIdTL;
    delete finalPayload.compTL;
    delete finalPayload.compLL;
    delete finalPayload.appIdLL;
    // delete finalPayload.branchId;
    console.log('Final payload:', finalPayload);
    // } else {
    //   console.log('Error filling form');
    //   this.toastr.error('Error filling form!', 'Error');
    // }
    
      // ... (other properties)

      if (finalPayload) {
        // Assuming your form value represents the payload structure
        
        this.apiService.postProductDetails(finalPayload)
          .then((res) => {
            console.log('Response:', res);
            // Handle success, show toast, or navigate to another page if needed
          })
          .catch((error) => {
            console.error('Error:', error);
            // Handle error, show toast, or display an error message
          });
      } else {
        console.log('error while submitting-----------');
        
      }
    
  }





  getTermLoanPayload(): any {
    return {
      minTicket: this.termForm.get('ticketmin').value,
      maxTicket: this.termForm.get('ticketmax').value,
      minCust: this.termForm.get('custmin').value,
      maxCust: this.termForm.get('custmax').value,

    };
  }

  customCompTLValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;


    if (value !== null && (isNaN(value) || value < 0 || value > 100)) {
      return { invalidCompTL: true };
    }

    return null;
  }
  customCompLLValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;


    if (value !== null && (isNaN(value) || value < 0 || value > 100)) {
      return { invalidCompLL: true };
    }

    return null;
  }

  masterFormCompositionSumValidator(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      const compTLValue = formGroup.get('compTL');
      const compLLValue = formGroup.get('compLL');

      if (compTLValue && compLLValue) {
        const totalValue = (compTLValue.value || 0) + (compLLValue.value || 0);

        if (totalValue !== 100) {
          compTLValue.setErrors({ compositionSumInvalid: true });
          compLLValue.setErrors({ compositionSumInvalid: true });
        } else {
          if (compTLValue.errors && compTLValue.errors['compositionSumInvalid']) {
            const errors = { ...compTLValue.errors };
            delete errors['compositionSumInvalid'];
            compTLValue.setErrors(Object.keys(errors).length ? errors : null);
          }

          if (compLLValue.errors && compLLValue.errors['compositionSumInvalid']) {
            const errors = { ...compLLValue.errors };
            delete errors['compositionSumInvalid'];
            compLLValue.setErrors(Object.keys(errors).length ? errors : null);
          }
        }
      }

      return null;
    };
  }


  //   getAppIdControlName() {

  //     if (this.selectedValues.includes(1)) {
  //         return 'appIdTL';
  //     }

  //     if (this.selectedValues.includes(2)) {
  //         return 'appIdLL'; 
  //     } 



  // }





  atLeastOneCheckedValidator() {
    return (formGroup: AbstractControl): { [key: string]: any } | null => {
      const securedProduct = formGroup.get('isSecured');
      const unsecuredProduct = formGroup.get('isUnsecured');

      if ((securedProduct?.dirty || unsecuredProduct?.dirty) && (!securedProduct?.value && !unsecuredProduct?.value)) {
        return { atLeastOneChecked: true };
      }

      return null;
    };
  }


  goback() {
    this.router.navigate(['/productconfiguration-list'])
  }
}
