import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-status',
  templateUrl: './file-status.component.html',
  styleUrls: ['./file-status.component.css']
})
export class FileStatusComponent implements OnInit {
  columnDefinitions1: any[] = [
    // Replace this with your actual column definitions for Slickgrid 1
    // Example:
    { id: 'title', name: 'Title', field: 'title', sortable: true },
    { id: 'duration', name: 'Duration', field: 'duration', sortable: true }
  ];

  gridOptions1: any = {
    // Replace this with your actual grid options for Slickgrid 1
    // Example:
    enableCellNavigation: true,
    enableColumnReorder: false
  };

  dataset1: any[] = [
    // Replace this with your actual dataset for Slickgrid 1
    // Example:
    { id: 1, title: 'Task 1', duration: '5 days' },
    { id: 2, title: 'Task 2', duration: '3 days' }
  ];

  columnDefinitions2: any[] = [
    // Replace this with your actual column definitions for Slickgrid 2
    // Example:
    { id: 'name', name: 'Name', field: 'name', sortable: true },
    { id: 'age', name: 'Age', field: 'age', sortable: true }
  ];

  gridOptions2: any = {
    // Replace this with your actual grid options for Slickgrid 2
    // Example:
    enableCellNavigation: true,
    enableColumnReorder: false
  };

  dataset2: any[] = [
    // Replace this with your actual dataset for Slickgrid 2
    // Example:
    { id: 1, name: 'John', age: 30 },
    { id: 2, name: 'Jane', age: 25 }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
