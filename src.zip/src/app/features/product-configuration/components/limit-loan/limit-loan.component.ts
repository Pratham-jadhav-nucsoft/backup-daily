import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-limit-loan',
  templateUrl: './limit-loan.component.html',
  styleUrls: ['./limit-loan.component.css']
})
export class LimitLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;

  limitForm!: FormGroup;

  stmtCycle = [
    {
      "commonId": 2994,
      "masterType": "cycle_date",
      "commonCode": "cycle1",
      "commonValue": "1",

    },

    {
      "commonId": 2995,
      "masterType": "cycle_date",
      "commonCode": "cycle2",
      "commonValue": "2",

    },
    {
      "commonId": 2996,
      "masterType": "cycle_date",
      "commonCode": "cycle3",
      "commonValue": "3",

    },
    {
      "commonId": 2997,
      "masterType": "cycle_date",
      "commonCode": "cycle4",
      "commonValue": "4",

    },
    {
      "commonId": 2998,
      "masterType": "cycle_date",
      "commonCode": "cycle5",
      "commonValue": "5",

    },
    {
      "commonId": 2999,
      "masterType": "cycle_date",
      "commonCode": "cycle6",
      "commonValue": "6",

    },
    {
      "commonId": 3000,
      "masterType": "cycle_date",
      "commonCode": "cycle7",
      "commonValue": "7",

    },
    {
      "commonId": 3001,
      "masterType": "cycle_date",
      "commonCode": "cycle8",
      "commonValue": "8",

    },
    {
      "commonId": 3002,
      "masterType": "cycle_date",
      "commonCode": "cycle9",
      "commonValue": "9",

    },
    {
      "commonId": 3003,
      "masterType": "cycle_date",
      "commonCode": "cycle10",
      "commonValue": "10",

    }

  ];

  orderDisbursalEventList = [
    {
      "commonId": 3039,
      "masterType": "order_disbursal_event",
      "commonCode": "or_dis_eve_pur",
      "commonValue": "Delivered",

    },
    {
      "commonId": 3040,
      "masterType": "order_disbursal_event",
      "commonCode": "or_dis_eve_non_pur",
      "commonValue": "Purchased",

    }
  ];

  interestCalMethodList = [
    {
      "commonId": 3041,
      "masterType": "interest_cal_method",
      "commonCode": "interest_cal_method",
      "commonValue": "Interest Free",

    },
    {
      "commonId": 3107,
      "masterType": "interest_cal_method",
      "commonCode": "interest_cal_method",
      "commonValue": "Non interest free",

    }
  ];

  penalInterestList = [
    {
      "commonId": 3042,
      "masterType": "penal_interest_cal_method",
      "commonCode": "penal_cal_01",
      "commonValue": "From payment due date",

    },
    {
      "commonId": 3108,
      "masterType": "penal_interest_cal_method",
      "commonCode": "penal_cal_02",
      "commonValue": "From disbursement",

    }
  ];

  minAmtDueCalMethodList = [
    {
      "commonId": 3044,
      "masterType": "minimum_amount_due_calculation_method",
      "commonCode": "min_total_amt",
      "commonValue": "Of total amount",

    },
    {
      "commonId": 3114,
      "masterType": "minimum_amount_due_calculation_method",
      "commonCode": "min_princi_interest",
      "commonValue": "Of principal and interest",

    }
  ];

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.limitForm = this.formBuilder.group({

      minLimitTicketSize: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      maxLimitTicketSize: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      disbMonth: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      repaymentMonth: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      totalMonth: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      increaseDecreaseLoanLimit: [null, [Validators.minLength(1), Validators.maxLength(15)]],
      gracePeriod: [null, [Validators.required,Validators.minLength(1), Validators.maxLength(2)]],
      statementDateCode: [[], [Validators.required]],
      interestPercentage: [null, [Validators.required, Validators.min(1), Validators.max(100)]],
      interestEffectiveDate: [null,],
      penalRateOfInterestPercentage: [null,Validators.required],
      penalEffectiveDate: [null,],
      minimumPaymentPercentage: [null,Validators.required],
      processingFeePercentage: [null],
      gstPercentage: [null],
      chequeBounceCharges: [null,Validators.required],
      nachBounceCharges: [null],
      tolerancePeriod: [null],
      minimumDisbursement: [null,Validators.required],
      toleranceAmount: [null],
      dpdToleranceAmount: [null],
      orderDisbursementEventCode: [[],],
      interestCalculationMethodCode: [null],
      penalInterestCalculationMethodCode: [null],
      minimumAmountDueCalculationMethodCode: [null],
      coolingPeriodHrs: [null],

    });
    this.limitForm.get('disbMonth')?.valueChanges.subscribe(() => {
      this.updatetotalMonth();
    });

    this.limitForm.get('repaymentMonth')?.valueChanges.subscribe(() => {
      this.updatetotalMonth();
    });
  }

  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }

  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }
  updatetotalMonth() {
    const disbMonth = this.limitForm.get('disbMonth')?.value || 0;
    const repaymentMonth = this.limitForm.get('repaymentMonth')?.value || 0;

    const totalMonth = disbMonth + repaymentMonth;

    this.limitForm.get('totalMonth')?.setValue(totalMonth);
  }

}
