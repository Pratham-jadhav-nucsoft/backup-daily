import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';
import { EventEmitter, Output } from '@angular/core';
@Component({
  selector: 'app-limit-loan',
  templateUrl: './limit-loan.component.html',
  styleUrls: ['./limit-loan.component.css']
})
export class LimitLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  @Output() formControlsChange = new EventEmitter<FormGroup>();
  limitForm!: FormGroup;
  selectedodeList: any = [];
  selectedinterestCalMethodList: any = [];
  selectedminimumAmountDueCalculationMethodList: any = [];
  selectedPenalInterestCalculationMethodsList: any = [];
  selectedStatementCycleList: any = [];
  params: any;
  editingMode: boolean=false;

  constructor(private formBuilder: FormBuilder,  public apiService: ApiFacadeService,public activate:ActivatedRoute) {
    this.activate.queryParams.subscribe(productId => {
      this.params = productId;
      console.log("this.params", this.params);
      if (productId['productId']) {
        this.editingMode = true;
      }

    })
   }

  ngOnInit(): void {
    this.limitForm = this.formBuilder.group({

      minLimitTicketSize: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      maxLimitTicketSize: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      disbMonth: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      repaymentMonth: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      totalMonth: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      increaseDecreaseLoanLimit: [null, [Validators.minLength(1), Validators.maxLength(15)]],
      gracePeriod: [null, [Validators.required,Validators.minLength(1), Validators.maxLength(2)]],
      statementDateCode: [null, Validators.required],
      interestPercentage: [null, [Validators.required, Validators.min(1), Validators.max(100)]],
      interestEffectiveDate: [null,],
      penalRateOfInterestPercentage: [null,Validators.required],
      penalEffectiveDate: [null,],
      minimumPaymentPercentage: [null,Validators.required],
      processingFeePercentage: [null],
      gstPercentage: [null,Validators.required],
      chequeBounceCharges: [null,Validators.required],
      nachBounceCharges: [null,Validators.required],
      tolerancePeriod: [null,Validators.required],
      minimumDisbursement: [null,Validators.required],
      toleranceAmount: [null],
      dpdToleranceAmount: [null],
      orderDisbursementEventCode: [null,],
      interestCalculationMethodCode: [null],
      penalInterestCalculationMethodCode: [null],
      minimumAmountDueCalculationMethodCode: [null],
      coolingPeriodHrs: [null,Validators.required],

    });
    this.limitForm.get('disbMonth')?.valueChanges.subscribe(() => {
      this.updatetotalMonth();
    });

    this.limitForm.get('repaymentMonth')?.valueChanges.subscribe(() => {
      this.updatetotalMonth();
    });
    this.getAllODEs()
    this.getAllinterestCalMethods()
    this.getMinimumAccountDueCalculationMethods()
    this.getPenalInterestCalculationMethods()
    this.fetchProductData();
    this.getAllStatementCycles();
    this.sendFormControls();
  }
  sendFormControls() {
    this.formControlsChange.emit(this.limitForm);
  }
  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }

  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }
  updatetotalMonth() {
    const disbMonth = this.limitForm.get('disbMonth')?.value || 0;
    const repaymentMonth = this.limitForm.get('repaymentMonth')?.value || 0;

    const totalMonth = disbMonth + repaymentMonth;

    this.limitForm.get('totalMonth')?.setValue(totalMonth);
  }



  async getAllODEs() {
    console.log('adadadad');
    this.selectedodeList = await this.apiService.getAllODE();
    console.log(" category->>>>", this.selectedodeList);
  }
  async getAllinterestCalMethods() {
    console.log('adadadad');
    this.selectedinterestCalMethodList = await this.apiService.getAllinterestCalMethod();
    console.log(" category->>>>", this.selectedinterestCalMethodList);
  }
  async getMinimumAccountDueCalculationMethods() {
    console.log('adadadad');
    this.selectedminimumAmountDueCalculationMethodList = await this.apiService.getMinimumAccountDueCalculationMethod();
    console.log(" category->>>>", this.selectedminimumAmountDueCalculationMethodList);
  }
  async getPenalInterestCalculationMethods() {
    console.log('adadadad');
    this.selectedPenalInterestCalculationMethodsList = await this.apiService.getPenalInterestCalculationMethod();
    console.log(" category->>>>", this.selectedPenalInterestCalculationMethodsList);
  }
  async getAllStatementCycles() {
    console.log('adadadad');
    this.selectedStatementCycleList = await this.apiService.getAllStatementCycle();
    console.log(" category->>>>", this.selectedStatementCycleList);
  }


  async fetchProductData(): Promise<void> {
   
    try {
      if(this.params.productId){    const productData :any = {
        "productId": 123,
        "isRenewal": true,
        "renewalProductId": 0,
        "productName": "oldIndustry",
        "productDescription": "ABCD",
        "productCode": "IND",
        "productCategoryCode": "string",
        "parentProductId": 0,
        "typesOfProduct": [
            {
                "productCompositionID": 92,
                "productTypeId": 1,
                "appIdPattern": 100,
                "percentageComposition": 0,
                "productTypeName": "Term Loan",
                "isActive": true,
                "isDeleted": false,
                "createdBy": "00000000-0000-0000-0000-000000000000",
                "createdDate": "2023-08-25T15:55:21.14",
                "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "updatedDate": "2023-08-08T13:55:50.683"
            }
        ],
        "overrideAtCalculatorLevel": true,
        "companyId": 1,
        "listOfIndustries": [
            {
                "product_industry_mapping_id": 4,
                "productId": 0,
                "industryId": 4,
                "subIndustryId": [
                    {
                        "product_industry_mapping_id": 4,
                        "subIndustryId": 1,
                        "isActive": true,
                        "isDeleted": false
                    }
                ],
                "isActive": true,
                "isDeleted": false,
                "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "createdDate": "2023-08-25T10:23:54.217",
                "updatedBy": null,
                "updatedDate": null
            }
        ],
        "isSecured": true,
        "isUnsecured": true,
        "branchId": [
            {
                "product_branch_mapping_id": 9,
                "branchId": 42,
                "productId": 123,
                "isActive": true,
                "isDeleted": false,
                "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "createdDate": "2023-08-25T10:23:54.217",
                "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "updatedDate": "2023-08-09T13:55:50.683"
            }
        ],
        "maxOutstandingPercentageOfPreviousLoan": 0,
        "isBcPartner": true,
        "termLoanCommercialConfig": [
            {
                "termLoanCommercialConfigId": 30,
                "productCompositionId": 92,
                "ticketSizeMin": 20,
                "ticketSizeMax": 30,
                "minCustomerIdExposure": 1000,
                "maxCustomerIdExposure": 2000,
                "minAdvanceAmount": 10,
                "maxAdvanceAmount": 0,
                "minAprPercentage": 0,
                "maxAprPercentage": 0,
                "minTenure": 0,
                "maxTenure": 0,
                "minProcessingFeePercentage": 0,
                "maxProcessingFeePercentage": 0,
                "isManagedFeeBasedLoanAmount": true,
                "interestCode": "string",
                "interestMethodCode": "string",
                "isFreeInsuranceAllowed": false,
                "isOverrideEligibility": true,
                "isBalanceTransferred": false,
                "termLoanCommercialProcessingFeeConfig": [
                    {
                        "termLoanCommercialConfig": 30,
                        "listOfTermCommercialConfig": [
                            {
                                "termLoanCommercialProcessingFeeConfigId": 30,
                                "amountRangeMin": 10,
                                "amountRangeMax": 0,
                                "processingFeePercentageMin": 0,
                                "processingFeePercentageMax": 0,
                                "isActive": true,
                                "isDeleted": false,
                                "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "createdDate": "2023-08-25T10:23:54.217",
                                "updatedBy": null,
                                "updatedDate": null
                            },
     {
                                "termLoanCommercialProcessingFeeConfigId": 30,
                                "amountRangeMin": 10,
                                "amountRangeMax": 0,
                                "processingFeePercentageMin": 0,
                                "processingFeePercentageMax": 0,
                                "isActive": true,
                                "isDeleted": false,
                                "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "createdDate": "2023-08-25T10:23:54.217",
                                "updatedBy": null,
                                "updatedDate": null
                            }
                        ]
                    }
                ],
                "isActive": true,
                "isDeleted": false,
                "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "createdDate": "0001-01-01T00:00:00",
                "updatedBy": null,
                "updatedDate": null
            }
        ],
      
        "listOfLimitLoan": 
        [
            {

                "limitLoanCommercialConfigId": 0,
                "productCompositionId": 0,
                "minLimitTicketSize": "1",
                "maxLimitTicketSize": "2",
                "disbMonth": 1,
                "repaymentMonth": 12,
                "totalMonth": 13,
                "increaseDecreaseLoanLimit": null,
                "gracePeriod": "1",
                "statementDateCode": "cycle4",
                "interestPercentage": "1",
                "interestEffectiveDate": "2023-08-29T18:30:00.000Z",
                "penalRateOfInterestPercentage": "1",
                "penalEffectiveDate": "2023-08-29T18:30:00.000Z",
                "minimumPaymentPercentage": "1",
                "processingFeePercentage": "1",
                "gstPercentage": "1",
                "chequeBounceCharges": "1",
                "nachBounceCharges": "1",
                "tolerancePeriod": "1",
                "minimumDisbursement": "1",
                "toleranceAmount": "1",
                "dpdToleranceAmount": "1",
                "orderDisbursementEventCode": "delivered",
                "interestCalculationMethodCode": "interest_free",
                "penalInterestCalculationMethodCode": "disbursement",
                "minimumAmountDueCalculationMethodCode": "of_total_amount",
                "coolingPeriodHrs": "1",
                "isActive": true,
                "isDeleted": false,
                "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "createdDate": "2023-08-18T03:53:13.873Z",
                "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                "updatedDate": "2023-08-18T03:53:13.873Z"
            }
        ],
        "isActive": true,
        "isDeleted": false,
        "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
        "createdDate": "2023-08-25T15:55:21.137",
        "updatedBy": null,
        "updatedDate": null
    }
  
      if (productData) {
        this.limitForm.patchValue({
          minLimitTicketSize: productData.listOfLimitLoan[0].minLimitTicketSize,
          maxLimitTicketSize: productData.listOfLimitLoan[0].maxLimitTicketSize,
          disbMonth: productData.listOfLimitLoan[0].disbMonth,
          repaymentMonth: productData.listOfLimitLoan[0].repaymentMonth,
          totalMonth: productData.listOfLimitLoan[0].totalMonth,
          increaseDecreaseLoanLimit: productData.listOfLimitLoan[0].increaseDecreaseLoanLimit,
          gracePeriod: productData.listOfLimitLoan[0].gracePeriod,
          statementDateCode: productData.listOfLimitLoan[0].statementDateCode,
          interestPercentage: productData.listOfLimitLoan[0].interestPercentage,
          interestEffectiveDate: productData.listOfLimitLoan[0].interestEffectiveDate,
          penalRateOfInterestPercentage: productData.listOfLimitLoan[0].penalRateOfInterestPercentage,
          penalEffectiveDate: productData.listOfLimitLoan[0].penalEffectiveDate,
          minimumPaymentPercentage: productData.listOfLimitLoan[0].minimumPaymentPercentage,
          processingFeePercentage: productData.listOfLimitLoan[0].processingFeePercentage,
          gstPercentage: productData.listOfLimitLoan[0].gstPercentage,
          chequeBounceCharges: productData.listOfLimitLoan[0].chequeBounceCharges,
          nachBounceCharges: productData.listOfLimitLoan[0].nachBounceCharges,
          tolerancePeriod: productData.listOfLimitLoan[0].tolerancePeriod,
          minimumDisbursement: productData.listOfLimitLoan[0].minimumDisbursement,
          toleranceAmount: productData.listOfLimitLoan[0].toleranceAmount,
          dpdToleranceAmount: productData.listOfLimitLoan[0].dpdToleranceAmount,
          orderDisbursementEventCode: productData.listOfLimitLoan[0].orderDisbursementEventCode,
          interestCalculationMethodCode: productData.listOfLimitLoan[0].interestCalculationMethodCode,
          penalInterestCalculationMethodCode: productData.listOfLimitLoan[0].penalInterestCalculationMethodCode,
          minimumAmountDueCalculationMethodCode: productData.listOfLimitLoan[0].minimumAmountDueCalculationMethodCode,
          coolingPeriodHrs: productData.listOfLimitLoan[0].coolingPeriodHrs,
          isActive: productData.listOfLimitLoan[0].isActive,
          isDeleted: productData.listOfLimitLoan[0].isDeleted,
          createdBy: productData.listOfLimitLoan[0].createdBy,
          createdDate: productData.listOfLimitLoan[0].createdDate,
          updatedBy: productData.listOfLimitLoan[0].updatedBy,
          updatedDate: productData.listOfLimitLoan[0].updatedDate,
        });
        
        console.log('limitproductData---------------->', productData);
      } else {
        console.error('Failed to fetch product data.');
      }}
      // const productData :any = await this.apiService.getProductById2(this.params.productId);
   
    } catch (error) {
      console.error('Error while fetching data by ID:', error);
    }
  }

}
