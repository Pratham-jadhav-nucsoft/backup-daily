import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatButtonModule} from '@angular/material/button';
import { CdkAccordionModule } from '@angular/cdk/accordion';
import { HttpClientModule } from '@angular/common/http';
import { AngularSlickgridModule } from 'angular-slickgrid';
import { MatIconModule } from '@angular/material/icon';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatSelectModule} from '@angular/material/select';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatCardModule} from '@angular/material/card';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { AccountFormComponent } from './components/account-form/account-form.component';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatRadioModule} from '@angular/material/radio';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { FunsourceFormComponent } from './components/funsource-form/funsource-form.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { BankingFormComponent } from './components/banking-form/banking-form.component';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { NgSelectModule } from '@ng-select/ng-select'; // Import the NgSelectModule

@NgModule({
  declarations: [
    BankingFormComponent,
    FunsourceFormComponent,
    AccountFormComponent
  ],
  imports: [
    CommonModule,
    
   FormsModule, 
    MatInputModule,
    MatDatepickerModule,
    NgSelectModule ,
    MatCardModule,
    MatAutocompleteModule,
    MatSlideToggleModule,
    MatCheckboxModule,
    HttpClientModule,
    MatRadioModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonModule,
    CdkAccordionModule,
    MatIconModule ,
    NgxPaginationModule,
    FormsModule, ReactiveFormsModule ,
    AngularSlickgridModule.forRoot({}),
  ]
})
export class FundsourceDetailsModule { }
