import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApplicationDetailsRoutingModule } from './application-details-routing.module';


@NgModule({
  declarations: [
    
  ],
  imports: [
    CommonModule,
    ApplicationDetailsRoutingModule
  ]
})
export class ApplicationDetailsModule { }
