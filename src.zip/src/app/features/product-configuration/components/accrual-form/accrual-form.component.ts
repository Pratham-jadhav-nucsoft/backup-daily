import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-accrual-form',
  templateUrl: './accrual-form.component.html',
  styleUrls: ['./accrual-form.component.css']
})
export class AccrualFormComponent implements OnInit {
  masterForm!: FormGroup;
  lastAddedRowIndex: any;
  constructor(public formBuilder: FormBuilder) {
    this.masterForm = this.formBuilder.group({
      disbursedFromHour: [0, [Validators.min(0), Validators.max(23)]],
      disbursedFromMinute: [0, [Validators.min(0), Validators.max(60)]],
      disbursedToHour: [23, [Validators.min(0), Validators.max(23)]],
      disbursedToMinute: [59, [Validators.min(0), Validators.max(60)]],
      startDay: [1],
      isDefaultRuleModified: [false],
      accrualStartDayConfig: this.formBuilder.array([]) // Initialize as an empty array
    });
  }

  ngOnInit(): void {
    const defaultRowCount = 1; // Set the number of default rows you want
    // if (!this.params.productId) {
    // for (let i = 0; i < defaultRowCount; i++) {
    //   this.addAccrualRow(); // This function adds default rows
    // }
    // }

    this.addAccrualRow();
    this.addAccrualRow();


  }


  get accrualFormArray() {
    return this.masterForm.get('accrualStartDayConfig') as FormArray;
  }

  // Method to add a new accrual row
  addAccrualRow() {
    this.accrualFormArray.push(
      this.formBuilder.group({
        disbursedFromHour: [null, [Validators.min(0), Validators.max(23)]],
        disbursedFromMinute: [null, [Validators.min(0), Validators.max(59)]],
        disbursedToHour: [null, [Validators.min(0), Validators.max(23)]],
        disbursedToMinute: [null, [Validators.min(0), Validators.max(59)]],
        startDay: [null],
      })
    );
    // this.lastAddedRowIndex = this.accrualFormArray.length - 1; 
    this.accrualFormArray.setValidators([this.continuityValidator]);
    this.isChecked();
  }

  // Method to remove a specific accrual row by index
  removeAccrualRow(index: number) {
    this.accrualFormArray.removeAt(index);


    if (index === this.lastAddedRowIndex) {
      if (this.accrualFormArray.length === 0) {
        this.lastAddedRowIndex = -1; // No rows left
      } else {
        this.lastAddedRowIndex = this.accrualFormArray.length - 1; // Update to the new last row index
      }
    }
  }


  isChecked() {
    this.lastAddedRowIndex = this.accrualFormArray.length - 1;

    const firstFormGroup = this.accrualFormArray.at(0) as FormGroup;

    firstFormGroup.patchValue({
      disbursedFromHour: 0,
      disbursedFromMinute: 0,
      startDay: 0,
    });



    console.log('this.accrualFormArray.length', this.accrualFormArray.length);

  }




  continuityValidator(control: AbstractControl): { [key: string]: boolean } | null {
    if (control.parent && control.parent instanceof FormArray) {
      const index = control.parent.controls.indexOf(control);
      if (index > 0) {
        const prevControl = control.parent.controls[index - 1] as FormGroup;
        const currControl = control as FormGroup;
        const prevHour = prevControl.get('disbursedToHour')?.value;
        const prevMinute = prevControl.get('disbursedToMinute')?.value;
        const currHour = currControl.get('disbursedFromHour')?.value;
        const currMinute = currControl.get('disbursedFromMinute')?.value;

        if (prevHour === currHour && prevMinute === currMinute) {
          return { continuityError: true };
        }
      }
    }

    return null;
  }
}
