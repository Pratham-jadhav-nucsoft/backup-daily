import { OnInit, Directive } from '@angular/core';
import configJson from "src/assets/config/config.json";
import { Injectable } from '@angular/core';
@Directive()



@Injectable({
  providedIn: 'root',
})
export class GlobalUrlService implements OnInit {

  public static fundsource = configJson.gateWayUrl + '/fund-source/pagination';

  // public static bank = configJson.gateWayUrl + '/api/Master/get-all-bank';


  // dropdowns
  public static state = configJson.gateWayUrl + '/masters/get-all-state';
  public static city = configJson.gateWayUrl + '/masters/get-all-city';
  public static pincode = configJson.gateWayUrl + '/masters/get-all-pincode';
  public static country = configJson.gateWayUrl + '/masters/get-all-country';
  public static bankifsc = configJson.gateWayUrl + '/masters/get-all-ifsc';
  public static bankname = configJson.gateWayUrl + '/masters/get-all-bank';

  public static accounttype = configJson.gateWayUrl + '/masters/get-all-account-type';


  //edit
  public static edit = configJson.gateWayUrl + '/fund-source/fundSourceId';


  // post
  public static post = configJson.gateWayUrl + '/fund-source';


  /// delete
  public static delete = configJson.gateWayUrl + '/fund-source';

//sequence
  public static sequence = configJson.gateWayUrl+'/fund-source/max-sequence';

//autopopulate
  public static   autopopulate = configJson.gateWayUrl+'  /masters/get-all-ifsc';


//template
  public static   template = configJson.gateWayUrl+'/fund-source/sample';

//import
  public static   imports = configJson.gateWayUrl+'/fund-source/import';


//export 
  public static   export = configJson.gateWayUrl+'/fund-source';






  public static   create = configJson.gateWayUrl2+'/product';

  // dorpdowns
  public static   company = configJson.gateWayUrl2+'/company';
  
  public static   productType = configJson.gateWayUrl2+'/productType';
  public static   industry = configJson.gateWayUrl2+'/industry';
  public static   subindustry = configJson.gateWayUrl2+'/subIndustry';
  public static   subindustrymapping = configJson.gateWayUrl2+'/subIndustryFromIndustryId';





  public static  category = configJson.gateWayUrl2+'/category';
  
  public static  interest = configJson.gateWayUrl2+'/interest';
  public static  interestmethod = configJson.gateWayUrl2+'/interestMethod';
  public static  ode = configJson.gateWayUrl2+'/overDisbursedEvent';
  public static  icm = configJson.gateWayUrl2+'/interestCalculationMethod';
  public static  madcm = configJson.gateWayUrl2+'/minimumAccountDueCalculationMethod';
  public static  picm = configJson.gateWayUrl2+'/penalInterestCalculationMethod';
  public static  branch = configJson.gateWayUrl2+'/branch';
  public static  stmtcycle = configJson.gateWayUrl2+'/statementCycle';
  public static  parentproduct = configJson.gateWayUrl2+'/parentProduct';


  //getbyid
  public static  patch = configJson.gateWayUrl2+'/productId';
  public static  slick = configJson.gateWayUrl2+'/pagination';
  public static  deleted = configJson.gateWayUrl2+'/product';


  

  ngOnInit(): void {
  }
}

