import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
// import { GlobalUrlDirective } from 'src/app/shared/helpers/modal/global-url';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
@Injectable({
  providedIn: 'root',
})
export class ApiFacadeService {
  constructor(private apiService: ApiService) { }

  async getAllFundSource() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.fundsource).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }


  //   async getAllBanks() {
  //     return new Promise(resolve => {
  //              return this.apiService.getAllBank  (GlobalUrlService.bank).subscribe(res => {
  //                 resolve(res);
  //                 console.log(res);
  //                 console.log('console running')
  //               });
  //             });
  // }

  async getAllState() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.state).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running(facade layer)')
      });
    });
  }
  async getAllCity() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.city).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllPincode() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.pincode).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllCountry() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.country).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllBankIFSC() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.bankifsc).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllBankName() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.bankname).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }

  async getAllAccountType() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.accounttype).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }




  postCityDetails(payload: any) {
    return new Promise(resolve => {
      this.apiService.postAllDetails(GlobalUrlService.post, payload).subscribe(res => {
        resolve(res);
        console.log(res);
      });
    });
  }
}