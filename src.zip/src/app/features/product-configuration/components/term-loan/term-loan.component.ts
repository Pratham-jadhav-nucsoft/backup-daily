// import { Component, OnInit } from '@angular/core';
// import { FormGroup } from '@angular/forms';

// @Component({
//   selector: 'app-term-loan',
//   templateUrl: './term-loan.component.html',
//   styleUrls: ['./term-loan.component.css']
// })
// export class TermLoanComponent implements OnInit {
//   isFormCollapsed: boolean = true;
//   isFormCollapsed2: boolean = true;
 
//   termForm!: FormGroup;
//   constructor() { }

//   ngOnInit(): void {
//   }
//   toggleCollapse1() {
//     this.isFormCollapsed = !this.isFormCollapsed;
//   }
//   toggleCollapse2() {
//     this.isFormCollapsed2 = !this.isFormCollapsed2;
//   }
// }
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-term-loan',
  templateUrl: './term-loan.component.html',
  styleUrls: ['./term-loan.component.css']
})
export class TermLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
 
  termForm!: FormGroup;
  
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.termForm = this.formBuilder.group({
      productDescription: [''],
      manageFeeBasedOnLoan: [false]
    
      // Add more form controls as needed
    });
  }

  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }
  
  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }
}
