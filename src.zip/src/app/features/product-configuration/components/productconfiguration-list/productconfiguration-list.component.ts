import { Component, OnInit } from '@angular/core';
import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { Router } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { DialogboxComponent } from 'src/app/shared/helpers/dialogbox/dialogbox.component';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-productconfiguration-list',
  templateUrl: './productconfiguration-list.component.html',
  styleUrls: ['./productconfiguration-list.component.css']
})
export class ProductconfigurationListComponent implements OnInit {
  // flag1 :boolean = false
  variable1 = "pratham jadhav"
  columnDefinitions1: Column[] = [];
  gridOptions1: GridOption;
  dataset1: any[] = [];
  productslists: any = [];
  selectedItemId!: number;
  items = [
    {
      id: "hello1",

    },
    {
      id: "hello12",

    },
    {
      id: "hello13",

    },
    {
      id: "hello14",

    },
    {
      id: "hello15",

    },
    {
      id: "hello16",

    },
    {
      id: "hello17",

    },
    {
      id: "hello18",

    }
  ];
  currentItemIndex: number = 0;
  flag: boolean = false;

  constructor(private router: Router, public apiService: ApiFacadeService, public api: ApiService, public dialog: MatDialog, private toastr: ToastrService, public formBuilder: FormBuilder) {
    this.gridOptions1 = {
      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 500,
      gridWidth: 1500,
      enableFiltering: true,
      enableCellNavigation: true,
      enableCheckboxSelector: true,
      checkboxSelector: {
        // you can toggle these 2 properties to show the "select all" checkbox in different location
        columnIndexPosition: 0,
        hideInFilterHeaderRow: false,
        hideInColumnTitleRow: true
      },

      enableRowSelection: true,
      rowSelectionOptions: {
        // True (Single Selection), False (Multiple Selections)
        selectActiveRow: false
      },
      dataView: {
        syncGridSelection: true, // enable this flag so that the row selection follows the row even if we move it to another position
      },
    };
  }
  paginationConfigForListGrid: any = {
    totalItems: 0,
    itemsPerPage: 100,
    currentPage: 1,
  };

  ngOnInit(): void {



    this.columnDefinitions1 = [

      { id: 'productName', name: 'Product Name', field: 'productName', filterable: true, maxWidth: 200, sortable: true },
      { id: 'typeOfLoan', name: 'Type Of Loan', field: 'typeOfLoan', filterable: true, maxWidth: 250, sortable: true },
      { id: 'isBcPartner', name: 'Product Type', field: 'isBcPartner', filterable: true, maxWidth: 250, sortable: true },
      { id: 'userName', name: 'Parent Product', field: 'userName', filterable: true, maxWidth: 250, sortable: true },
      { id: 'isActive', name: 'BC Partners', field: 'isActive', filterable: true, maxWidth: 250, sortable: true },

      { id: 'parentProductName', name: 'parentProductName', field: 'parentProductName', filterable: true, maxWidth: 150, sortable: true },
      { id: 'Status', name: 'isActive', field: 'isActive', maxWidth: 150, sortable: true, filterable: true },

      {
        id: 'action',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext", args.dataContext.productId);
          this.selectedItemId = args.dataContext.productId;
          console.log("product-id ", this.selectedItemId);
          this.router.navigate(['/productconfiguration-form'], { queryParams: { productId: args.dataContext.productId } });
        },

        formatter: Formatters.editIcon
      },
      {
        id: 'delete',
        name: 'Action',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext prtham", args.dataContext.productId);
          this.selectedItemId = args.dataContext.productId;
          this.openDialog(e, args);

        },
        formatter: Formatters.deleteIcon
      },
      {

        id: 'clone',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,

        formatter: this.cloneIconFormatter,

      }
    ];


    this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
  }
  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable"  style="cursor: pointer;"></i> `;
  }



  route() {
    this.router.navigate(['/productconfiguration-form'])
  }



  async getAllproductslists() {
    this.productslists = await this.apiService.getAllProductlist();

    console.log('hello', this.productslists);
  }


  async getAllFundSource(pageNumber: number, pageSize: number) {
    console.log('inside getAllBranchs facade')
    return new Promise(resolve => {
      return this.api.getDetailsPagination(GlobalUrlService.slick, pageNumber, pageSize).subscribe((res: any) => {
        console.log("ress==>", res);

        this.productslists = res.data;
        console.log("this.branches", this.productslists);

        this.productslists.forEach((item: { id: any; }, index: number) => {
          item.id = index + 1;
        });
        this.dataset1 = this.productslists;
        console.log("this.branches==", this.dataset1);

        console.log("branches==========", this.productslists);
        resolve(this.productslists);
      });
    })

  }

  openDialog(action: any, obj: any) {

    obj.action = action;

    console.log("Inside the dialog ");
    const dialogRef = this.dialog.open(DialogboxComponent, {

      width: '250px',
      data: { message: 'Do you want to delete this item?' }
    })


    dialogRef.afterClosed().subscribe((result: boolean) => {

      if (result === true) {
        console.log("Inside the dialog 2234");
        this.deleteData();
      }
    });

  }
  async deleteData() {
    console.log("****686865353.29698653****")
    console.log("Selected item", this.selectedItemId);
    this.toastr.success('Item deleted successfully!', 'Success');
    await this.apiService.deleteProductById(this.selectedItemId)
    console.log("fundsource id", this.selectedItemId);
    console.log("************")

    await this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);



    this.router.navigate(['/productconfiguration-list']);
  }

  visible(){
  this.flag = !this.flag
  }


}

