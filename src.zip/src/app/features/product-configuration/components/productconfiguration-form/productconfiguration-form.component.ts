import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-productconfiguration-form',
  templateUrl: './productconfiguration-form.component.html',
  styleUrls: ['./productconfiguration-form.component.css']
})
export class ProductconfigurationFormComponent implements OnInit {
  selectedProductTypes: boolean[] = [];
   selectedValues :any;

  

  isFormCollapsed: boolean = true;
 

  productTypes = [
    { value: 'type1', label: 'Term Loan' },
    { value: 'type2', label: 'Kuch to Loan  ' },
    // ... add more product types
  ];
  // subIndustries = [
  //   { value: 'subIndustry1', label: 'Sub-industry 1' },
  //   { value: 'subIndustry2', label: 'Sub-industry 2' },
  //   // ... add more sub-industries
  // ];
  
  industries = [
    { value: 'financialServices', label: 'Financial Services' },
    { value: 'healthcare', label: 'Healthcare' },
    // ... add other industries
  ];

  subIndustriesMapping: { [key: string]: string[] } = { // Provide an index signature
    financialServices: [
      'biotechnology',
      'telemedicine',
      'banking',
      'assetManagement',
      // ... add other sub-industries
    ],
    healthcare: [
      'medicalDevices',
      'pharmaceuticals',
      // ... add other sub-industries
    ],
    // ... add mappings for other industries
  };


  productForm!: FormGroup;





  constructor(
    private formBuilder:FormBuilder
  ) { }

ngOnInit(): void {

  this.productForm = this.formBuilder.group({
    isRenewal: [null, ],
    correspondingFreshProduct: [null, ],
    productName: [null, ],
    productDescription: [null, ],
    productCode: [null, ],
    parentProduct: [null, ],
    category: [null, ],
    productType: [null,[] ],
    companyName: [null, ],
    allowedIndustries: [ []],
    allowedSubIndustries: [[] ],
    securedProduct: [null, ],
    UnsecuredProduct: [null, ],
    branch: [null, ],
    maxOutstanding: [null, ],
    bcPartner: [null, ],
    
  });
}




toggleCollapse() {
  this.isFormCollapsed = !this.isFormCollapsed;
}
onAllowedIndustriesChange(selectedIndustries: string[]): void {
  const selectedSubIndustries = selectedIndustries.flatMap(industry =>
    this.subIndustriesMapping[industry]
  );
  this.productForm.patchValue({ allowedSubIndustries: selectedSubIndustries });
}
getSubIndustriesForSelectedIndustries(selectedIndustries: string[]): any[] {
  let subIndustries: any[] = [];
  selectedIndustries.forEach(industry => {
    if (this.subIndustriesMapping[industry]) {
      subIndustries = subIndustries.concat(this.subIndustriesMapping[industry]);
    }
  });
  return subIndustries;
}
onProductTypeChange(): void {
  this.selectedValues = this.productForm.get('productType')?.value || [];
 // this.selectedProductTypes = this.productTypes.map(type => selectedValues.includes(type.value));
}
}
