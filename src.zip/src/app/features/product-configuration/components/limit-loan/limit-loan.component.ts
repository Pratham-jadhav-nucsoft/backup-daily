//limitform.ts 
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';
import { EventEmitter, Output } from '@angular/core';
@Component({
  selector: 'app-limit-loan',
  templateUrl: './limit-loan.component.html',
  styleUrls: ['./limit-loan.component.css']
})
export class LimitLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  @Output() formControlsChange = new EventEmitter<FormGroup>();
  limitForm!: FormGroup;
  selectedodeList: any = [];
  selectedinterestCalMethodList: any = [];
  selectedminimumAmountDueCalculationMethodList: any = [];
  selectedPenalInterestCalculationMethodsList: any = [];
  selectedStatementCycleList: any = [];
  params: any;
  editingMode: boolean = false;
  showTickIcon: { [key: string]: boolean } = {};

  constructor(private formBuilder: FormBuilder, public apiService: ApiFacadeService, public activate: ActivatedRoute) {
    this.activate.queryParams.subscribe(productId => {
      this.params = productId;
      console.log("this.params", this.params);
      if (productId['productId']) {
        this.editingMode = true;
      }

    })
  }

  ngOnInit(): void {
    this.limitForm = this.formBuilder.group({

      minLimitTicketSize: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      maxLimitTicketSize: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      disbMonth: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      repaymentMonth: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      totalMonth: [null,],
      increaseDecreaseLoanLimit: [null, [Validators.minLength(1), Validators.maxLength(15)]],
      gracePeriod: [null, [Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      statementDateCode: [null, Validators.required],
      interestPercentage: [null, [Validators.required, Validators.min(1), Validators.max(100)]],
      interestEffectiveDate: [null,],
      penalRateOfInterestPercentage: [null, [Validators.required, Validators.max(100)]],
      penalEffectiveDate: [null,],
      minimumPaymentPercentage: [null, Validators.required],
      processingFeePercentage: [null, Validators.max(100)],
      gstPercentage: [null, [Validators.max(100), Validators.required]],
      chequeBounceCharges: [null, Validators.required],
      nachBounceCharges: [null, [Validators.max(100), Validators.required]],
      tolerancePeriod: [null, Validators.required],
      minimumDisbursement: [null, Validators.required],
      toleranceAmount: [null],
      dpdToleranceAmount: [null],
      orderDisbursementEventCode: [null,],
      interestCalculationMethodCode: [null],
      penalInterestCalculationMethodCode: [null],
      minimumAmountDueCalculationMethodCode: [null],
      coolingPeriodHrs: [null, Validators.required],

    });
    this.limitForm.get('disbMonth')?.valueChanges.subscribe(() => {
      this.updatetotalMonth();
    });

    this.limitForm.get('repaymentMonth')?.valueChanges.subscribe(() => {
      this.updatetotalMonth();
    });
    this.getAllODEs()
    this.getAllinterestCalMethods()
    this.getMinimumAccountDueCalculationMethods()
    this.getPenalInterestCalculationMethods()
    this.fetchProductData();
    this.getAllStatementCycles();
    this.sendFormControls();
  }
  onInputChange(fieldName: string) {
    const inputValue = this.limitForm.get(fieldName)?.value;
    this.showTickIcon[fieldName] = inputValue.trim().length > 0;
  }
  sendFormControls() {
    this.formControlsChange.emit(this.limitForm);
  }
  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }

  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }
  updatetotalMonth() {
    const disbMonth = this.limitForm.get('disbMonth')?.value || 0;
    const repaymentMonth = this.limitForm.get('repaymentMonth')?.value || 0;

    const totalMonth = disbMonth + repaymentMonth;

    this.limitForm.get('totalMonth')?.setValue(totalMonth);

  }



  async getAllODEs() {
    console.log('adadadad');
    this.selectedodeList = await this.apiService.getAllODE();
    console.log(" category->>>>", this.selectedodeList);
  }
  async getAllinterestCalMethods() {
    console.log('adadadad');
    this.selectedinterestCalMethodList = await this.apiService.getAllinterestCalMethod();
    console.log(" category->>>>", this.selectedinterestCalMethodList);
  }
  async getMinimumAccountDueCalculationMethods() {
    console.log('adadadad');
    this.selectedminimumAmountDueCalculationMethodList = await this.apiService.getMinimumAccountDueCalculationMethod();
    console.log(" category->>>>", this.selectedminimumAmountDueCalculationMethodList);
  }
  async getPenalInterestCalculationMethods() {
    console.log('adadadad');
    this.selectedPenalInterestCalculationMethodsList = await this.apiService.getPenalInterestCalculationMethod();
    console.log(" category->>>>", this.selectedPenalInterestCalculationMethodsList);
  }
  async getAllStatementCycles() {
    console.log('adadadad');
    this.selectedStatementCycleList = await this.apiService.getAllStatementCycle();
    console.log(" category->>>>", this.selectedStatementCycleList);
  }


  async fetchProductData(): Promise<void> {

    try {
      if (this.params.productId) {
        const productData: any = await this.apiService.getProductById2(this.params.productId);
        console.log('  this.limitForm.->>>>>>>>>>>>>>>>>>>', productData);

        if (productData) {
          if (productData.listOfLimitLoan != null) {
            this.limitForm.patchValue({
              minLimitTicketSize: productData.listOfLimitLoan[0].minLimitTicketSize,
              maxLimitTicketSize: productData.listOfLimitLoan[0].maxLimitTicketSize,
              disbMonth: productData.listOfLimitLoan[0].disbMonth,
              repaymentMonth: productData.listOfLimitLoan[0].repaymentMonth,
              totalMonth: productData.listOfLimitLoan[0].totalMonth,
              increaseDecreaseLoanLimit: productData.listOfLimitLoan[0].increaseDecreaseLoanLimit,
              gracePeriod: productData.listOfLimitLoan[0].gracePeriod,
              statementDateCode: productData.listOfLimitLoan[0].statementDateCode,
              interestPercentage: productData.listOfLimitLoan[0].interestPercentage,
              interestEffectiveDate: productData.listOfLimitLoan[0].interestEffectiveDate,
              penalRateOfInterestPercentage: productData.listOfLimitLoan[0].penalRateOfInterestPercentage,
              penalEffectiveDate: productData.listOfLimitLoan[0].penalEffectiveDate,
              minimumPaymentPercentage: productData.listOfLimitLoan[0].minimumPaymentPercentage,
              processingFeePercentage: productData.listOfLimitLoan[0].processingFeePercentage,
              gstPercentage: productData.listOfLimitLoan[0].gstPercentage,
              chequeBounceCharges: productData.listOfLimitLoan[0].chequeBounceCharges,
              nachBounceCharges: productData.listOfLimitLoan[0].nachBounceCharges,
              tolerancePeriod: productData.listOfLimitLoan[0].tolerancePeriod,
              minimumDisbursement: productData.listOfLimitLoan[0].minimumDisbursement,
              toleranceAmount: productData.listOfLimitLoan[0].toleranceAmount,
              dpdToleranceAmount: productData.listOfLimitLoan[0].dpdToleranceAmount,
              orderDisbursementEventCode: productData.listOfLimitLoan[0].orderDisbursementEventCode,
              interestCalculationMethodCode: productData.listOfLimitLoan[0].interestCalculationMethodCode,
              penalInterestCalculationMethodCode: productData.listOfLimitLoan[0].penalInterestCalculationMethodCode,
              minimumAmountDueCalculationMethodCode: productData.listOfLimitLoan[0].minimumAmountDueCalculationMethodCode,
              coolingPeriodHrs: productData.listOfLimitLoan[0].coolingPeriodHrs,
              isActive: productData.listOfLimitLoan[0].isActive,
              isDeleted: productData.listOfLimitLoan[0].isDeleted,
              createdBy: productData.listOfLimitLoan[0].createdBy,
              createdDate: productData.listOfLimitLoan[0].createdDate,
              updatedBy: productData.listOfLimitLoan[0].updatedBy,
              updatedDate: productData.listOfLimitLoan[0].updatedDate,
            });
          }
          this.limitForm.markAllAsTouched()
          console.log('limitproductData---------------->', productData);
        } else {
          console.error('Failed to fetch product data.');
        }
      }
      // const productData :any = await this.apiService.getProductById2(this.params.productId);

    } catch (error) {
      console.error('Error while fetching data by ID1:', error);
    }
  }

}
