import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductconfigurationFormComponent } from './productconfiguration-form.component';

describe('ProductconfigurationFormComponent', () => {
  let component: ProductconfigurationFormComponent;
  let fixture: ComponentFixture<ProductconfigurationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductconfigurationFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductconfigurationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
