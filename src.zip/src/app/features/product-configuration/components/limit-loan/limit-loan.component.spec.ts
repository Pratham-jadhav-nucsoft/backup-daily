import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LimitLoanComponent } from './limit-loan.component';

describe('LimitLoanComponent', () => {
  let component: LimitLoanComponent;
  let fixture: ComponentFixture<LimitLoanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LimitLoanComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LimitLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
