import { Component, OnInit } from '@angular/core';
import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { Router } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { DialogboxComponent } from 'src/app/shared/helpers/dialogbox/dialogbox.component';
import { MatDialog } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-productconfiguration-list',
  templateUrl: './productconfiguration-list.component.html',
  styleUrls: ['./productconfiguration-list.component.css']
})
export class ProductconfigurationListComponent implements OnInit {


  columnDefinitions1: Column[] = [];
  gridOptions1: GridOption;
  dataset1: any[] = []; 
  productslists: any = [];
  selectedItemId!: number;

  constructor( private router: Router, public apiService: ApiFacadeService,public api: ApiService,public dialog: MatDialog,  private toastr: ToastrService,) {  this.gridOptions1 = {
    enableAutoResize: false,
    enableSorting: true,
    gridHeight: 500,
    gridWidth: 1500,
    enableFiltering: true,
    enableCellNavigation: true,
    enableCheckboxSelector: true, 
    checkboxSelector: {
      // you can toggle these 2 properties to show the "select all" checkbox in different location
      hideInFilterHeaderRow: false,
      hideInColumnTitleRow: true
    },
  };  
  }
  paginationConfigForListGrid: any = {
    totalItems: 0,
    itemsPerPage: 100,
    currentPage: 1,
  };

  ngOnInit(): void {
    this.columnDefinitions1 = [
      
      { id: 'productName', name: 'Product Name', field: 'productName', filterable: true,  maxWidth: 200, sortable: true },
      { id: 'typeOfLoan', name: 'Type Of Loan', field: 'typeOfLoan', filterable: true, maxWidth: 250, sortable: true },
      { id: 'isBcPartner', name: 'Product Type', field: 'isBcPartner', filterable: true, maxWidth: 250,  sortable: true },
      { id: 'userName', name: 'Parent Product', field: 'userName', filterable: true, maxWidth: 250, sortable: true },
      { id: 'isActive', name: 'BC Partners', field: 'isActive', filterable: true, maxWidth: 250,  sortable: true },
      
      { id: 'parentProductName', name: 'parentProductName', field: 'parentProductName', filterable: true, maxWidth: 150,sortable: true },
      { id: 'Status', name: 'isActive', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
      
      {
        id: 'action',
        
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        formatter: Formatters.editIcon
      },
      {
        id: 'delete',
        name: 'Action',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext prtham",args.dataContext.productId);
          this.selectedItemId = args.dataContext.productId;
          this.openDialog(e, args);

        },
        formatter: Formatters.deleteIcon
      },
      {



        id: 'clone',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        
        formatter: this.cloneIconFormatter,

      }
    ];
  // Define your hardcoded dataset
  // this.dataset1 =
  //  [
  //   {
  //     id: 1,
    
  //     sequence: 'Item 1',
  //     accountNumber: '12345',
  //     accountName: 'Type A',
  //     bankId: 'Parent A',
  //     description: 'Partner A',
  //     ifscCode: 'IFSC123',
  //     address: 'Address A',
  //     isActive: true
  //   },
  //   {
  //     id: 2,
    
  //     sequence: 'Item 2',
  //     accountNumber: '67890',
  //     accountName: 'Type B',
  //     bankId: 'Parent B',
  //     description: 'Partner B',
  //     ifscCode: 'IFSC456',
  //     address: 'Address B',
  //     isActive: false
  //   },
    // ... add more data objects
  // ];
  this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
  }
  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable"  style="cursor: pointer;"></i> `;
  }
  


  route(){
    this.router.navigate(['/productconfiguration-form'])
  }


  
  async getAllproductslists() {
    this.productslists = await this.apiService.getAllProductlist();

    console.log('hello', this.productslists);
  }


  async getAllFundSource(pageNumber: number, pageSize: number) {
    console.log('inside getAllBranchs facade')
    return new Promise(resolve => {
      return this.api.getDetailsPagination(GlobalUrlService.slick, pageNumber, pageSize).subscribe((res: any) => {
        console.log("ress==>", res);

        this.productslists = res.data;
        console.log("this.branches", this.productslists);

        this.productslists.forEach((item: { id: any; }, index: number) => {
          item.id = index + 1;
        });
        this.dataset1 = this.productslists;
        console.log("this.branches==", this.dataset1);

        console.log("branches==========", this.productslists);
        resolve(this.productslists);
      });
    })

  }

  openDialog(action: any, obj: any) {

    obj.action = action;

  console.log("Inside the dialog ");
 const dialogRef= this.dialog.open(DialogboxComponent, {  

    width: '250px',
    data: { message: 'Do you want to delete this item?' }
      })

  //  const result=this.box.onYesClick();
  dialogRef.afterClosed().subscribe((result:boolean) => {
    // console.log(result);
      // result=true;
    if (result === true) {
      console.log("Inside the dialog 2234");
      // this.branchFacade.deleteItemById(this.selectedItemId);
      this.deleteData();
    }
  });

}
async deleteData() {
  console.log("****686865353.29698653****")
  console.log("Selected item",this.selectedItemId);
  this.toastr.success('Item deleted successfully!', 'Success');
  await this.apiService.deleteProductById(this.selectedItemId)
  console.log("fundsource id", this.selectedItemId);
  console.log("************")

  await this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
  console.log("************")


 this.router.navigate(['/productconfiguration-list']);
}

}

