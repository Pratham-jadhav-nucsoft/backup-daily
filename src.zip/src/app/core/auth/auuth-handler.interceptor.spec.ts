import { TestBed } from '@angular/core/testing';

import { AuuthHandlerInterceptor } from './auuth-handler.interceptor';

describe('AuuthHandlerInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      AuuthHandlerInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: AuuthHandlerInterceptor = TestBed.inject(AuuthHandlerInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
