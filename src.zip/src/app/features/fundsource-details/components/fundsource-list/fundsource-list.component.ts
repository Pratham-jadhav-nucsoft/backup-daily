import { FileStatusComponent } from 'src/app/shared/helpers/file-status/file-status.component';
import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { HttpClient } from '@angular/common/http';
import { ApiFacadeService } from 'src/app/features/facade';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DialogboxComponent } from 'src/app/shared/helpers/dialogbox/dialogbox.component';
import * as XLSX from 'xlsx';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { FullscreenOverlayContainer } from '@angular/cdk/overlay';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { event } from 'jquery';
import { Router } from '@angular/router';
import { saveAs } from 'file-saver';
import { ToastrService } from 'ngx-toastr';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
@Component({
  selector: 'app-fundsource-list',
  templateUrl: './fundsource-list.component.html',
  styleUrls: ['./fundsource-list.component.css'],

})
export class FundsourceListComponent implements OnInit {
  // @ViewChild(DialogboxComponent)
  // dialogBox!: DialogboxComponent;


  @ViewChild('fileInput') fileInput!: ElementRef<HTMLInputElement>;


  selectedFile: File | null = null;
  loggedInUserId:string ="admin"
  columnDefinitions1: Column[] = [];
  gridOptions1: GridOption;
  dataset1!: any[];
  selectedItemId!: number;
  page = 1;
  pageSize = 1000;
  currentPage = 1;
  fundsources: any = [];
  angularGrid: any;
  listOfSuccessFailureRecords: any;
  listOfSuccessRecords: any;
  listOfFailureRecords: any;
  fileSuccessFailureColumnDefinitions: any[]= [];
  successFailureHeaders: any;

  constructor(private http: HttpClient,private cdr: ChangeDetectorRef,public toastr: ToastrService, public apiService: ApiFacadeService, public dialog: MatDialog, public api: ApiService, private router: Router) 
  {
    this.gridOptions1 = {
      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 500,
      gridWidth: 1500,
      enableFiltering: true,
      enableCellNavigation: true, // Enable cell navigation to handle click events
    };  
    this.selectedFile = null;
  }
  
  paginationConfigForListGrid: any = {
    totalItems: 0,
    itemsPerPage: 5,
    currentPage: 1,
  };



  ngOnInit(): void {

    if (this.loggedInUserId === 'admin') {
    this.columnDefinitions1 = [
      {
        id: 'isAnchorTagged',
        name: 'Anchor Tag',
        field: 'isAnchorTagged',
        maxWidth: 100,
        formatter: this.anchorTagFormatter, // Add the formatter for the checkbox column
      },
      { id: 'sequence', name: 'sequence', field: 'sequence', filterable: true, formatter: this.numberAlignFormatter, maxWidth: 80, sortable: true },
      { id: 'accountNumber', name: 'accountNumber', field: 'accountNumber', filterable: true, maxWidth: 140, formatter: this.numberAlignFormatter, sortable: true },
      { id: 'accountName', name: 'accountName', field: 'accountName', filterable: true, maxWidth: 140, formatter: this.textAlignFormatter, sortable: true },
      { id: 'bankId', name: 'bankId', field: 'bankId', filterable: true, maxWidth: 150, formatter: this.textAlignFormatter, sortable: true },
      { id: 'description', name: 'description', field: 'description', filterable: true, maxWidth: 250, formatter: this.textAlignFormatter, sortable: true },
      
      { id: 'ifscID', name: 'ifscID', field: 'ifscCode', filterable: true, maxWidth: 120, formatter: this.numberAlignFormatter, sortable: true },
      { id: 'address', name: 'address', field: 'address', filterable: true, maxWidth: 150, formatter: this.textAlignFormatter, sortable: true },
      { id: 'isActive', name: 'isActive', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true,formatter: this.statusFormatter  },
      { id: 'phoneNumber', name: 'phoneNumber', field: 'phoneNumber', filterable: true, formatter: this.numberAlignFormatter, sortable: true },
      {
        id: 'action',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext", args.dataContext.fundSourceId);
          this.selectedItemId = args.dataContext.fundSourceId;
          console.log("fundsource-id ", this.selectedItemId);
          this.router.navigate(['/fundsource-form'], { queryParams: { selectedItemId: args.dataContext.fundSourceId } });
        },

        formatter: Formatters.editIcon
      },
      {
        id: 'delete',
        name: 'Action',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext prtham",args.dataContext.fundSourceId);
          this.selectedItemId = args.dataContext.fundSourceId;
          this.openDialog(e, args);

        },
        formatter: Formatters.deleteIcon
      },
      {



        id: 'clone',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext", args.dataContext.fundSourceId);
          this.selectedItemId = args.dataContext.fundSourceId;
          console.log(this.selectedItemId);

          this.router.navigate(['/fundsource-form'], { queryParams: { selectedItemId: args.dataContext.fundSourceId, cloneFlag: 1 } });
        },
        formatter: this.cloneIconFormatter,// Use the custom formatter function

      }
    ];

  }



else{


  this.columnDefinitions1 = [
    {
      id: 'isAnchorTagged',
      name: 'Anchor Tag',
      field: 'isAnchorTagged',
      maxWidth: 100,
      formatter: this.anchorTagFormatter, // Add the formatter for the checkbox column
    },
    { id: 'sequence', name: 'sequence', field: 'sequence', filterable: true, formatter: this.numberAlignFormatter, maxWidth: 80, sortable: true },
    { id: 'accountNumber', name: 'accountNumber', field: 'accountNumber', filterable: true, maxWidth: 140, formatter: this.numberAlignFormatter, sortable: true },
    { id: 'accountName', name: 'accountName', field: 'accountName', filterable: true, maxWidth: 140, formatter: this.textAlignFormatter, sortable: true },
    { id: 'bankName', name: 'bankName', field: 'bankName', filterable: true, maxWidth: 150, formatter: this.textAlignFormatter, sortable: true },
    { id: 'description', name: 'description', field: 'description', filterable: true, maxWidth: 250, formatter: this.textAlignFormatter, sortable: true },
    { id: 'ifscCode', name: 'ifscID', field: 'ifscCode', filterable: true, maxWidth: 120, formatter: this.numberAlignFormatter, sortable: true },
   
    { id: 'address', name: 'address', field: 'address', filterable: true, maxWidth: 150, formatter: this.textAlignFormatter, sortable: true },
    { id: 'isActive', name: 'isActive', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true,formatter: this.statusFormatter  },

    { id: 'phoneNumber', name: 'phoneNumber', field: 'phoneNumber', filterable: true, formatter: this.numberAlignFormatter, sortable: true },
   
   
   
    {
      id: 'action',
      field: 'id',
      excludeFromColumnPicker: true,
      excludeFromGridMenu: true,
      excludeFromHeaderMenu: true,
      sortable: false,
      maxWidth: 50,
      onCellClick: (e: Event, args: OnEventArgs) => {
        if (args.dataContext.isAnchorTagged !== true && this.loggedInUserId === 'user') {
          this.selectedItemId = args.dataContext.fundSourceId;
          this.router.navigate(['/fundsource-form'], { queryParams: { selectedItemId: args.dataContext.fundSourceId } });
        }
      },
      formatter: (row: number, cell: number, value: any, columnDef: Column, dataContext: any) => {
        if (dataContext.isAnchorTagged !== true) {
          return `<i class="fa fa-edit clickable" style="cursor: pointer;" title="Edit"></i>`;
        } else {
          return '<i class="fa fa-edit faded-icon"  title="Disable anchor" ></i>';
        }
      }
    },
    

         
{
  id: 'delete',
  name: 'Action',
  field: 'id',
  excludeFromColumnPicker: true,
  excludeFromGridMenu: true,
  excludeFromHeaderMenu: true,
  sortable: false,
  maxWidth: 50,
  onCellClick: (e: Event, args: OnEventArgs) => {
    if (args.dataContext.isAnchorTagged !== true && this.loggedInUserId === 'user') {
      this.selectedItemId = args.dataContext.fundSourceId;
      this.openDialog(e, args);
    }
  },
  formatter: (row: number, cell: number, value: any, columnDef: Column, dataContext: any) => {
    if (dataContext.isAnchorTagged !== true && this.loggedInUserId === 'user') {
      return `<i class="fa fa-trash clickable" style="cursor: pointer;" title="Delete"></i>`;
    } else {
      return '<i class="fa fa-trash  faded-icon" title="Disable anchor"></i>';
    }
  }
},
{
  id: 'clone',
  field: 'id',
  excludeFromColumnPicker: true,
  excludeFromGridMenu: true,
  excludeFromHeaderMenu: true,
  sortable: false,
  maxWidth: 50,
  onCellClick: (e: Event, args: OnEventArgs) => {
    if (args.dataContext.isAnchorTagged !== true && this.loggedInUserId === 'user') {
      console.log("args.dataContext", args.dataContext.fundSourceId);
      this.selectedItemId = args.dataContext.fundSourceId;
      console.log(this.selectedItemId);
      this.router.navigate(['/fundsource-form'], { queryParams: { selectedItemId: args.dataContext.fundSourceId, cloneFlag: 1 } });
    }
  },
  formatter: (row: number, cell: number, value: any, columnDef: Column, dataContext: any) => {
    if (dataContext.isAnchorTagged !== true && this.loggedInUserId === 'user') {
      return `<i class="fa fa-clone clickable" style="cursor: pointer;" title="Clone"></i>`;
    } else {
      return '<i class="fa fa-clone faded-icon" title="Disable anchor"></i>';
    }
  }
}
  ];



}


    /////////////ngonit
    this.intializefileSuccFailureColumnsDefinations();
    this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
  }

  
  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable"  style="cursor: pointer;"></i> `;
  }
  
  
  statusFormatter( value: any): string {
    if (value==true) {
      return '<span style="color: green;">Active</span>';
    } else {
      return '<span style="color: red;">Inactive</span>';
    }
  }


  numberAlignFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<div style="text-align: right;">${value}</div>`;
  }


  textAlignFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<div style="text-align: left;">${value}</div>`;
  }

  handleCellClick(event: Event, args: any): void {
    const actionColumnId = 'clone';
    if (args.cell === this.columnDefinitions1.findIndex((c) => c.id === actionColumnId)) {
      this.cloneItem(args.row); // Handle the clone action, you can implement your own logic here
    }
  }

  cloneItem(row: number): void {
    console.log('Clone icon clicked on row:', row);
    // Implement your logic for the cloning operation here
  }


  pageChange(page: number): void {
    this.currentPage = page;
  }

  addNewUser(): void {
    // Add your logic for adding a new user here
  }


 

  async getAllFundSources() {
    this.fundsources = await this.apiService.getAllFundSource();

    console.log('hello', this.fundsources);
  }


  async getAllFundSource(pageNumber: number, pageSize: number) {
    console.log('inside getAllBranchs facade')
    return new Promise(resolve => {
      return this.api.getDetailsPagination(GlobalUrlService.fundsource, pageNumber, pageSize).subscribe((res: any) => {
        console.log("ress==>", res);

        this.fundsources = res.data;
        console.log("this.branches", this.fundsources);

        this.fundsources.forEach((item: { id: any; }, index: number) => {
          item.id = index + 1;
        });
        this.dataset1 = this.fundsources;
        console.log("this.branches==", this.dataset1);

        console.log("branches==========", this.fundsources);
        resolve(this.fundsources);
      });
    })

  }

  // exportData(): void {
  //   // Convert the data to a CSV format
  //   const csvContent = this.convertToCSV(this.dataset1);

  //   // Create a Blob with the data
  //   const blob = new Blob([csvContent], { type: 'text/csv' });

  //   // Trigger the download using FileSaver.js
  //   saveAs(blob, 'exported_data.csv');
  // }
  convertToCSV(data: any[]): string {
    // Initialize the CSV content with the header row
    let csvContent = 'Sequence,Ifsc Code,Micr Code\n'; // here you must replace this to your column titles of list 

    // Iterate through the data and add each row to the CSV content
    for (const item of data) {
      const row = `${item.sequence},${item.ifscCode},${item.micrCode}\n`;  // here you must replace sequence , ifscCode and micrCode to your column titles of list 
      csvContent += row;
    }

    return csvContent;
  }

  exportData(): void {
    const exportUrl = GlobalUrlService.export; // Adjust the import and usage based on your setup
    this.api.getExport(exportUrl).subscribe(
      (data) => {
        // Handle the exported data here (e.g., save it to a file or display a success notification)
        console.log('Exported data:', data);
        this.toastr.success('Data exported successfully!', 'Success');

        // Assuming data is an array of objects
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.json_to_sheet(data);

        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/octet-stream' });
        saveAs(blob, 'exported_data.xlsx');

        console.log('Exported============>');
      },
      (error) => {
        console.error('Error exporting data:', error);
        this.toastr.error('Error exporting data', 'Error');
      }
    );
  }


  ////////////////////////////


  onDeleteRecord(fundSourceId: number): void {
    this.selectedItemId = fundSourceId;
    this.openDialog('delete', { fundSourceId });
   
  }





  openDialog(action: any, obj: any) {

      obj.action = action;

    console.log("Inside the dialog ");
   const dialogRef= this.dialog.open(DialogboxComponent, {  

      width: '250px',
      data: { message: 'Do you want to delete this item?' }
        })

    //  const result=this.box.onYesClick();
    dialogRef.afterClosed().subscribe((result:boolean) => {
      // console.log(result);
        // result=true;
      if (result === true) {
        console.log("Inside the dialog 2234");
        // this.branchFacade.deleteItemById(this.selectedItemId);
        this.deleteData();
      }
    });

  }

  async deleteData() {
    console.log("****686865353.29698653****")
    console.log("Selected item",this.selectedItemId);
    this.toastr.success('Item deleted successfully!', 'Success');
    await this.apiService.deleteItemById(this.selectedItemId)
    console.log("fundsource id", this.selectedItemId);
    console.log("************")
 
    await this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
    console.log("************")
  

    // this.router.navigate(['/fundsource-list']);
  }

  //////editt code



  anchorTagFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    console.log(dataContext);

    if (dataContext.isAnchorTagged == true) {

      return '<i class="fa-solid fa-anchor" style="cursor: pointer;"></i>';

    } else {
      return '';
    }

  }
  async onAnchorTagChange(item: any, event: MatCheckboxChange): Promise<void> {
    item.isAnchorTagged = event.checked;
    this.cdr.detectChanges();
    try {
      // Call the API to update the anchor tag status on the server
      await this.apiService.getFundSourceById(item); // You might need to provide the correct method to update the item
    } catch (error) {
      console.error('Error updating the anchor tag status:', error);
      // If there's an error, handle it accordingly (e.g., show a toast or error message)
    }
  }
  
 //-----------------------------

 handleAnchorTagged(value: boolean): void {
  console.log('Anchor tag value---------------:', value);
  // Do whatever you need to do with the anchor tag value here
}

downloadTemplate(): void {
  this.apiService.downloadTemplate().subscribe(
    (data: Blob) => {
      const blobURL = URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = blobURL;
      link.download = 'template.xlsx'; 
      link.click();
    },
    (error) => {
      console.error('Error downloading template:', error);
    }
  );
}




// async uploadFile(): Promise<void> {
//   console.log(" Inside the upload function ", this.selectedFile);

//   if (this.selectedFile) {
//     try {
//       console.log(this.selectedFile);

//       const dataTransfer = new DataTransfer();
//       dataTransfer.items.add(this.selectedFile);
//       console.log(dataTransfer.files);
//       // Assuming you have the importFiles function in your ApiFacadeService
//       const result = await this.apiService.importFiles(dataTransfer.files);

//       this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);


//       console.log('Upload result:', result);

//       // Clear the file selection and hide the "Upload" button
//       this.selectedFile = null;
//     } catch (error) {
//       console.error('Upload error:', error);

//       // Handle upload error, display error message, etc.
//       // Example: this.toastr.error('Upload failed: ' + error.message, 'Error');
//     }
//   }
// }


// async uploadFile(): Promise<void> {
//   console.log(" Inside the upload function ", this.selectedFile);

//   if (this.selectedFile) {
//     try {
//       console.log(this.selectedFile);

      
      
//       let saveFileUploadResp = await this.apiService.uploadFile(this.selectedFile);
//     console.log("saveFileUploadResp",saveFileUploadResp);
    
//     this.listOfSuccessFailureRecords = saveFileUploadResp;
//     console.log("this.listOfSuccessFailureRecords", this.listOfSuccessFailureRecords);
//     this.listOfSuccessFailureRecords.success.data.forEach((item: { id: any; }, index: number) => {
//       item.id = index + 1;
//     });

//     this.listOfSuccessFailureRecords.failure.data.forEach((item: { id: any; }, index: number) => {
//       item.id = index + 1;
//     });

//     this.listOfSuccessRecords = this.listOfSuccessFailureRecords.success.data;
//     this.listOfFailureRecords = this.listOfSuccessFailureRecords.failure.data;

//     this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
//       // await this.toastr.success('File uploaded successfully!', 'Success');

//       console.log('Upload result:', saveFileUploadResp);
//     this.dialog.open(FileStatusComponent, {
//       width: '2000px',
//       height: '600px',
//       data: {
//         columnDefinitions: this.columnDefinitions1,
//         listOfSuccessRecords: this.listOfSuccessRecords,
//         listOfFailureRecords: this.listOfFailureRecords,
//         headers: this.successFailureHeaders,
//         successCount: this.listOfSuccessFailureRecords?.successCount,
//         failureCount: this.listOfSuccessFailureRecords?.failureCount,
//         gridOptions: this.gridOptions1,
//       }
      
//     });
      
   
     

    
//       this.selectedFile = null;
//     } 

//       catch (error) {
//       console.error('Upload error:', error);
//       this.toastr.error('Error uploading file !' , 'Error');

//     }
//   }
// }

async uploadFile() {
  console.log(" Inside the upload function ", this.selectedFile);

  if (this.selectedFile) {
    try {
      console.log(this.selectedFile);

      
      
      let saveFileUploadResp = await this.apiService.uploadFile(this.selectedFile);
    console.log("saveFileUploadResp",saveFileUploadResp);
    
    this.listOfSuccessFailureRecords = saveFileUploadResp;
    console.log("this.listOfSuccessFailureRecords", this.listOfSuccessFailureRecords);
    this.listOfSuccessFailureRecords.success.data.forEach((item: { id: any; }, index: number) => {
      item.id = index + 1;
    });

    this.listOfSuccessFailureRecords.failure.data.forEach((item: { id: any; }, index: number) => {
      item.id = index + 1;
    });

    this.listOfSuccessRecords = this.listOfSuccessFailureRecords.success.data;
    this.listOfFailureRecords = this.listOfSuccessFailureRecords.failure.data;
console.log(this.listOfSuccessFailureRecords.failure.data)
     await  this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
      // await this.toastr.success('File uploaded successfully!', 'Success');

      console.log('Upload result:', saveFileUploadResp);
    this.dialog.open(FileStatusComponent, {
      width: '2000px',
      height: '600px',
      data: {
        columnDefinitions: this.columnDefinitions1,
        listOfSuccessRecords: this.listOfSuccessRecords,
        listOfFailureRecords: this.listOfFailureRecords,
        headers: this.successFailureHeaders,
        successCount: this.listOfSuccessFailureRecords?.successCount,
        failureCount: this.listOfSuccessFailureRecords?.failureCount,
        
      }
      
    });
      
   
     

   

      // this.selectedFile = null;
    } 

      catch (error) {
      console.error('Upload error:', error);
      this.toastr.error('Error uploading file !' , 'Error');

    }
  }
}

// upload a file
  onFileSelected(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    if (inputElement.files && inputElement.files.length > 0) {
      this.selectedFile = inputElement.files[0];
    }
  }

clearFileSelection(): void {
  this.selectedFile = null;
  const fileInput = document.getElementById('fileInput') as HTMLInputElement;
  if (fileInput) {
    fileInput.value = '';
  }
}

importFile(): void {  
  if (this.selectedFile) {
    // Here, you can process the selected file for import using your desired logic.
    // For example, you can read the file content and perform the necessary operations.
    // Once the import is successful, you can clear the file selection if needed.
    this.clearFileSelection();
  }
}

///////dialog call for upload
openUploadDialog(): void {
  const dialogRef = this.dialog.open(DialogboxComponent, {
    data: { message: 'Are you sure you want to upload?' }
  });

  dialogRef.afterClosed().subscribe(result => {
    if (result === true) {
   
    } else {
      // Logic to handle the "No" action or cancel the upload process
    }
  });
}


openUploadDialog2(): void {
  const dialogRef = this.dialog.open(DialogboxComponent, {
     // Set the width of the dialog box as per your requirement
    data: { message: 'Are you sure you want to upload?' }
  });

  // Subscribe to the dialog after it is closed
  dialogRef.afterClosed().subscribe(async result => {
    if (result === true) {
     await this.uploadFile()
    
      
      
   
    } 
  });
}



private intializefileSuccFailureColumnsDefinations():void
    {
      this.fileSuccessFailureColumnDefinitions = [
        { id: 'error', name: 'Error Message', field: 'Errors', filterable: true, sortable: true, minWidth: 200, maxWidth: 350 },
        { id: 'isAnchorTagged', name: 'anchor', field: 'isAnchorTagged', maxWidth: 100, formatter: this.anchorTagFormatter },
        { id: 'sequence', name: 'sequence', field: 'sequence', sortable: true, filterable: true, maxWidth: 350 },
        { id: 'branchName', name: 'branchName', field: 'branchName', sortable: true, filterable: true, maxWidth: 350 },
        { id: 'branchCode', name: 'branchCode', field: 'branchCode', sortable: true, filterable: true, maxWidth: 350 },
        { id: 'address', name: 'address', field: 'address', sortable: true, filterable: true, maxWidth: 350 },
        { id: 'description', name: 'description', field: 'description', sortable: true, filterable: true, maxWidth: 350 },
        { id: 'status', name: 'status', field: 'status', sortable: true, filterable: true, maxWidth: 350, formatter: this.statusFormatter },
        {
          id: 'action',

          field: 'id',
          excludeFromColumnPicker: true,
          excludeFromGridMenu: true,
          excludeFromHeaderMenu: true,
          sortable: false,
          maxWidth: 50,
          onCellClick: (e: Event, args: OnEventArgs) => {
            console.log("args.dataContext", args.dataContext.branchId);
            this.selectedItemId = args.dataContext.branchId;
            console.log("branch_id ", this.selectedItemId);
            this.router.navigate(['/branch/form'], { queryParams: { selectedItemId: args.dataContext.branchId } })
            // this.openDialog(e, args);
          },
          formatter: Formatters.editIcon
        },
        {
          id: 'delete',
          name: 'Action',
          field: 'id',
          excludeFromColumnPicker: true,
          excludeFromGridMenu: true,
          excludeFromHeaderMenu: true,
          sortable: false,
          maxWidth: 50,
          onCellClick: (e: Event, args: OnEventArgs) => {
            console.log("args.dataContext", args.dataContext.branchId);
            this.selectedItemId = args.dataContext.branchId;
            this.openDialog(e, args);

          },
          formatter: Formatters.deleteIcon
        },
        {
          id: 'clone',

          field: 'id',
          excludeFromColumnPicker: true,
          excludeFromGridMenu: true,
          excludeFromHeaderMenu: true,
          sortable: false,
          maxWidth: 50,
          onCellClick: (e: Event, args: OnEventArgs) => {
            console.log("args.dataContext", args.dataContext.branchId);
            this.selectedItemId = args.dataContext.branchId;
            console.log("branch_id ", this.selectedItemId);
            this.router.navigate(['/branch/form'], { queryParams: { selectedItemId: args.dataContext.branchId, cloneFlag: 1 } })
            // this.openDialog(e, args);
          },
          formatter: this.cloneIconFormatter // Use the custom formatter function

        }
      ]
    }
  
}




