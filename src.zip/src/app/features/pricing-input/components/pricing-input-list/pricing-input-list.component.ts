import { Component, OnInit } from '@angular/core';
import { Column, Formatters, GridOption } from 'angular-slickgrid';

@Component({
  selector: 'app-pricing-input-list',
  templateUrl: './pricing-input-list.component.html',
  styleUrls: ['./pricing-input-list.component.css']
})
export class PricingInputListComponent implements OnInit {
  isFormVisible: boolean= false
  columnDefinitions1: Column[] = [];
  gridOptions1!: GridOption;
  dataset1: any[] = []; 

  constructor(
    
   
  ) { 
    this.gridOptions1 = {
      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 200,
      gridWidth: 1500,
      enableFiltering: true,
      enableCellNavigation: true,
      enableCheckboxSelector: true, 
      checkboxSelector: {
        // you can toggle these 2 properties to show the "select all" checkbox in different location
        hideInFilterHeaderRow: false,
        hideInColumnTitleRow: true
      },
    }; 

    this.columnDefinitions1 = [
      
      { id: 'Month', name: 'Month', field: 'month', filterable: true,  maxWidth: 100, sortable: true },
      { id: 'Type Of Loan', name: 'MID', field: 'accountNumber', filterable: true, maxWidth: 150, sortable: true },
      { id: 'Product Type', name: 'TID', field: 'accountName', filterable: true, maxWidth: 150,  sortable: true },
      { id: 'Parent Product', name: '#Txn', field: 'bankId', filterable: true, maxWidth: 150, sortable: true },
      { id: 'BC Partners', name: '#Batch', field: 'description', filterable: true, maxWidth: 250,  sortable: true },
      { id: 'Last Modified By', name: 'High Tix', field: 'ifscCode', filterable: true, maxWidth: 150,sortable: true },
      { id: 'Last Modified Date', name: 'Low Tix', field: 'address', filterable: true, maxWidth: 150,  sortable: true },
      { id: 'Status', name: 'Card Sales', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
      { id: 'AvgTix', name: 'Avg.Tix', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
      { id: 'AMEX', name: 'AMEX', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
      { id: 'Total', name: 'Total', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
      { id: 'Cash Sales', name: 'Cash Sales', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
      { id: 'ND', name: 'ND', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
      { id: 'Action', name: 'Action', field: 'isActive', maxWidth: 150, sortable: true ,filterable:true  },
    ];

    this.dataset1 = [
      {
        id: 1,
      
        sequence: 'Item 1',
        accountNumber: '12345',
        accountName: 'Type A',
        bankId: 'Parent A',
        description: 'Partner A',
        ifscCode: 'IFSC123',
        address: 'Address A',
        isActive: true
      },
      {
        id: 2,
      
        sequence: 'Item 2',
        accountNumber: '67890',
        accountName: 'Type B',
        bankId: 'Parent B',
        description: 'Partner B',
        ifscCode: 'IFSC456',
        address: 'Address B',
        isActive: false
      },
      // ... add more data objects
    ];
  }

  ngOnInit(): void {
  }
  onAdd(){
    this.isFormVisible = !this.isFormVisible    
    
  }
}
