
import { Component, OnInit, ViewChild } from '@angular/core';
import { Column, GridOption, Formatters, OnEventArgs } from 'angular-slickgrid';
import { HttpClient } from '@angular/common/http';
import { ApiFacadeService } from 'src/app/features/facade';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DialogboxComponent } from 'src/app/shared/helpers/dialogbox/dialogbox.component';
import { ImportComponent } from 'src/app/shared/helpers/import/import.component';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
import { FullscreenOverlayContainer } from '@angular/cdk/overlay';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { event } from 'jquery';
import { Router } from '@angular/router';
import { saveAs } from 'file-saver';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-fundsource-list',
  templateUrl: './fundsource-list.component.html',
  styleUrls: ['./fundsource-list.component.css'],

})
export class FundsourceListComponent implements OnInit {
  // @ViewChild(DialogboxComponent)
  // dialogBox!: DialogboxComponent;

  columnDefinitions1: Column[] = [];
  gridOptions1: GridOption;
  dataset1!: any[];

  selectedItemId!: number;
  page = 1;
  pageSize = 1000;

  currentPage = 1;


  fundsources: any = [];
  angularGrid: any;

  constructor(private http: HttpClient, public toastr: ToastrService, public apiService: ApiFacadeService, public dialog: MatDialog, public api: ApiService, private router: Router) 
  
  {
    this.gridOptions1 = {
      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 500,
      gridWidth: 1500,
      enableFiltering: true,
      enableCellNavigation: true, // Enable cell navigation to handle click events
    };  
  }
  
  paginationConfigForListGrid: any = {
    totalItems: 0,
    itemsPerPage: 1000,
    currentPage: 1,

  };



  ngOnInit(): void {


    this.columnDefinitions1 = [
      {
        id: 'isAnchorTagged',
        name: 'Anchor Tag',
        field: 'isAnchorTagged',
        maxWidth: 100,
        formatter: this.anchorTagFormatter, // Add the formatter for the checkbox column
      },
      { id: 'Sequence', name: 'Sequence', field: 'Sequence', filterable: true, formatter: this.numberAlignFormatter, maxWidth: 80, sortable: true },
      { id: 'Account Number', name: 'Account Number', field: 'Account Number', filterable: true, maxWidth: 140, formatter: this.numberAlignFormatter, sortable: true },
      { id: 'Account Name', name: 'Account Name', field: 'Account Name', filterable: true, maxWidth: 140, formatter: this.textAlignFormatter, sortable: true },
      { id: 'BankName', name: 'BankName', field: 'BankName', filterable: true, maxWidth: 150, formatter: this.textAlignFormatter, sortable: true },
      { id: 'Branch Name', name: 'Branch Name', field: 'Branch Name', filterable: true, maxWidth: 120, formatter: this.textAlignFormatter, sortable: true },
      { id: 'Description', name: 'Description', field: 'Description', filterable: true, maxWidth: 250, formatter: this.textAlignFormatter, sortable: true },
      { id: 'IFSC Code', name: 'IFSC Code', field: 'IFSC Code', filterable: true, maxWidth: 120, formatter: this.numberAlignFormatter, sortable: true },
      { id: 'Address', name: 'Address', field: 'Address', filterable: true, maxWidth: 250, formatter: this.textAlignFormatter, sortable: true },
      { id: 'Phone Number', name: 'Phone Number', field: 'Phone Number', filterable: true, formatter: this.numberAlignFormatter, sortable: true },
      {
        id: 'action',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext", args.dataContext.fundSourceId);
          this.selectedItemId = args.dataContext.cityId;
          console.log("fundsource-id ", this.selectedItemId);
          this.router.navigate(['/fundsource-form'], { queryParams: { selectedItemId: args.dataContext.fundSourceId } });
        },

        formatter: Formatters.editIcon
      },
      {
        id: 'delete',
        name: 'Action',
        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext prtham",args.dataContext.fundSourceId);
          this.selectedItemId = args.dataContext.fundSourceId;
          this.openDialog(e, args);

        },
        formatter: Formatters.deleteIcon
      },
      {
        id: 'clone',

        field: 'id',
        excludeFromColumnPicker: true,
        excludeFromGridMenu: true,
        excludeFromHeaderMenu: true,
        sortable: false,
        maxWidth: 50,
        onCellClick: (e: Event, args: OnEventArgs) => {
          console.log("args.dataContext", args.dataContext.fundSourceId);
          this.selectedItemId = args.dataContext.fundSourceId;
          console.log(this.selectedItemId);

          this.router.navigate(['/fundsource-form'], { queryParams: { selectedItemId: args.dataContext.fundSourceId, cloneFlag: 1 } });
        },
        formatter: this.cloneIconFormatter,// Use the custom formatter function

      }
    ];

    this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
  }

  
  cloneIconFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa fa-clone clickable"  style="cursor: pointer;"></i> `;
  }
  anchorTagFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<i class="fa-solid fa-anchor"  style="cursor: pointer;"></i> `;
  }

  numberAlignFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<div style="text-align: right;">${value}</div>`;
  }


  textAlignFormatter(row: number, cell: number, value: any, columnDef: Column, dataContext: any): string {
    return `<div style="text-align: left;">${value}</div>`;
  }

  handleCellClick(event: Event, args: any): void {
    const actionColumnId = 'clone';
    if (args.cell === this.columnDefinitions1.findIndex((c) => c.id === actionColumnId)) {
      this.cloneItem(args.row); // Handle the clone action, you can implement your own logic here
    }
  }

  cloneItem(row: number): void {
    console.log('Clone icon clicked on row:', row);
    // Implement your logic for the cloning operation here
  }


  pageChange(page: number): void {
    this.currentPage = page;
  }

  addNewUser(): void {
    // Add your logic for adding a new user here
  }


  openDialog2() {

    this.dialog.open(ImportComponent, {})
  }

  async getAllFundSources() {
    this.fundsources = await this.apiService.getAllFundSource();

    console.log('hello', this.fundsources);
  }


  async getAllFundSource(pageNumber: number, pageSize: number) {
    console.log('inside getAllBranchs facade')
    return new Promise(resolve => {
      return this.api.getDetailsPagination(GlobalUrlService.fundsource, pageNumber, pageSize).subscribe((res: any) => {
        console.log("ress==>", res);

        this.fundsources = res.data;
        console.log("this.branches", this.fundsources);

        this.fundsources.forEach((item: { id: any; }, index: number) => {
          item.id = index + 1;
        });
        this.dataset1 = this.fundsources;
        console.log("this.branches==", this.dataset1);

        console.log("branches==========", this.fundsources);
        resolve(this.fundsources);
      });
    })

  }

  exportData(): void {
    // Convert the data to a CSV format
    const csvContent = this.convertToCSV(this.dataset1);

    // Create a Blob with the data
    const blob = new Blob([csvContent], { type: 'text/csv' });

    // Trigger the download using FileSaver.js
    saveAs(blob, 'exported_data.csv');
  }
  convertToCSV(data: any[]): string {
    // Initialize the CSV content with the header row
    let csvContent = 'Sequence,Ifsc Code,Micr Code\n'; // here you must replace this to your column titles of list 

    // Iterate through the data and add each row to the CSV content
    for (const item of data) {
      const row = `${item.sequence},${item.ifscCode},${item.micrCode}\n`;  // here you must replace sequence , ifscCode and micrCode to your column titles of list 
      csvContent += row;
    }

    return csvContent;
  }


  ////////////////////////////


  onDeleteRecord(fundSourceId: number): void {
    this.selectedItemId = fundSourceId;
    this.openDialog('delete', { fundSourceId });
   
  }





  openDialog(action: any, obj: any) {

      obj.action = action;

    console.log("Inside the dialog ");
   const dialogRef= this.dialog.open(DialogboxComponent, {  

      width: '250px',
      data: { message: 'Do you want to delete this item?' }
        })

    //  const result=this.box.onYesClick();
    dialogRef.afterClosed().subscribe((result:boolean) => {
      // console.log(result);
        // result=true;
      if (result === true) {
        console.log("Inside the dialog 2234");
        // this.branchFacade.deleteItemById(this.selectedItemId);
        this.deleteData();
      }
    });

  }

  async deleteData() {
    console.log("****686865353.29698653****")
    console.log("Selected item",this.selectedItemId);
    this.toastr.success('Item deleted successfully!', 'Success');
    await this.apiService.deleteItemById(this.selectedItemId)
    console.log("fundsource id", this.selectedItemId);
    console.log("************")
 
    await this.getAllFundSource(this.paginationConfigForListGrid.currentPage, this.paginationConfigForListGrid.itemsPerPage);
    console.log("************")
  

    // this.router.navigate(['/fundsource-list']);
  }

  //////editt code


}