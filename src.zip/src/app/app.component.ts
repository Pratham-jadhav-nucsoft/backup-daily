import { Component, OnInit } from '@angular/core';
import { Column, GridOption } from 'angular-slickgrid';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title(title: any) {
    throw new Error('Method not implemented.');
  }
  columnDefinitions1: Column[] = [];
  gridOptions1!: GridOption;
  dataset1: any[] = [];

  ngOnInit(): void {
    this.columnDefinitions1 = [
      { id: 'title', name: 'Form Name', field: 'title' },
      { id: 'description', name: 'Description', field: 'description' },
      {
        id: 'action',
        name: 'Action',
        field: 'action',
        minWidth: 100,
        maxWidth: 120
      }
    ];

    this.gridOptions1 = {
      enableAutoResize: false,
      enableSorting: true,
      gridHeight: 500,
      gridWidth: 1500,
    };

    this.dataset1 = this.mockData();
  }

  mockData(): any[] {
    return [
      { id: 1, title: 'Task 1', description: 'Description 1', action: '' },
      { id: 2, title: 'Task 2', description: 'Description 2', action: '' },
      { id: 3, title: 'Task 3', description: 'Description 3', action: '' }
    ];
  }
}
