import { Component, OnInit ,ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AccountFormComponent } from '../account-form/account-form.component';
import { BankingFormComponent } from '../banking-form/banking-form.component';
import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { ApiFacadeService } from 'src/app/features/facade';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

import { startWith, map } from 'rxjs/operators';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
@Component({
  selector: 'app-fundsource-form',
  templateUrl: './fundsource-form.component.html',
  styleUrls: ['./fundsource-form.component.css']
})
export class FundsourceFormComponent implements OnInit {
  bankingForm!: FormGroup;
  listOfCompany: any=[];
  listOfIfsc: any=[];
  listOfAccountType:any=[];
  selectedBankName: any=[];
  selectedState:any= [];
  selectedCountry:any=[];
  listOfPincode:any =[];
  selectedCity:any = [];
  constructor(private formBuilder: FormBuilder, private http: HttpClient, public apiService: ApiFacadeService,) { }

  ngOnInit(): void {
    this.bankingForm = this.formBuilder.group({
      companyName: [null, Validators.required],
      branchName: [null, Validators.required],
      pincode: [null, Validators.required],
      // country: [null, Validators.required],
      country: [null, Validators.required],

      stdCode: [null, Validators.required],
      mobileNumber: [null, Validators.required],
      IFSC: [null, Validators.required],
      branchCode: [null, Validators.required],
      city: [null, Validators.required],
      address: [null, Validators.required],
      faxNumber: [null, Validators.required],
      emailId: [null, [Validators.required, Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)]],
      bankName: [null, Validators.required],
      micr: [null, [Validators.required, Validators.pattern('^[0-9]+$')]],
      state: [null, Validators.required],
      phoneNumber: [null, Validators.required],
      relationshipPerson: [null, Validators.required]
    });
  }
  // get f() {
  //   return this.bankingForm.controls;
  // }
  saveFundSource(){
    if (this.bankingForm.valid) {
      //    console.log(this.bankingForm);
      //     this.toastr.success('Form saved successfully !', 'Success');
      //     this.router.navigate(['/city-list']); }
      //    else {
      // this.message = 'Fill the remaining form';
      //      console.log('fill form properly');
      //     this.toastr.error('Fill the Form !', 'Fail');
      //  }
  }
}
goBack()
{
  console.log('back button')
}
}
