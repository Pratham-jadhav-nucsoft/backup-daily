import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-limit-loan',
  templateUrl: './limit-loan.component.html',
  styleUrls: ['./limit-loan.component.css']
})
export class LimitLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  
  limitForm!: FormGroup;
  
  
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.limitForm = this.formBuilder.group({
      productDescription: [''],
      manageFeeBasedOnLoan: [false],
      limmin:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      limmax:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      disbMonths:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      repayMonths:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      totalMonths:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
      incDecLimit:[null,[ Validators.minLength(1), Validators.maxLength(15)]],
      gracePeriod:[null,[ Validators.minLength(1), Validators.maxLength(2)]],
      stmtCycle:[null,[ Validators.required]],
      int:[null,[ Validators.required,Validators.min(1),Validators.max(100)]]
    });
  }

  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }
  
  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }


}
