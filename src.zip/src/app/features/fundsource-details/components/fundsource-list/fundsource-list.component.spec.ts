import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FundsourceListComponent } from './fundsource-list.component';

describe('FundsourceListComponent', () => {
  let component: FundsourceListComponent;
  let fixture: ComponentFixture<FundsourceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FundsourceListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FundsourceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
