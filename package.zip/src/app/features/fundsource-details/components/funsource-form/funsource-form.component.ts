import { Component, OnInit ,ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AccountFormComponent } from '../account-form/account-form.component';
import { BankingFormComponent } from '../banking-form/banking-form.component';
import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { ApiFacadeService } from 'src/app/features/facade';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
@Component({
  selector: 'app-funsource-form',
  templateUrl: './funsource-form.component.html',
  styleUrls: ['./funsource-form.component.css']
})
export class FunsourceFormComponent implements OnInit {
  @ViewChild(BankingFormComponent) bankingFormComponent!: BankingFormComponent;
  @ViewChild(AccountFormComponent) accountFormComponent!: AccountFormComponent;

  isFormCollapsed: boolean = true;
  isFormCollapsed2:  boolean = true;
  isFormCollapsed3:  boolean = true ;
  bankingForm: any;
  stateary:any=[];
 
  constructor(public toastr: ToastrService, private router: Router,private dialog: MatDialog,private http: HttpClient,public apiService:ApiFacadeService,public api:ApiService) {}
  toggleFormCollapse() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }
 
  
 
  toggleFormCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }
 
  toggleFormCollapse3() {
    this.isFormCollapsed3 = !this.isFormCollapsed3;
  }

  ngOnInit(): void {
    
  }

  async getAllBranchesCountry() {
    this.stateary = await this.apiService.getAllState();
    console.log("this.branches", this.stateary);
  }
 
  saveForm(): void  {
    const bankingFormData = this.bankingFormComponent.bankingForm.value;
    const accountFormData = this.accountFormComponent.accountForm.value;

    // Combine data and perform submission logic here
    const combinedData = { ...bankingFormData, ...accountFormData };
    console.log('Combined Data:', combinedData);
    // Perform API calls or other logic to save the data

    // Reset the forms after successful submission (optional)
    this.bankingFormComponent.bankingForm.reset();
    this.accountFormComponent.accountForm.reset();
    console.log('save button clicked');
    this.toastr.success('The Information may get lost!', 'Success');
  }

 

  goBack() {
    this.router.navigate(['/fundsource-list']);
  }

  navigateToOtherComponent() {
    // Use the Router service to navigate to another component
    this.router.navigateByUrl('/fundsource-list');
  }
}
