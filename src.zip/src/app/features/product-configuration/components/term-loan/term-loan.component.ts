
import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiFacadeService } from 'src/app/features/facade';

@Component({
  selector: 'app-term-loan',
  templateUrl: './term-loan.component.html',
  styleUrls: ['./term-loan.component.css']
})
export class TermLoanComponent implements OnInit {
  isFormCollapsed: boolean = true;
  isFormCollapsed2: boolean = true;
  params: any;
  editingMode : boolean = false;
  termForm!: FormGroup;
  rowFormArray!: FormArray;
  lastAddedRowIndex: number = -1;
  selectedInterestList: any = [];
  selectedMethodInterestList: any = [];




  
  interestMethodList =
    [
      {
        "commonId": 3033,
        "masterType": "interest_method",
        "commonCode": "interest_method_quat",
        "commonValue": "Declining Balance",
      },
      {
        "commonId": 3034,
        "masterType": "interest_method",
        "commonCode": "interest_method_year",
        "commonValue": "Flat",

      }
    ];






  constructor(private formBuilder: FormBuilder, public apiService: ApiFacadeService, public activate:ActivatedRoute) { 

    this.activate.queryParams.subscribe(productId => {
      this.params = productId;
      console.log("this.params", this.params);
      if (productId['productId']) {
        this.editingMode = true;
      }

    })

  }
 
  ngOnInit(): void {
    this.termForm = this.formBuilder.group({

      isManagedFeeBasedLoanAmount: [false],
      // ticketSizeMin:[null,[Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      // ticketSizeMax:[null,[this.maxValidator('min'),Validators.required,Validators.minLength(1),Validators.maxLength(15)]],
      ticketSizeMax: [null, [this.maxValidator('ticketSizeMin'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      ticketSizeMin: [null, [this.minValidator('ticketSizeMax'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

      maxCustomerIdExposure: [null, [this.maxValidator('minCustomerIdExposure'), Validators.minLength(1), Validators.maxLength(15)]],
      minCustomerIdExposure: [0, [this.maxValidator('maxCustomerIdExposure'), Validators.minLength(1), Validators.maxLength(15)]],
      maxTenure: [null, [this.maxValidator('minTenure'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minTenure: [null, [this.minValidator('maxTenure'), Validators.required, Validators.minLength(1), Validators.maxLength(3)]],

      maxAdvanceAmount: [null, [this.maxValidator('minAdvanceAmount'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
      minAdvanceAmount: [null, [this.minValidator('maxAdvanceAmount'), Validators.required, Validators.minLength(1), Validators.maxLength(15)]],

      maxAprPercentage: [null, [this.maxValidator('minAprPercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minAprPercentage: [null, [this.minValidator('maxAprPercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],

      maxProcessingFeePercentage: [null, [this.maxValidator('minProcessingFeePercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      minProcessingFeePercentage: [null, [this.minValidator('maxProcessingFeePercentage'), this.lessThanHundred, Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      // amtmax0: [null, Validators.required],
      // amtmin0: [null, Validators.required],
      // maxProcessingFeePercentage0: [null, Validators.required],
      // minProcessingFeePercentage0: [null, Validators.required],
      interestCode: [null, Validators.required],
      interestMethodCode: [null, Validators.required],
      isBalanceTransferred: [false],
      isOverrideEligibility: [false],
      isFreeInsuranceAllowed: [false],

      
      listOfTermCommercialConfig: this.formBuilder.array([

      ]),
      // Add more form controls as needed
    });

    this.rowFormArray = this.termForm.get('rows') as FormArray;
    const defaultRowCount = 2; // Set the number of default rows you want
    if(!this.params.productId){
      for (let i = 0; i < defaultRowCount; i++) {
        this.addContactDetails(); // This function adds default rows
      }
    }
   
    this.getAllInterests();
    this.getAllInterestMethods();
    this.fetchProductData();
  }
  



  
  toggleCollapse1() {
    this.isFormCollapsed = !this.isFormCollapsed;
  }

  toggleCollapse2() {
    this.isFormCollapsed2 = !this.isFormCollapsed2;
  }


  
  maxValidator(minControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const minControl = control.parent?.get(minControlName);
      if (minControl && control.value !== null && minControl.value !== null) {
        const min = +minControl.value;
        const max = +control.value;

        if (max <= min) {
          return { maxError: true };
        }
      }

      return null;
    };
  }


  get contactDetails() {
    return this.termForm.get("listOfTermCommercialConfig") as FormArray;
  }
  minValidator(maxControlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const maxControl = control.parent?.get(maxControlName);
      if (maxControl && control.value !== null && maxControl.value !== null) {
        const min = +control.value;
        const max = +maxControl.value;

        if (min >= max) {
          return { minError: true };
        }
      }

      return null;
    };
  }

  // visible() {
  //   // Convert to number
  //   if (this.termForm.valid) {
  //     isValid=!isValid;
  //   }

  // }

  lessThanHundred(control: AbstractControl): ValidationErrors | null {
    const value = +control.value; // Convert to number
    if (value >= 100) {
      return { lessThanHundred: true };
    }
    return null;
  }

  isManageFeeCheckboxDisabled(): boolean {
    const ticketSizeMin = this.termForm.get('ticketSizeMin')?.value;
    const ticketSizeMax = this.termForm.get('ticketSizeMax')?.value;
    return !(ticketSizeMin !== null && ticketSizeMax !== null && ticketSizeMin !== '' && ticketSizeMax !== '');
  }
  

  addContactDetails() {


    const termLoanCommercialProcessingFeeConfig = this.formBuilder.group({

      amountRangeMin: [null, [this.minValidator('amountRangeMax'), Validators.minLength(1), Validators.maxLength(15), Validators.required]],
      amountRangeMax: [null, [this.maxValidator('amountRangeMin'), Validators.minLength(1), Validators.maxLength(15), Validators.required]],
      processingFeePercentageMin: [null, [this.minValidator('processingFeePercentageMax'),Validators.max(100),  Validators.required]],
      processingFeePercentageMax: [null, [this.maxValidator('processingFeePercentageMin'),Validators.max(100), Validators.required]],
    });
    
    this.contactDetails.push(termLoanCommercialProcessingFeeConfig);
    this.lastAddedRowIndex = this.contactDetails.length - 1; // Update lastAddedRowIndex
  }

  addArray(i: any) {
    console.log('aaaaaa', +this.contactDetails.at(i).get('amountRangeMax')?.value)
    if (+this.termForm.value.ticketSizeMax != +this.contactDetails.at(i).get('amountRangeMax')?.value) {
      // if (this.termForm.value.ticketSizeMax.valid&&this.termForm.value.ticketSizeMin.valid) {
      //  this.addContactDetails();
      // } else {
      //  console.log('Please fill the current row first');
      //  }
      if (this.contactDetails.at(i).valid) {
        console.log('all fields valid');
        this.addContactDetails();
      } else {
        console.log('invalid field');

      }

    }
    else {
      console.log('max amount reached');
    }
  }
  // addArray(i: any) {
  //   const newRowFormGroup = this.formBuilder.group({
  //     amountRangeMin: [null, [this.minValidator('amountRangeMax'), Validators.required]],
  //     amountRangeMax: [null, [this.maxValidator('amountRangeMin'), Validators.required]],
  //     processingFeePercentageMin: [null, [this.minValidator('processingFeePercentageMax'), Validators.required]],
  //     processingFeePercentageMax: [null, [this.maxValidator('processingFeePercentageMin'), Validators.required]],
  //   });
  
  //   if (newRowFormGroup.valid) {
  //     this.contactDetails.push(newRowFormGroup);
  //     this.lastAddedRowIndex = this.contactDetails.length - 1;
  //   } else {
  //     console.log('Invalid field');
  //   }
  // }
  




  deleteDetails(contactIndex: number) {
    this.contactDetails.removeAt(contactIndex);

    if (contactIndex === this.lastAddedRowIndex) {
      if (this.contactDetails.length === 0) {
        this.lastAddedRowIndex = -1; // No rows left
      } else {
        this.lastAddedRowIndex = this.contactDetails.length - 1; // Update to the new last row index
      }
    }
  }


  // // form array
  // addRow() {
  //   this.rowFormArray.push(this.createRowFormGroup());
  // }
  // // removeRow(index: number) {
  // //   this.rowFormArray.removeAt(index);
  // // }
  // createRowFormGroup() {
  //   return this.formBuilder.group({
  //     min: [null, Validators.required],
  //     max: [null, Validators.required],
  //     // ... other controls
  //   });
  // }



  async getAllInterests() {
    console.log('adadadad');
    this.selectedInterestList = await this.apiService.getAllInterest();
    console.log(" category->>>>", this.selectedInterestList);
  }
  async getAllInterestMethods() {
    console.log('adadadad');
    this.selectedMethodInterestList = await this.apiService.getAllInterestMethod();
    console.log(" category->>>>", this.selectedMethodInterestList);
  }

  async fetchProductData(): Promise<void> {
   
    try {
      // const productData :any = await this.apiService.getProductById2(this.params.productId);
      if(this.params.productId){
        const productData :any = {
          "productId": 123,
          "isRenewal": true,
          "renewalProductId": 0,
          "productName": "oldIndustry",
          "productDescription": "ABCD",
          "productCode": "IND",
          "productCategoryCode": "string",
          "parentProductId": 0,
          "typesOfProduct": [
              {
                  "productCompositionID": 92,
                  "productTypeId": 1,
                  "appIdPattern": 100,
                  "percentageComposition": 0,
                  "productTypeName": "Term Loan",
                  "isActive": true,
                  "isDeleted": false,
                  "createdBy": "00000000-0000-0000-0000-000000000000",
                  "createdDate": "2023-08-25T15:55:21.14",
                  "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                  "updatedDate": "2023-08-08T13:55:50.683"
              }
          ],
          "overrideAtCalculatorLevel": true,
          "companyId": 1,
          "listOfIndustries": [
              {
                  "product_industry_mapping_id": 4,
                  "productId": 0,
                  "industryId": 4,
                  "subIndustryId": [
                      {
                          "product_industry_mapping_id": 4,
                          "subIndustryId": 1,
                          "isActive": true,
                          "isDeleted": false
                      }
                  ],
                  "isActive": true,
                  "isDeleted": false,
                  "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                  "createdDate": "2023-08-25T10:23:54.217",
                  "updatedBy": null,
                  "updatedDate": null
              }
          ],
          "isSecured": true,
          "isUnsecured": true,
          "branchId": [
              {
                  "product_branch_mapping_id": 9,
                  "branchId": 42,
                  "productId": 123,
                  "isActive": true,
                  "isDeleted": false,
                  "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                  "createdDate": "2023-08-25T10:23:54.217",
                  "updatedBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                  "updatedDate": "2023-08-09T13:55:50.683"
              }
          ],
          "maxOutstandingPercentageOfPreviousLoan": 0,
          "isBcPartner": true,
          "termLoanCommercialConfig": [
              {
                  "termLoanCommercialConfigId": 30,
                  "productCompositionId": 92,
                  "ticketSizeMin": 20,
                  "ticketSizeMax": 30,
                  "minCustomerIdExposure": 1000,
                  "maxCustomerIdExposure": 2000,
                  "minAdvanceAmount": 10,
                  "maxAdvanceAmount": 0,
                  "minAprPercentage": 0,
                  "maxAprPercentage": 0,
                  "minTenure": 0,
                  "maxTenure": 0,
                  "minProcessingFeePercentage": 0,
                  "maxProcessingFeePercentage": 0,
                  "isManagedFeeBasedLoanAmount": true,
                  "interestCode": "variable",
                  "interestMethodCode": "flat",
                  "isFreeInsuranceAllowed": false,
                  "isOverrideEligibility": true,
                  "isBalanceTransferred": false,
                  "termLoanCommercialProcessingFeeConfig": [
                      {
                          "termLoanCommercialConfig": 30,
                          "listOfTermCommercialConfig": [
                              {
                                  "termLoanCommercialProcessingFeeConfigId": 30,
                                  "amountRangeMin": 10,
                                  "amountRangeMax": 0,
                                  "processingFeePercentageMin": 0,
                                  "processingFeePercentageMax": 0,
                                  "isActive": true,
                                  "isDeleted": false,
                                  "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                  "createdDate": "2023-08-25T10:23:54.217",
                                  "updatedBy": null,
                                  "updatedDate": null
                              },
                              {
                                "termLoanCommercialProcessingFeeConfigId": 30,
                                "amountRangeMin": 10,
                                "amountRangeMax": 0,
                                "processingFeePercentageMin": 0,
                                "processingFeePercentageMax": 0,
                                "isActive": true,
                                "isDeleted": false,
                                "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "createdDate": "2023-08-25T10:23:54.217",
                                "updatedBy": null,
                                "updatedDate": null
                            },
                              {
                                "termLoanCommercialProcessingFeeConfigId": 30,
                                "amountRangeMin": 10,
                                "amountRangeMax": 0,
                                "processingFeePercentageMin": 0,
                                "processingFeePercentageMax": 0,
                                "isActive": true,
                                "isDeleted": false,
                                "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                                "createdDate": "2023-08-25T10:23:54.217",
                                "updatedBy": null,
                                "updatedDate": null
                            }
                          ]
                      }
                  ],
                  "isActive": true,
                  "isDeleted": false,
                  "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                  "createdDate": "0001-01-01T00:00:00",
                  "updatedBy": null,
                  "updatedDate": null
              }
          ],
          "listOfLimitLoan": null,
          "isActive": true,
          "isDeleted": false,
          "createdBy": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
          "createdDate": "2023-08-25T15:55:21.137",
          "updatedBy": null,
          "updatedDate": null
      }
    
        if (productData) {
          if(productData.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig){
            productData.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig.forEach((element:any) => {
              this.addContactDetails();
            });
          }
  
          this.termForm.patchValue({
            ticketSizeMax: productData.termLoanCommercialConfig[0].ticketSizeMax,
            ticketSizeMin: productData.termLoanCommercialConfig[0].ticketSizeMin,
            maxCustomerIdExposure: productData.termLoanCommercialConfig[0].maxCustomerIdExposure,
            minCustomerIdExposure: productData.termLoanCommercialConfig[0].maxCustomerIdExposure,
            minTenure: productData.termLoanCommercialConfig[0].minTenure,
            maxTenure: productData.termLoanCommercialConfig[0].maxTenure,
            maxAdvanceAmount: productData.termLoanCommercialConfig[0].maxAdvanceAmount,
            minAdvanceAmount: productData.termLoanCommercialConfig[0].minAdvanceAmount,
            maxAprPercentage: productData.termLoanCommercialConfig[0].maxAprPercentage,
            minAprPercentage: productData.termLoanCommercialConfig[0].minAprPercentage,
            maxProcessingFeePercentage: productData.termLoanCommercialConfig[0].maxProcessingFeePercentage,
            interestCode: productData.termLoanCommercialConfig[0].interestCode,
            interestMethodCode: productData.termLoanCommercialConfig[0].interestMethodCode,
            isBalanceTransferred: productData.termLoanCommercialConfig[0].isBalanceTransferred,
            isOverrideEligibility: productData.termLoanCommercialConfig[0].isOverrideEligibility,
            isFreeInsuranceAllowed: productData.termLoanCommercialConfig[0].isFreeInsuranceAllowed,
            isManagedFeeBasedLoanAmount: productData.termLoanCommercialConfig[0].isManagedFeeBasedLoanAmount,
            
            listOfTermCommercialConfig: productData.termLoanCommercialConfig[0].termLoanCommercialProcessingFeeConfig[0].listOfTermCommercialConfig.map((element: any) => ({
              amountRangeMin: element.amountRangeMin,
              amountRangeMax: element.amountRangeMax,
              processingFeePercentageMin: element.processingFeePercentageMin,
              processingFeePercentageMax: element.processingFeePercentageMax
            })),
        
  
            // Map other properties as needed
          });
          console.log('termproductData---------------->', productData);
        } else {
          console.error('Failed to fetch product data.');
        }
      }
      
    } catch (error) {
      console.error('Error while fetching data by ID:', error);
    }
  }
  
  
}
