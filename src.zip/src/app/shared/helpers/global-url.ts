import { OnInit, Directive } from '@angular/core';
import configJson from "src/assets/config/config.json";
import { Injectable } from '@angular/core';
@Directive()



@Injectable({
  providedIn: 'root',
})
export class GlobalUrlService implements OnInit {

  public static fundsource = configJson.gateWayUrl + '/fund-source/pagination';

  // public static bank = configJson.gateWayUrl + '/api/Master/get-all-bank';


  // dropdowns
  public static state = configJson.gateWayUrl + '/masters/get-all-state';
  public static city = configJson.gateWayUrl + '/masters/get-all-city';
  public static pincode = configJson.gateWayUrl + '/masters/get-all-pincode';
  public static country = configJson.gateWayUrl + '/masters/get-all-country';
  public static bankifsc = configJson.gateWayUrl + '/masters/get-all-ifsc';
  public static bankname = configJson.gateWayUrl + '/masters/get-all-bank';

  public static accounttype = configJson.gateWayUrl + '/masters/get-all-account-type';


  //edit
  public static edit = configJson.gateWayUrl + '/fund-source/fundSourceId';


  // post
  public static post = configJson.gateWayUrl + '/fund-source';


  /// delete
  public static delete = configJson.gateWayUrl + '/fund-source';

//sequence
  public static sequence = configJson.gateWayUrl+'/fund-source/max-sequence';

//autopopulate
  public static   autopopulate = configJson.gateWayUrl+'  /masters/get-all-ifsc';


//template
  public static   template = configJson.gateWayUrl+'/fund-source/sample';

//import
  public static   imports = configJson.gateWayUrl+'/fund-source/import';


//export 
  public static   export = configJson.gateWayUrl+'/fund-source/export';



  

  ngOnInit(): void {
  }
}

