import { Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LimitLoanComponent } from '../limit-loan/limit-loan.component';
import { TermLoanComponent } from '../term-loan/term-loan.component';
import { validateHorizontalPosition } from '@angular/cdk/overlay';
@Component({
  selector: 'app-productconfiguration-form',
  templateUrl: './productconfiguration-form.component.html',
  styleUrls: ['./productconfiguration-form.component.css']
})
export class ProductconfigurationFormComponent implements OnInit {
  @ViewChild('dynamicComponent', { read: ViewContainerRef, static: true })
  dynamicComponentContainer!: ViewContainerRef;

  allowedIndustriesSelected: boolean = false;
  termLoanComponentRef: any = null;
  limitLoanComponentRef: any = null;  
  showAdditionalDiv: boolean = false;
  showAdditionalDiv2: boolean = false;
  showAdditionalDiv3: boolean = false;
  
  selectedProductTypes: boolean[] = [];
   selectedValues :any;

  

  isFormCollapsed: boolean = true;
 

  productTypes = [
    { value: 'type1', label: 'Term Loan' },
    { value: 'type2', label: 'Limit Loan  ' },
    // ... add more product types
  ];
  // subIndustries = [
  //   { value: 'subIndustry1', label: 'Sub-industry 1' },
  //   { value: 'subIndustry2', label: 'Sub-industry 2' },
  //   // ... add more sub-industries
  // ];
  
  industries = [
    { value: 'financialServices', label: 'Financial Services' },
    { value: 'healthcare', label: 'Healthcare' },
    // ... add other industries
  ];

  subIndustriesMapping: { [key: string]: string[] } = { // Provide an index signature
    financialServices: [
      'biotechnology',
      'telemedicine',
      'banking',
      'assetManagement',
      // ... add other sub-industries
    ],
    healthcare: [
      'medicalDevices',
      'pharmaceuticals',
      // ... add other sub-industries
    ],
    // ... add mappings for other industries
  };


  productForm!: FormGroup;
  // isPanelExpanded: boolean = true;





  constructor(
    private formBuilder:FormBuilder,
    private componentFactoryResolver: ComponentFactoryResolver
  ) { }

ngOnInit(): void {

  this.productForm = this.formBuilder.group({
    isRenewal: [false],
    correspondingFreshProduct: [null,Validators.required],
    productName: [null,[ Validators.required,Validators.pattern('^[a-zA-Z0-9\\s]*$'),Validators.minLength(2),Validators.maxLength(30)]],
    productDescription: [null,[Validators.minLength(2),Validators.maxLength(300)] ],
    productCode: [null,[Validators.required ,Validators.minLength(2),Validators.maxLength(6)] ],
    parentProduct: [null, ],
    appIdTL:[null,[Validators.required, Validators.pattern('^[0-9]+$'),Validators.minLength(1),Validators.maxLength(15)]],
    compTL:[null,[Validators.required,Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
    appIdLL:[null,[Validators.required, Validators.pattern('^[0-9]+$'),Validators.minLength(1),Validators.maxLength(15)]],
    compLL:[null,[Validators.required,Validators.pattern('^(?:100(?:\\.0{1,2})?|\\d{1,2}(?:\\.\\d{1,2})?)$')]],
    calLvl:[false],

    category: [null, Validators.required ],
    productType: [null, Validators.required,[] ],
    companyName: [null,Validators.required ],
    allowedIndustries: [ [],Validators.required ],
    allowedSubIndustries: [[] ],
    securedProduct: [null, ],
    UnsecuredProduct: [null, ],
    branch: [null, Validators.required],
    maxOutstanding: [null, ],
    bcPartner: [null, ],
    
  });
}



  get f() {
    return this.productForm.controls;
  }
 

// toggleCollapse() {
//   this.isFormCollapsed = !this.isFormCollapsed;
// }





onAllowedIndustriesChange(selectedIndustries: string[]): void {
  const selectedSubIndustries = selectedIndustries.flatMap(industry =>
    this.subIndustriesMapping[industry]
  );
  this.productForm.patchValue({ allowedSubIndustries: selectedSubIndustries });
}
getSubIndustriesForSelectedIndustries(selectedIndustries: string[]): any[] {
  let subIndustries: any[] = [];
  selectedIndustries.forEach(industry => {
    if (this.subIndustriesMapping[industry]) {
      subIndustries = subIndustries.concat(this.subIndustriesMapping[industry]);
    }
  });
  return subIndustries;
}
// onProductTypeChange(): void {
//   this.selectedValues = this.productForm.get('productType')?.value || [];
//   this.dynamicComponentContainer.clear();

//     // Dynamically load the selected component
//     if (this.selectedValues.includes('type1')) {
//       const termLoanFactory = this.componentFactoryResolver.resolveComponentFactory(TermLoanComponent);
//       this.dynamicComponentContainer.createComponent(termLoanFactory);
//     }
  
//     if (this.selectedValues.includes('type2')) {
//       const limitLoanFactory = this.componentFactoryResolver.resolveComponentFactory(LimitLoanComponent);
//       this.dynamicComponentContainer.createComponent(limitLoanFactory);
//     }
   
// }
// onProductTypeChange(): void {
//   this.selectedValues = this.productForm.get('productType')?.value || [];
//   this.dynamicComponentContainer.clear();

//   // Dynamically load the selected component
//   if (this.selectedValues.includes('type1')) {
//     const termLoanFactory = this.componentFactoryResolver.resolveComponentFactory(TermLoanComponent);
//     this.dynamicComponentContainer.createComponent(termLoanFactory);
//   }

//   if (this.selectedValues.includes('type2')) {
//     const limitLoanFactory = this.componentFactoryResolver.resolveComponentFactory(LimitLoanComponent);
//     this.dynamicComponentContainer.createComponent(limitLoanFactory);
//   }

//   // Set the showAdditionalDiv property based on the condition
//   this.showAdditionalDiv = this.selectedValues.includes('type1') ;
//   this.showAdditionalDiv2 = this.selectedValues.includes('type2') ;
//   this.showAdditionalDiv3 = this.selectedValues.includes('type1') &&this.selectedValues.includes('type2');
// }

onProductTypeChange(): void {
  this.selectedValues = this.productForm.get('productType')?.value || [];

  // Set the showAdditionalDiv properties based on the condition
  this.showAdditionalDiv = this.selectedValues.includes('type1');
  this.showAdditionalDiv2 = this.selectedValues.includes('type2');
  this.showAdditionalDiv3 = this.selectedValues.includes('type1') && this.selectedValues.includes('type2');

  // Clear any previously loaded components
  this.dynamicComponentContainer.clear();

  // Dynamically load the selected components
  if (this.selectedValues.includes('type1')) {
    const termLoanFactory = this.componentFactoryResolver.resolveComponentFactory(TermLoanComponent);
    const termLoanComponentRef = this.dynamicComponentContainer.createComponent(termLoanFactory);
    // Optional: Pass any inputs or handle interactions with the component
    // termLoanComponentRef.instance.someInput = someValue;
  }

  if (this.selectedValues.includes('type2')) {
    const limitLoanFactory = this.componentFactoryResolver.resolveComponentFactory(LimitLoanComponent);
    const limitLoanComponentRef = this.dynamicComponentContainer.createComponent(limitLoanFactory);
    // Optional: Pass any inputs or handle interactions with the component
    // limitLoanComponentRef.instance.someInput = someValue;
  }
}




// onsave method
onSubmitButtonClicked(): void {
  if (this.productForm.valid) {
    // You can access form values using this.productForm.value
    const formData = this.productForm.value;
    console.log('Form submitted:', formData);
    
    // Perform further actions, like sending data to a server
  } else {
    console.log('Form is invalid. Cannot submit.');
  }
}

// ... other class methods ...



}
