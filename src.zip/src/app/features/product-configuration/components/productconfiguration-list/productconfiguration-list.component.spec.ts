import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductconfigurationListComponent } from './productconfiguration-list.component';

describe('ProductconfigurationListComponent', () => {
  let component: ProductconfigurationListComponent;
  let fixture: ComponentFixture<ProductconfigurationListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductconfigurationListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductconfigurationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
