import { Component, OnInit ,ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AccountFormComponent } from '../account-form/account-form.component';
import { BankingFormComponent } from '../banking-form/banking-form.component';
import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { ApiFacadeService } from 'src/app/features/facade';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

import { startWith, map } from 'rxjs/operators';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
@Component({
  selector: 'app-fundsource-form',
  templateUrl: './fundsource-form.component.html',
  styleUrls: ['./fundsource-form.component.css']
})
export class FundsourceFormComponent implements OnInit {
  bankingForm!: FormGroup;
  listOfCompany: any=[];
  listOfIfsc: any=[];
  listOfAccountType:any=[];
  selectedBankName: any=[];
  selectedState:any= [];
  selectedCountry:any=[];
  listOfPincode:any =[];
  selectedCity:any = [];
  constructor(private formBuilder: FormBuilder, private http: HttpClient, public apiService: ApiFacadeService,) { }

  ngOnInit(): void {
    this.bankingForm = this.formBuilder.group({
      companyId: [null, Validators.required],
      bankBranchName: [null, Validators.required],
      pincodeId: [null, Validators.required],
      // country: [null, Validators.required],
      countryId: [null, Validators.required],
      bankId: [null, Validators.required],
      
      phoneStdCode: [null, Validators.required],
      mobileNumber: [null, Validators.required],
      ifscId: [null, Validators.required],
      bankBranchCode: [null, Validators.required],
      cityId: [null, Validators.required],
      address: [null, Validators.required],
      faxNumber: [null, Validators.required],
      emailId: [null, [Validators.required, Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)]],
      
      micrCode: [null, [Validators.required, Validators.pattern('^[0-9]+$')]],
      stateId: [null, Validators.required],
      phoneNumber: [null, Validators.required],
      relationshipPerson: [null, Validators.required],
      accountTypeCode: [null, Validators.required],
      accountName: [null, Validators.required],
      accountNumber: [null, Validators.required],
      userNumber: [null, Validators.required],
      userName: [null, Validators.required],
      esctTapeInputNumber: [null, Validators.required],
      ledgerFolioNumber: [null, Validators.required],
      creditItemLimit: [null, Validators.required],
      creditReference: [null, Validators.required],
      description: [null, Validators.required],
      sequence: [null, Validators.required],
      isRestricted: [null, Validators.required],
      isExcluded: [null, Validators.required],
      fromDate: [null, Validators.required],
      toDate: [null, Validators.required],
      isAnchorTagged: [null, Validators.required],


    });
  }
  // get f() {
  //   return this.bankingForm.controls;
  // }
  saveFundSource(){
    if (this.bankingForm.valid) {
      //    console.log(this.bankingForm);
      //     this.toastr.success('Form saved successfully !', 'Success');
      //     this.router.navigate(['/city-list']); }
      //    else {
      // this.message = 'Fill the remaining form';
      //      console.log('fill form properly');
      //     this.toastr.error('Fill the Form !', 'Fail');
      //  }
  }
}
goBack()
{
  console.log('back button')
}
}
