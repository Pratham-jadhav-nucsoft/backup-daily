  import { Component, OnInit } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';

  @Component({
    selector: 'app-limit-loan',
    templateUrl: './limit-loan.component.html',
    styleUrls: ['./limit-loan.component.css']
  })
  export class LimitLoanComponent implements OnInit {
    isFormCollapsed: boolean = true;
    isFormCollapsed2: boolean = true;
    
    limitForm!: FormGroup;
    
    
    constructor(private formBuilder: FormBuilder) { }

    ngOnInit(): void {
      this.limitForm = this.formBuilder.group({
     
        minLimitTicketSize:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
        maxLimitTicketSize:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(15)]],
        disbMonth:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
        repaymentMonth:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
        totalMonth:[null,[Validators.required, Validators.minLength(1), Validators.maxLength(2)]],
        increaseDecreaseLoanLimit:[null,[ Validators.minLength(1), Validators.maxLength(15)]],
        gracePeriod:[null,[ Validators.minLength(1), Validators.maxLength(2)]],
        statementDateCode:[null,[ Validators.required]],
        interestPercentage:[null,[ Validators.required,Validators.min(1),Validators.max(100)]],
        interestEffectiveDate:[null],
        penalRateOfInterestPercentage:[null],
        penalEffectiveDate:[null],
        minimumPaymentPercentage:[null],
        processingFeePercentage:[null],
        gstPercentage:[null],
        chequeBounceCharges:[null],
        nachBounceCharges:[null],
        tolerancePeriod:[null],
        minimumDisbursement:[null],
        toleranceAmount:[null],
        dpdToleranceAmount:[null],
        orderDisbursementEventCode:[null],
        interestCalculationMethodCode:[null],
        penalInterestCalculationMethodCode:[null],
        minimumAmountDueCalculationMethodCode:[null],
        coolingPeriodHrs:[null],

      });
      this.limitForm.get('disbMonth')?.valueChanges.subscribe(() => {
        this.updatetotalMonth();
      });
    
      this.limitForm.get('repaymentMonth')?.valueChanges.subscribe(() => {
        this.updatetotalMonth();
      });
    }

    toggleCollapse1() {
      this.isFormCollapsed = !this.isFormCollapsed;
    }
    
    toggleCollapse2() {
      this.isFormCollapsed2 = !this.isFormCollapsed2;
    }
    updatetotalMonth() {
      const disbMonth = this.limitForm.get('disbMonth')?.value || 0;
      const repaymentMonth = this.limitForm.get('repaymentMonth')?.value || 0;
      
      const totalMonth = disbMonth + repaymentMonth;
      
      this.limitForm.get('totalMonth')?.setValue(totalMonth);
    }

  }
