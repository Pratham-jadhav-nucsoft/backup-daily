import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/shared/helpers/modal/api.service';
// import { GlobalUrlDirective } from 'src/app/shared/helpers/modal/global-url';
import { GlobalUrlService } from 'src/app/shared/helpers/global-url';
@Injectable({
  providedIn: 'root',
})
export class ApiFacadeService {
  deletedData: any;
  constructor(private apiService: ApiService) { }

  async getAllFundSource() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.fundsource).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }


  //   async getAllBanks() {
  //     return new Promise(resolve => {
  //              return this.apiService.getAllBank  (GlobalUrlService.bank).subscribe(res => {
  //                 resolve(res);
  //                 console.log(res);
  //                 console.log('console running')
  //               });
  //             });
  // }

  async getAllState() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.state).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running(facade layer)')
      });
    });
  }
  async getAllCity() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.city).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllPincode() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.pincode).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllCountry() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.country).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllBankIFSC() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.bankifsc).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }
  async getAllBankName() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.bankname).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }

  async getAllAccountType() {
    return new Promise(resolve => {
      return this.apiService.getAllDetails(GlobalUrlService.accounttype).subscribe(res => {
        resolve(res);
        console.log(res);
        console.log('console running')
      });
    });
  }


  async getBranchByIdPincode(id: number) {
    return new Promise(resolve => {
      return this.apiService.getDetailsById(GlobalUrlService.autopopulate, +id).subscribe(
        (res: any) => {
          resolve(res);
          console.log(res);
        },
        (error: any) => {
          // Handle error here
          console.error('Error while fetching data by ID:', error);
          resolve(null); // Return null or handle the error case as needed
        }
      );
    });
}


  postCityDetails(payload: any) {
    return new Promise(resolve => {
      this.apiService.postAllDetails(GlobalUrlService.post, payload).subscribe(res => {
        resolve(res);
        console.log(res);
      });
    });
  }


  deleteItemById(fundSourceId: number){
    console.log("this.apis_id=====>", fundSourceId);
    return new Promise(resolve => {
        this.apiService.deleteById(GlobalUrlService.delete,fundSourceId).subscribe(res => {
            this.deletedData = res;
            console.log("data", this.deletedData);
           resolve(res);
        });
    });
  
}

async getFundSourceById(id: number) {
  return new Promise(resolve => {
    return this.apiService.getDetailsById(GlobalUrlService.edit, +id).subscribe(
      (res: any) => {
        resolve(res);
        console.log(res);
      },
      (error: any) => {
        // Handle error here
        console.error('Error while fetching data by ID:', error);
        resolve(null); // Return null or handle the error case as needed
      }
    );
  });
}


async getNextSequence() {
  return new Promise(resolve => {
      return this.apiService.getAllSequence(GlobalUrlService.sequence).subscribe(res => {
          resolve(res);
          console.log("ggggggggggg", res);
      });
  });
}


downloadTemplate(): Observable<Blob> {
  return this.apiService.downloadTemplate();
}


// async getFundSourceById(id: number) {
//   return new Promise(resolve => {
//     return this.apiService.getDetailsById(GlobalUrlService.edit, +id).subscribe(
//       (res: any) => {
//         resolve(res);
//         console.log(res);
//       },
//       (error: any) => {
//         // Handle error here
//         console.error('Error while fetching data by ID:', error);
//         resolve(null); // Return null or handle the error case as needed
//       }
//     );
//   });
// }
}


